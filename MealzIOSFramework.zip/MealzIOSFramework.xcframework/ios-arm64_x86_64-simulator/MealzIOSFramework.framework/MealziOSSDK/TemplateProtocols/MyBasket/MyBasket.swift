//
//  MyBasket.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 25/03/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI
import mealzcore

public enum SelectedMyBasketPage: Int {
    case recipes
    case products
}

/**
 A view showing the MyBasket page where users can see the recipes and products in their basket.
 
 Mandatory Parameters:
 - myBasketParams:  An implementation of ``MyBasketParametersProtocol``, usually the default ``MyBasketParameters``
 - myBasketBaseViews:  An implementation of ``BaseViewsProtocol``
 - myMealsParams:  An implementation of ``MyMealsParametersProtocol``, usually the default ``MyMealsParameters``
 - myMealsBaseViews:  An implementation of ``BaseViewsProtocol``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as the spacing, recipe card height & width, etc.
 */
@available(iOS 14, *)
public struct MyBasket<
    MyBasketParameters: MyBasketParametersProtocol,
    MyBasketBaseViews: BaseViewsProtocol,
    MyMealsParameters: MyMealsParametersProtocol,
    MyMealsBaseViews: BaseViewsProtocol,
    MyProductsParameters: MyProductsParametersProtocol,
    MyProductsBaseViews: BaseViewsProtocol
// TODO: Add MyProducts params & base views
>: View {
    private let myBasketParams: MyBasketParameters
    private let myBasketBaseViews: MyBasketBaseViews
    private let myMealsParams: MyMealsParameters
    private let myMealsBaseViews: MyMealsBaseViews
    private let myProductsParams: MyProductsParameters
    private let myProductsBaseViews: MyProductsBaseViews
    private let footerHeight: CGFloat

    private let gridConfig: CatalogRecipesListGridConfig
    @SwiftUI.State private var selection: SelectedMyBasketPage
    @StateObject private var myBasketVM: MyBasketVM = MyBasketVM()
    @StateObject private var myMealsViewModel: MyMealVM = MyMealVM()
    @StateObject private var myProductsViewModel: MyProductsVM
    
    public init(
        myBasketParams: MyBasketParameters,
        myBasketBaseViews: MyBasketBaseViews,
        myMealsParams: MyMealsParameters,
        myMealsBaseViews: MyMealsBaseViews,
        myProductsParams: MyProductsParameters,
        myProductsBaseViews: MyProductsBaseViews,
        footerHeight: CGFloat = 80,
        gridConfig: CatalogRecipesListGridConfig
    ) {
        self.myBasketParams = myBasketParams
        self.myBasketBaseViews = myBasketBaseViews
        self.myMealsParams = myMealsParams
        self.myMealsBaseViews = myMealsBaseViews
        self.myProductsParams = myProductsParams
        self.myProductsBaseViews = myProductsBaseViews
        self.gridConfig = gridConfig
        self.footerHeight = footerHeight
        _selection = State(initialValue: .recipes)
        _myProductsViewModel =  StateObject(wrappedValue: MyProductsVM(openItemSelector: myProductsParams.actions.openItemSelector))
    }
    
    public var body: some View {
        ZStack {
            myBasketBaseViews.background.content(params: BaseBackgroundParameters())
            SuccessContent(
                myMealsViewModel: myMealsViewModel,
                myProductsViewModel: myProductsViewModel,
                recipeCount: $myBasketVM.recipeCount,
                selection: $selection,
                myBasketParams: myBasketParams,
                myMealsParams: myMealsParams,
                myMealsBaseViews: myMealsBaseViews,
                myProductsParams: myProductsParams,
                myProductsBaseViews: myProductsBaseViews,
                gridConfig: gridConfig
            )
            .padding(.bottom, footerHeight)
            Footer(viewModel: myBasketVM, myBasketParams: myBasketParams, footerHeight: footerHeight)
        }
        .onAppear { myBasketVM.registerListeners() }
        .onDisappear { myBasketVM.dispose() }
    }
    
    struct SuccessContent: View {
        // maybe these can be created here instaed of passed in
        @ObservedObject private var myMealsViewModel: MyMealVM
        @ObservedObject private var myProductsViewModel: MyProductsVM
        @Binding private var recipeCount: Int
        @Binding var selection: SelectedMyBasketPage
        private let myBasketParams: MyBasketParameters
        private let myMealsParams: MyMealsParameters
        private let myMealsBaseViews: MyMealsBaseViews
        private let myProductsParams: MyProductsParameters
        private let myProductsBaseViews: MyProductsBaseViews
        let gridConfig: CatalogRecipesListGridConfig
        
        init(
            myMealsViewModel: MyMealVM,
            myProductsViewModel: MyProductsVM,
            recipeCount: Binding<Int>,
            selection: Binding<SelectedMyBasketPage>,
            myBasketParams: MyBasketParameters,
            myMealsParams: MyMealsParameters,
            myMealsBaseViews: MyMealsBaseViews,
            myProductsParams: MyProductsParameters,
            myProductsBaseViews: MyProductsBaseViews,
            gridConfig: CatalogRecipesListGridConfig
        ) {
            _myMealsViewModel = ObservedObject(wrappedValue: myMealsViewModel)
            _myProductsViewModel = ObservedObject(wrappedValue: myProductsViewModel)
            _recipeCount = recipeCount
            _selection = selection
            self.myBasketParams = myBasketParams
            self.myMealsParams = myMealsParams
            self.myMealsBaseViews = myMealsBaseViews
            self.myProductsParams = myProductsParams
            self.myProductsBaseViews = myProductsBaseViews
            self.gridConfig = gridConfig
        }
        
        public var body: some View {
            VStack {
                TitleContent(recipeCount: $recipeCount, myBasketParams: myBasketParams)
                myBasketParams.swapper.content(params: MyBasketSwapperParameters(selection: $selection))
                if (selection == .recipes) {
                    MyMeals(params: myMealsParams, baseViews: myMealsBaseViews, gridConfig: gridConfig, myMealsViewModel: myMealsViewModel)
                } else {
                    MyProducts(params: myProductsParams, baseViews: myProductsBaseViews, myProductsViewModel: myProductsViewModel)
                }
            }
        }
    }
    
    struct Footer: View {
        @ObservedObject private var viewModel: MyBasketVM
        private let myBasketParams: MyBasketParameters
        private let footerHeight: CGFloat
        
        init(viewModel: MyBasketVM, myBasketParams: MyBasketParameters, footerHeight: CGFloat) {
            self.viewModel = viewModel
            self.myBasketParams = myBasketParams
            self.footerHeight = footerHeight
        }
        
        var body: some View {
            VStack {
                Spacer()
                myBasketParams.footer.content(params: MyBasketFooterParameters(
                    totalPrice: viewModel.totalPrice,
                    heightOfFooter: footerHeight,
                    basketStatus: viewModel.myBasketStatus,
                    submitOrder: { 
                        viewModel.transferBasketIfPossible { url in
                            myBasketParams.actions.onSubmitOrder(url)
                        }
                    }))
            }
        }
    }
    
    struct TitleContent: View {
        @Binding private var recipeCount: Int
        private let myBasketParams: MyBasketParameters
        
        init(recipeCount: Binding<Int>, myBasketParams: MyBasketParameters) {
            self.myBasketParams = myBasketParams
            _recipeCount = recipeCount
        }
        
        var body: some View {
            myBasketParams.title.content(
                params: TitleParameters(
                    title:
                        String(
                            format: String.localizedStringWithFormat(
                                Localization.myMeals.mealsAdded(numberOfMeals: Int32(recipeCount)).localised,
                                recipeCount
                            ),
                            recipeCount
                        ),
                    subtitle: Localization.myMeals.goToCatalog.localised)
            )
            .padding(.top, 24)
            .padding(.bottom, 8)
        }
    }
}
