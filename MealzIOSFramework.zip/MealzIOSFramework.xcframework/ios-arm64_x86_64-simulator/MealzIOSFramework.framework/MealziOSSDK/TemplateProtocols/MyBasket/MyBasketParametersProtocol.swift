//
//  MyBasketParametersProtocol.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 27/03/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the My Basket Page.
 - title:  An implementation of ``BaseTitleProtocol``
 - swapper:  An implementation of ``MyBasketSwapperProtocol``
 */
@available(iOS 14, *)
public protocol MyBasketParametersProtocol {
    associatedtype Title: BaseTitleProtocol
    associatedtype Swapper: MyBasketSwapperProtocol
    associatedtype Footer: MyBasketFooterProtocol

    var title: Title { get }
    var swapper: Swapper { get }
    var footer: Footer { get }
    
    var actions: MyBasketActions { get set }
}

public struct MyBasketActions {
    var onSubmitOrder: (String) -> Void
    
    public init(
        onSubmitOrder: @escaping (String) -> Void
    ) {
        self.onSubmitOrder = onSubmitOrder
    }
}
