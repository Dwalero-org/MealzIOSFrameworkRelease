//
//  TypeSafeMyBasketFooter.swift
//  MealzIOSFramework
//
//  Created by Diarmuid McGonagle on 08/04/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public struct TypeSafeMyBasketFooter: MyBasketFooterProtocol {
    private let _content: (MyBasketFooterParameters) -> AnyView

    public init<T: MyBasketFooterProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MyBasketFooterParameters) -> some View {
        _content(params)
    }
}
