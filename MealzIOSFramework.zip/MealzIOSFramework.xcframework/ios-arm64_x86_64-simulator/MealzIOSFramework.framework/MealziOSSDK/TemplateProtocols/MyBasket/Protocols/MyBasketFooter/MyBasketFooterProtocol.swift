//
//  MyBasketFooterProtocol.swift
//  MealzIOSFramework
//
//  Created by Diarmuid McGonagle on 08/04/2024.
//


import Foundation
import SwiftUI
import mealzcore

@available(iOS 14, *)
public protocol MyBasketFooterProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MyBasketFooterParameters) -> Content
}

@available(iOS 14, *)
public struct MyBasketFooterParameters {
    public let totalPrice: Double
    public let heightOfFooter: CGFloat
    public let basketStatus: ComponentUiState
    public let submitOrder: () -> Void
    
    public init(
        totalPrice: Double,
        heightOfFooter: CGFloat,
        basketStatus: ComponentUiState,
        submitOrder: @escaping () -> Void
    ) {
        self.totalPrice = totalPrice
        self.heightOfFooter = heightOfFooter
        self.basketStatus = basketStatus
        self.submitOrder = submitOrder
    }
}
