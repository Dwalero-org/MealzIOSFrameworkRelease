//
//  MyBasketSwapperProtocol.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 25/03/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public protocol MyBasketSwapperProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MyBasketSwapperParameters) -> Content
}

@available(iOS 14, *)
public struct MyBasketSwapperParameters {
    @Binding public var selection: SelectedMyBasketPage
    
    public init(selection: Binding<SelectedMyBasketPage>) {
        _selection = selection
    }
}
