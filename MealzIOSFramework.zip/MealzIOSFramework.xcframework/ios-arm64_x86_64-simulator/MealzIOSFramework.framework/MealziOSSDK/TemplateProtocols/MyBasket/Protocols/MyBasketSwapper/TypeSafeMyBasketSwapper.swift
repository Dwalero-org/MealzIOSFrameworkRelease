//
//  TypeSafeMyBasketSwapper.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 25/03/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public struct TypeSafeMyBasketSwapper: MyBasketSwapperProtocol {
    private let _content: (MyBasketSwapperParameters) -> AnyView

    public init<T: MyBasketSwapperProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MyBasketSwapperParameters) -> some View {
        _content(params)
    }
}
