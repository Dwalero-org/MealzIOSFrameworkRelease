//
//  CatalogRecipesList.swift
//
//
//  Created by didi on 08/08/2023.
//

import SwiftUI
import mealzcore

/**
 An CatalogRecipesList that shows recipes for users to select
 
 Mandatory Parameters:
 - params:  An implementation of ``CatalogRecipesListParametersProtocol``
 - title: String -> The title of the search (whether it be filter or a catagory or a search)
 - subtitle: String? -> The subtitle of the search IF it exists
 - gridConfig:  An implementation of ``CatalogRecipesListGridConfig`` which has the view constraints like spacing & number of columnds
 - catalogContent: CatalogContent -> Content taken from the CatalogViewController to display what was searched on NoResults page
 - filterInstance: FilterInstance -> The instance of the FilterViewModel used on this recipes list
 
 Optional Parameters:
 - categoryId: String? -> If the Recipes should all correspond to one specific package or catagory
 
 */
@available(iOS 14, *)
struct CatalogRecipesList<
    RecipesListParameters: CatalogRecipesListParametersProtocol
>: View {
    private let params: RecipesListParameters
    @ObservedObject private var recipePageViewModel: RecipePageVM
    let catalogContent: CatalogContent
    let gridConfig: CatalogRecipesListGridConfig
    let title: String
    let subtitle: String?
    private let filterInstance: FilterInstance
    
    public init(
        params: RecipesListParameters,
        title: String,
        categorySubtitle: String?,
        gridConfig: CatalogRecipesListGridConfig,
        catalogContent: CatalogContent,
        filterInstance: FilterInstance,
        categoryId: String? = nil
    ) {
        self.params = params
        self.catalogContent = catalogContent
        self.gridConfig = gridConfig
        self.title = title
        self.subtitle = categorySubtitle
        self.filterInstance = filterInstance
        
        if let categoryId {
            self.recipePageViewModel = RecipePageVM(
                filterInstance: filterInstance,
                categoriesId: categoryId
            )
        } else {
            self.recipePageViewModel = RecipePageVM(
                filterInstance: filterInstance
            )
        }
    }
    
    public var body: some View {
        UIStateWrapperView(uiState: recipePageViewModel.state?.recipes) {
            params.loading.content(params: BaseLoadingParameters())
        } emptyView: {
            params.noResults.content(
                params: CatalogRecipesListNoResultsParameters(
                    catalogContent: catalogContent,
                    searchText: filterInstance.viewModel.currentState.searchString ?? "",
                    onNoResultsRedirect: params.actions.onNoResultsRedirect)
            )
        } successView: {
            successContent()
        }
    }
    
    func successContent() -> some View {
        ScrollView(showsIndicators: false) {
            params.title.content(
                params: TitleParameters(
                title: title,
                subtitle: subtitle ?? ""
                )
            )
            LazyVGrid(
                columns: Array(
                    repeating: GridItem(.flexible()),
                    count: gridConfig.numberOfColumns)
            ) {
                ForEach(recipePageViewModel.recipes, id: \.self) { recipe in
                    CatalogRecipeCard(
                        recipe.id,
                        recipeCardDimensions: gridConfig.recipeCardDimensions,
                        cardTemplate: params.recipeCard,
                        loadingTemplate: params.recipeCardLoading,
                        onShowRecipeDetails: params.actions.onShowRecipeDetails,
                        onCallToAction: params.actions.onRecipeCallToActionTapped)
                    .id(recipe.id)
                    .padding(.horizontal, gridConfig.spacing.width)
                    .padding(.vertical, gridConfig.spacing.height)
                    .onAppear {
                        recipePageViewModel.loadPage()
                    }
                }
            }
            if recipePageViewModel.isFetchingNewPage {
                params.loading.content(params: BaseLoadingParameters())
            }
        }
    }
}
