//
//  CatalogRecipesListNoResultsProtocol.swift
//
//
//  Created by didi on 10/08/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for Catalog Recipes List No Results.
 
 - catalogContent: CatalogContent -> The type of catalog content that was search, like .favorites, or .filter
 - searchText: String -> The search string from Filters
 - onNoResultsRedirect: () -> Void: A closure that can be used to navigate the user to another page, such as the Catalog
 
 */
@available(iOS 14, *)
public protocol CatalogRecipesListNoResultsProtocol {
    associatedtype Content: View
    func content(params: CatalogRecipesListNoResultsParameters) -> Content
}

public struct CatalogRecipesListNoResultsParameters {
    public let catalogContent: CatalogContent
    public let searchText: String
    public let onNoResultsRedirect: () -> Void
    
    public init(
        catalogContent: CatalogContent, 
        searchText: String,
        onNoResultsRedirect: @escaping () -> Void
    ) {
        self.catalogContent = catalogContent
        self.searchText = searchText
        self.onNoResultsRedirect = onNoResultsRedirect
    }
}
