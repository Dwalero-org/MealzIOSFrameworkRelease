//
//  CatalogRecipesListParametersProtocol.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Favorites Page.
 
 - title:  An implementation of ``BaseTitleProtocol``
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - noResults:  An implementation of ``CatalogRecipesListNoResultsProtocol``
 - loading: An implementation of ``LoadingProtocol``

 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onNoResultsRedirect: () -> Void: A closure that can be used to navigate users somewhere else if their search or filter has no results
 - onRecipeCallToActionTapped: (String) -> Void: A closure that executes the callback in the recipeCard CTA. 
 This is often a navigation to the Basket, but it can also be used on MealPlanner to navigate back to the MealPlanner Results
 
 */
@available(iOS 14, *)
public protocol CatalogRecipesListParametersProtocol {
    associatedtype Title: BaseTitleProtocol
    associatedtype RecipeCardContent: CatalogRecipeCardProtocol
    associatedtype RecipeLoading: RecipeCardLoadingProtocol
    associatedtype NoResults: CatalogRecipesListNoResultsProtocol
    associatedtype Loading: LoadingProtocol
    
    var title: Title { get }
    var recipeCard: RecipeCardContent { get }
    var recipeCardLoading: RecipeLoading { get }
    var noResults: NoResults { get }
    var loading: Loading { get }
    
    var actions: CatalogRecipesListActions { get set }
}

public struct CatalogRecipesListActions {
    var onShowRecipeDetails: (String) -> Void
    var onNoResultsRedirect: () -> Void
    var onRecipeCallToActionTapped: (String) -> Void
    
    public init(
        onShowRecipeDetails: @escaping (String) -> Void, 
        onNoResultsRedirect: @escaping () -> Void,
        onRecipeCallToActionTapped: @escaping (String) -> Void
    ) {
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onNoResultsRedirect = onNoResultsRedirect
        self.onRecipeCallToActionTapped = onRecipeCallToActionTapped
    }
}
