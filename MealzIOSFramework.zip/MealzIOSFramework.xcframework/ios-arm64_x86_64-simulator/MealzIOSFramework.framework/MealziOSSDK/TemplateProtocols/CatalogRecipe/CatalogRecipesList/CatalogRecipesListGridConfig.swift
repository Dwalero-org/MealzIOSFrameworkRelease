//
//  CatalogRecipesListGridConfig.swift
//  
//
//  Created by didi on 29/09/2023.
//

import SwiftUI

/**
 Configuration for the grid constraints of the CatalogRecipes List
 
 Mandatory Parameters:
 - numberOfColumns: Int -> The number of columns, should usually only be 1-3
 - spacing: CGSize -> The vertical & horizontal space between each recipe. ex: CGSize(width: 6, height: 5)
 - recipeCardDimensions: CGSize -> The width & height of each recipeCard
 
 Optional Parameters:
 - recipeCardFillMaxWidth: Bool = false -> If true, this will set the width to max amount based on the number of columns & padding. If false, it has no impact
 
 */
@available(iOS 14, *)
public struct CatalogRecipesListGridConfig {
    let numberOfColumns: Int
    let spacing: CGSize
    let recipeCardDimensions: CGSize
    
    public init(
        numberOfColumns: Int = 2,
        spacing: CGSize  = CGSize(width: 4, height: 4),
        recipeCardDimensions: CGSize = CGSize(width: 300, height: 380),
        recipeCardFillMaxWidth: Bool = true
    ) {
        self.numberOfColumns = numberOfColumns
        self.spacing = spacing
        // allow the recipe cards to take up the entire space
        if recipeCardFillMaxWidth {
            let width = (Int(UIScreen.main.bounds.width) / numberOfColumns) - Int(spacing.width * 2)
            self.recipeCardDimensions = CGSize(width: Double(width), height: recipeCardDimensions.height)
        } else {
            self.recipeCardDimensions = recipeCardDimensions
        }
    }
}
