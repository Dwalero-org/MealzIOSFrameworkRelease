//
//  CatalogRecipeCard.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore
import Combine

/**
 A CatalogRecipeCardView that handles the different states of the RecipeCardViewModel.
 
 Mandatory Parameters:
 [
 - recipeId: String -> The id of the Recipe that the view will display
 OR
 - recipe: Recipe -> The Recipe that the view will display
 ]
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - onAddToBasket: (String) -> Void: A closure that executes the function in the "Call To Action" of the recipe card. This is usally "add to basket", so the navigation is to the Basket
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 
 Optional Parameters:
 - numberOfGuests: Int -> optional parameter that will be passed into Price View Model to get the correct price for each Recipe. Created for Meal Planner
 - addToBasket: Bool = true -> A bool, that is default set to true, that will automatically add the recipe ingredients to the user basket. It is only FALSE when using the MealPlanner
 
 */
@available(iOS 14, *)
public struct CatalogRecipeCard<
    CardTemplate: CatalogRecipeCardProtocol,
    LoadingTemplate: RecipeCardLoadingProtocol
>: View {
    private let recipeId: String?
    public var recipe: Recipe?
    private let criteria: SuggestionsCriteria?
    private let recipeCardDimensions: CGSize
    private let cardTemplate: CardTemplate
    private let loadingTemplate: LoadingTemplate
    private let onCallToAction: (String) -> Void
    private let onShowRecipeDetails: (String) -> Void
    @StateObject var recipeViewModel: RecipeCardVM = RecipeCardVM()
    
    @SwiftUI.State private var timer: Cancellable? // used for analytics
    
    /// Initializer with string RecipeId
    /// - Parameters:
    ///   - recipeId: The id of the Recipe that the view will display
    ///   - numberOfGuests: optional parameter that will be passed into Price View Model to get the correct price for each Recipe. Created for Meal Planner
    ///   - cardTemplate: The template for the Recipe Card.
    ///   - loadingTemplate: The template when the Recipe Card is loading.
    ///   - onShowRecipeDetails: A closure that is called when the recipe card is tapped. This should navigate to the RecipeDetails page
    ///   - onCallToAction: A closure that is called when the add button is pressed. This should navigate back to the MealPlanner page.
    public init(
        _ recipeId: String,
        numberOfGuests: Int? = nil,
        recipeCardDimensions: CGSize,
        cardTemplate: CardTemplate,
        loadingTemplate: LoadingTemplate,
        onShowRecipeDetails: @escaping (String) -> Void,
        onCallToAction: @escaping (String) -> Void
    ) {
        self.cardTemplate = cardTemplate
        self.loadingTemplate = loadingTemplate
        self.onCallToAction = onCallToAction
        self.onShowRecipeDetails = onShowRecipeDetails
        self.recipeId = recipeId
        self.recipeCardDimensions = recipeCardDimensions
        self.criteria = nil
    }
    
    /// Initializer with Recipe object
    /// - Parameters:
    ///   - recipe: The Recipe that the view will display
    ///   - numberOfGuests: optional parameter that will be passed into Price View Model to get the correct price for each Recipe. Created for Meal Planner
    ///   - cardTemplate: The template for the Recipe Card.
    ///   - loadingTemplate: The template when the Recipe Card is loading.
    ///   - onShowRecipeDetails: A closure that is called when the recipe card is tapped. This should navigate to the RecipeDetails page
    ///   - onCallToAction: A closure that is called when the add button is pressed. This should navigate back to the MealPlanner page.
    public init(
        _ recipe: Recipe,
        numberOfGuests: Int? = nil,
        recipeCardDimensions: CGSize,
        cardTemplate: CardTemplate,
        loadingTemplate: LoadingTemplate,
        onShowRecipeDetails: @escaping (String) -> Void,
        onCallToAction: @escaping (String) -> Void
    ) {
        self.cardTemplate = cardTemplate
        self.loadingTemplate = loadingTemplate
        self.onCallToAction = onCallToAction
        self.onShowRecipeDetails = onShowRecipeDetails
        self.recipeId = recipe.id
        self.recipeCardDimensions = recipeCardDimensions
        self.recipe = recipe
        self.criteria = nil
    }
    
    /// Initializer with Recipe object
    /// - Parameters:
    ///   - recipe: The Recipe that the view will display
    ///   - numberOfGuests: optional parameter that will be passed into Price View Model to get the correct price for each Recipe. Created for Meal Planner
    ///   - cardTemplate: The template for the Recipe Card.
    ///   - loadingTemplate: The template when the Recipe Card is loading.
    ///   - onShowRecipeDetails: A closure that is called when the recipe card is tapped. This should navigate to the RecipeDetails page
    ///   - onCallToAction: A closure that is called when the add button is pressed. This should navigate back to the MealPlanner page.
    public init(
        criteria: SuggestionsCriteria,
        numberOfGuests: Int? = nil,
        recipeCardDimensions: CGSize,
        cardTemplate: CardTemplate,
        loadingTemplate: LoadingTemplate,
        onShowRecipeDetails: @escaping (String) -> Void,
        onCallToAction: @escaping (String) -> Void
    ) {
        self.cardTemplate = cardTemplate
        self.loadingTemplate = loadingTemplate
        self.onCallToAction = onCallToAction
        self.onShowRecipeDetails = onShowRecipeDetails
        self.criteria = criteria
        self.recipeCardDimensions = recipeCardDimensions
        self.recipe = nil
        self.recipeId = nil
    }
    
    public var body: some View {
        VStack {
            UIStateWrapperView(uiState: recipeViewModel.state?.recipeState) {
                loadingTemplate.content(params: RecipeCardLoadingParameters( recipeCardDimensions: recipeCardDimensions)
                )
            } emptyView: {
            } successView: {
                if let recipe = recipeViewModel.recipe {
                    cardTemplate.content(
                        params: CatalogRecipeCardParameters(
                            recipeCardDimensions: recipeCardDimensions,
                            recipe: recipe,
                            recipePrice: recipe.attributes?.price?.pricePerServe ?? 12.0,
                            numberOfGuests: recipeViewModel.numberOfGuests ?? Int(recipe.attributes?.numberOfGuests ?? 4),
                            isCurrentlyInBasket: recipeViewModel.currentState.isInCart,
                            onAddToBasket: { recipeId in
                                recipeViewModel.goToDetails()
                                onCallToAction(recipeId)
                            },
                            onShowRecipeDetails: { recipeId in
                                recipeViewModel.goToDetails()
                                onShowRecipeDetails(recipeId)
                            }
                        )
                    )
                    .onAppear {
                        timer?.cancel() // Cancel any existing timer when the view appears
                        timer = DispatchQueue.schedule(after: 1) {
                            recipeViewModel.sendAnalyticsImpression()
                        }
                    }
                    .onDisappear {
                        timer?.cancel() // Cancel analytics if the view disappears before 1 second
                    }
                }
            }
        }
        .onAppear {
            recipeViewModel.registerListeners()
            if let recipeId, recipeViewModel.recipe == nil {
                recipeViewModel.setEvent(event: RecipeContractEvent.FetchRecipeFromId(recipeId: recipeId))
            } else if let criteria {
                recipeViewModel.setEvent(event: RecipeContractEvent.FetchRecipeFromCriteria(criteria: criteria))
            }
        }
        .onDisappear {
           recipeViewModel.dispose()
        }
    }
}
