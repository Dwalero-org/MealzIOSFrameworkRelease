//
//  TypeSafeCatalogRecipeCard.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafeCatalogRecipeCard: CatalogRecipeCardProtocol {
    private let _content: (CatalogRecipeCardParameters) -> AnyView

    public init<T: CatalogRecipeCardProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: CatalogRecipeCardParameters) -> some View {
        _content(params)
    }
}
