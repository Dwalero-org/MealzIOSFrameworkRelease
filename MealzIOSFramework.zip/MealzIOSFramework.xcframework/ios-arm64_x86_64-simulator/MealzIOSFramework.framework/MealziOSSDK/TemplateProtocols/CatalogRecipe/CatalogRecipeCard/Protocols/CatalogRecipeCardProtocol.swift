//
//  CatalogRecipeCardProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the CatalogRecipeCard.
 
 - recipeCardDimensions: CGSize -> the width & height of the recipe card
 - recipe: Recipe -> The Recipe object of the current Recipe Card
 - recipePrice: Double -> The price of the Recipe, which updates when it is added to the baket
 - numberOfGuests: Int -> The number of guests that are in the recipe
 - isCurrentlyInBasket: Bool -> Boolean on whether the Recipe is currently in the basket. This can change the CTA text
 - onAddToBasket: (String) -> Void: A closure that executes the function in the "Call To Action" of the recipe card. This is usally "add to basket", so the navigation is to the Basket
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId

 */
@available(iOS 14, *)
public protocol CatalogRecipeCardProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: CatalogRecipeCardParameters) -> Content
}

public struct CatalogRecipeCardParameters {
    public var recipeCardDimensions: CGSize
    public var recipe: Recipe
    public var recipePrice: Double
    public var numberOfGuests: Int
    public var isCurrentlyInBasket: Bool
    public var onAddToBasket: (String) -> Void
    public var onShowRecipeDetails: (String) -> Void
    
    public init(
        recipeCardDimensions: CGSize,
        recipe: Recipe,
        recipePrice: Double,
        numberOfGuests: Int,
        isCurrentlyInBasket: Bool,
        onAddToBasket: @escaping (String) -> Void,
        onShowRecipeDetails: @escaping (String) -> Void
    ) {
        self.recipeCardDimensions = recipeCardDimensions
        self.recipe = recipe
        self.recipePrice = recipePrice
        self.numberOfGuests = numberOfGuests
        self.isCurrentlyInBasket = isCurrentlyInBasket
        self.onAddToBasket = onAddToBasket
        self.onShowRecipeDetails = onShowRecipeDetails
    }
}
