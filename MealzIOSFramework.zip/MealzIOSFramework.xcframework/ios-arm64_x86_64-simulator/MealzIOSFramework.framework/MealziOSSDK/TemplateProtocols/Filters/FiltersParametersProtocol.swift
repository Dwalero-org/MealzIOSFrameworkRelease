//
//  FiltersParametersProtocol.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for filters.
 
 - header:  An implementation of ``FiltersHeaderProtocol``
 - section:  An implementation of ``FiltersSectionProtocol``
 - callToAction:  An implementation of ``FiltersCTAProtocol``
 - background: An implementation of ``BackgroundProtocol``
 - onClosed: () -> Void: A closure that is triggered when the filters page is closed, this should navigate back to the Catalog Page
 - onApplied: () -> Void: A closure that updates the Filters Singleton & closes the page, this should navigate to the Catalog Results Page
 
 */
@available(iOS 14, *)
public protocol FiltersParametersProtocol {
    associatedtype Header: FiltersHeaderProtocol
    associatedtype Section: FiltersSectionProtocol
    associatedtype CallToAction: FiltersCTAProtocol
    associatedtype Background: BackgroundProtocol

    /// An implementation of ``FiltersHeaderProtocol``
    var header: Header { get }
    /// An implementation of ``FiltersSectionProtocol``
    var section: Section { get }
    /// An implementation of ``FiltersCTAProtocol``
    var callToAction: CallToAction { get }
    /// An implementation of ``BackgroundProtocol``
    var background: Background { get }
    
    /// A closure that closes the Filters page.
    var actions: FiltersActions { get set }
}

public struct FiltersActions {
    var onClosed: () -> Void
    var onApplied: () -> Void
    
    public init(onClosed: @escaping () -> Void, onApplied: @escaping () -> Void) {
        self.onClosed = onClosed
        self.onApplied = onApplied
    }
}
