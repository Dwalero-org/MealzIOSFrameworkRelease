//
//  Filters.swift
//
//
//  Created by didi on 07/08/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Filters page where users can sort recipes based on time, price, & difficulty.
 
 Mandatory Parameters:
 - params:  An implementation of ``FiltersParametersProtocol``, usually the default ``FiltersParamaters``
 - filterInstance:  A ``FilterInstance``. This will usually be passed in by the button that launches it.
 
 Optional Parameters:
 - difficultyText: String -> difficulty string where default is Miam localized
 - costText:  String -> cost string where default is Miam localized
 - timeText:  String -> time string where default is Miam localized
 
 */
@available(iOS 14, *)
public struct Filters<
    FiltersParameters: FiltersParametersProtocol
>: View {
    private let params: FiltersParameters
    /// Optional param for difficulty -> default is Miam localized
    public let difficultyText: String
    /// Optional param for cost -> default is Miam localized
    public let costText: String
    /// Optional param for time -> default is Miam localized
    public let timeText: String
    /// Used to close the entire Filters page
    @ObservedObject var filterViewModel: FiltersVM
    
    public init(
        params: FiltersParameters,
        filterInstance: FilterInstance,
        difficultyText: String = Localization.catalog.difficulty.localised,
        costText: String = Localization.catalog.costPerPerson.localised,
        timeText: String = Localization.catalog.preparationTime.localised
    ) {
        self.params = params
        self.filterViewModel = FiltersVM(filterInstance: filterInstance)
        self.difficultyText = difficultyText
        self.costText = costText
        self.timeText = timeText
    }
    
    private func onApplyFilters(){
        self.filterViewModel.applyFilter()
        params.actions.onApplied()
    }
    
    public var body: some View {
        ZStack {
            params.background.content(params: BaseBackgroundParameters())
            ScrollView {
                VStack {
                    params.header.content(params: FiltersHeaderParameters(onCloseFilters: params.actions.onClosed))
                    params.section.content(
                        params: FiltersSectionParameters(
                            title: difficultyText,
                            filters: filterViewModel.difficulty,
                            onFilterSelected: { option in
                                option.toogle()
                                filterViewModel.setEvent(
                                    event: FilterContractEvent.OnDifficultyChanged(difficulty: option)
                                )
                            })
                    )
                    params.section.content(
                        params: FiltersSectionParameters(
                            title: costText,
                            filters: filterViewModel.cost,
                            onFilterSelected: { option in
                                option.toogle()
                                filterViewModel.setEvent(
                                    event: FilterContractEvent.OnCostFilterChanged(costFilter: option)
                                )
                            })
                    )
                    params.section.content(
                        params: FiltersSectionParameters(
                            title: timeText,
                            filters: filterViewModel.time,
                            onFilterSelected: { option in
                                option.toogle()
                                filterViewModel.setEvent(
                                    event: FilterContractEvent.OnTimeFilterChanged(timeFilter: option)
                                )
                            })
                    )
                    params.callToAction.content(
                        params: FiltersCTAParameters(
                            numberOfRecipes: filterViewModel.numberOfRecipes,
                            onApply: { params.actions.onApplied()},
                            onClear: { filterViewModel.clear() })
                    )
                }.padding(Dimension.sharedInstance.lPadding)
            }
        }
    }
}
