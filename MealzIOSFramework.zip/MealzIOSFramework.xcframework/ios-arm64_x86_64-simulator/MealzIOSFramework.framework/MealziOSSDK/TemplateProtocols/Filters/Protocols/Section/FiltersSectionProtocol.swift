//
//  FiltersSectionProtocol.swift
//  
//
//  Created by didi on 19/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the title & options for each CatalogFilterOption. These options are the difficulty, time, & price per person.
 
 - title: String ->  The name of the section, usually Difficulty, Time, etc
 - filters: [CatalogFilterOptions] -> The options for the current FilterOption. ex: Easy, Medium
 - onFilterSelected: (CatalogFilterOptions) -> Void: A closure that selects this filter option. Multiple options can be selected at the same time
 */
@available(iOS 14, *)
public protocol FiltersSectionProtocol {
    associatedtype Content: View
    func content(params: FiltersSectionParameters) -> Content
}

public struct FiltersSectionParameters {
    public let title: String
    public let filters: [CatalogFilterOptions]
    public let onFilterSelected: (CatalogFilterOptions) -> Void
 
    public init(title: String, filters: [CatalogFilterOptions], onFilterSelected: @escaping (CatalogFilterOptions) -> Void) {
        self.title = title
        self.filters = filters
        self.onFilterSelected = onFilterSelected
    }
}
