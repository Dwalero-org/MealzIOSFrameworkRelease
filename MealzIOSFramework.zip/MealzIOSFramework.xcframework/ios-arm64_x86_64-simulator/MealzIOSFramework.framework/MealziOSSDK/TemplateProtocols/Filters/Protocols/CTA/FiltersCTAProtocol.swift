//
//  FiltersCTAProtocol.swift
//  
//
//  Created by didi on 07/08/2023.
//

import SwiftUI

/**
 A protocol defining the call to action on the Filters Page. This has two buttons, one to clear & another to apply
 
 - numberOfRecipes: Int ->  The number of recipes available for the current search
 - onApply: () -> Void -> A closure that applies the current filters & closes the page
 - onClear: () -> Void -> A closure that clears the current filters
 */
@available(iOS 14, *)
public protocol FiltersCTAProtocol {
    associatedtype Content: View
    func content(params: FiltersCTAParameters) -> Content
}

public struct FiltersCTAParameters {
    public let numberOfRecipes: Int
    public let onApply: () -> Void
    public let onClear: () -> Void
 
    public init(numberOfRecipes: Int, onApply: @escaping () -> Void, onClear: @escaping () -> Void) {
        self.numberOfRecipes = numberOfRecipes
        self.onApply = onApply
        self.onClear = onClear
    }
}
