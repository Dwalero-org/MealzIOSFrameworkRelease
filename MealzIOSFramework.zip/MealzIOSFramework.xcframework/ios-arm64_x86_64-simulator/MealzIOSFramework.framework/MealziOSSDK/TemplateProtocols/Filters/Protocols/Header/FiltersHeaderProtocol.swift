//
//  FiltersHeaderProtocol.swift
//  
//
//  Created by didi on 07/08/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the header on the Filters Page. This has one button to close the page
 
 - onCloseFilters: @escaping () -> Void -> A closure that applies closes the page
 */
@available(iOS 14, *)
public protocol FiltersHeaderProtocol {
    associatedtype Content: View
    func content(params: FiltersHeaderParameters) -> Content
}

public struct FiltersHeaderParameters {
    public let onCloseFilters: () -> Void
    
    public init(onCloseFilters: @escaping () -> Void) {
        self.onCloseFilters = onCloseFilters
    }
}
