//
//  RecipeCarousel.swift
//  
//
//  Created by didi on 16/10/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Recipe Carousel where users can see a horizontal scroll of recipes.

 Mandatory Parameters:
 - params:  An implementation of ``RecipeCarouselParametersProtocol``, usually the default ``RecipeCarouselParameters``.
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 - numberOfResults: Int: The amount of recipes the Client is looking to return.
 
 **Exclusive Parameters (Choose one)**:
 - productId: String - If you would like all the recipes to be based off a product (like Peanut Butter), pass in a productId.
 - criteria: SuggestionsCriteria - If you would like all the recipes to be from a SuggestionCriteria (like the products in your basket, on the page, or in a search result).

 **Note**: Only one of `productId` or `criteria` should be provided.

 */
@available(iOS 14, *)
public struct RecipeCarousel<
    RecipeCarouselParameters: RecipeCarouselParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: RecipeCarouselParameters
    private let baseViews: BaseViews
    public let gridConfig: RecipesCarouselGridConfig
    private var productId: String? = nil
    private var criteria: SuggestionsCriteria? = nil
    private let numberOfResults: Int
    
    @ObservedObject private var recipeCarouselVM: RecipeCarouselVM = RecipeCarouselVM()
    
    public init(
        params: RecipeCarouselParameters,
        baseViews: BaseViews,
        gridConfig: RecipesCarouselGridConfig,
        numberOfResults: Int,
        productId: String
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        self.numberOfResults = numberOfResults
        self.productId = productId
    }
    
    public init(
        params: RecipeCarouselParameters,
        baseViews: BaseViews,
        gridConfig: RecipesCarouselGridConfig,
        numberOfResults: Int,
        criteria: SuggestionsCriteria
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        self.numberOfResults = numberOfResults
        self.criteria = criteria
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: recipeCarouselVM.state?.suggestions) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                baseViews.empty.content(params: BaseEmptyParameters())
            }
            successView: {
                successContent()
            }
            .onAppear {
                if recipeCarouselVM.suggestions.isEmpty { // prevent calling on every onAppear
                    if let productId {
                        recipeCarouselVM.setEvent(event: RecipeCarouselContractEvent.GetRecipeSuggestionsFromId(
                            productId: productId,
                            numberOfResult: Int32(numberOfResults)))
                    } else if let criteria {
                        recipeCarouselVM.setEvent(event: RecipeCarouselContractEvent.GetRecipeSuggestionsFromCriteria(
                            criteria: criteria,
                            numberOfResult: Int32(numberOfResults)))
                    }
                }
                recipeCarouselVM.registerListeners()
            }
            .onDisappear(perform: { recipeCarouselVM.dispose()})
        }
    }
    
    func successContent() -> some View {
        ScrollView(.horizontal, showsIndicators: gridConfig.showsIndicators) {
            LazyHGrid(
                rows: Array(
                    repeating: GridItem(.fixed(gridConfig.recipeCardDimensions.height)),
                    count: gridConfig.numberOfRows),
                spacing: 0
            ) {
                ForEach(recipeCarouselVM.suggestions, id: \.self) { recipe in
                    CatalogRecipeCard(
                        recipe.id,
                        recipeCardDimensions: gridConfig.recipeCardDimensions,
                        cardTemplate: params.recipeCard,
                        loadingTemplate: params.recipeCardLoading,
                        onShowRecipeDetails: params.actions.onShowRecipeDetails,
                        onCallToAction: params.actions.onRecipeCallToActionTapped)
                    .id(recipe.id)
                    .padding(.vertical, gridConfig.spacing.height)
                    .padding(.horizontal, gridConfig.spacing.width)
                }
            }
        }
    }
}

