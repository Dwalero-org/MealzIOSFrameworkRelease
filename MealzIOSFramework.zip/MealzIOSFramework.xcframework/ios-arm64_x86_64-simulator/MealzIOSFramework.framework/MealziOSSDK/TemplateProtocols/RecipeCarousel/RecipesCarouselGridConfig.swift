//
//  RecipesCarouselGridConfig.swift
//  
//
//  Created by didi on 16/10/2023.
//

import SwiftUI

/**
 Configuration for the grid constraints of the Recipes Carousel
 
 Mandatory Parameters:
 - numberOfRows: Int -> The number of rows, should usually only be 1-3
 - spacing: CGSize -> The vertical & horizontal space between each recipe. ex: CGSize(width: 5, height: 5)
 - recipeCardDimensions: CGSize -> The width & height of each recipeCard
 
 Optional Parameters:
 - recipeCardFillMaxWidth: Bool = false -> If true, this will set the width to max amount based on the number of rows & padding. If false, it has no impact
 - showsIndicators: Bool = true -> This will show the scroll indicators on the ScrollView for the RecipeCarousel
 
 */
@available(iOS 14, *)
public struct RecipesCarouselGridConfig {
    let numberOfRows: Int
    let spacing: CGSize
    let recipeCardDimensions: CGSize
    let showsIndicators: Bool
    
    public init(
        numberOfRows: Int = 1,
        spacing: CGSize = CGSize(width: 6, height: 6),
        recipeCardDimensions: CGSize = CGSize(width: 200, height: 320),
        recipeCardFillMaxWidth: Bool = false,
        showsIndicators: Bool = true
    ) {
        self.numberOfRows = numberOfRows
        self.spacing = spacing
        // allow the recipe cards to take up the entire space
        if recipeCardFillMaxWidth {
            let width = (Int(UIScreen.main.bounds.width)) - Int(spacing.width)
            self.recipeCardDimensions = CGSize(width: Double(width), height: recipeCardDimensions.height)
        } else {
            self.recipeCardDimensions = recipeCardDimensions
        }
        self.showsIndicators = showsIndicators
    }
}
