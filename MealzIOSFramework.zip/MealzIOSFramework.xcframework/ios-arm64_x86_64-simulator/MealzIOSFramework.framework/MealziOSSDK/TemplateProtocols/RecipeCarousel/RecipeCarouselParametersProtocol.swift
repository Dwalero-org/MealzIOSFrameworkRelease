//
//  RecipeCarouselParametersProtocol.swift
//  
//
//  Created by didi on 16/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Recipe Carousel.
 
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - loading: An implementation of ``LoadingProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onRecipeCallToActionTapped: (String) -> Void: A closure that activates the CTA on the Recipe Card. This usually adds it to the Basket & navigates to the basket.
 
 */
@available(iOS 14, *)
public protocol RecipeCarouselParametersProtocol {
    associatedtype RecipeCardContent: CatalogRecipeCardProtocol
    associatedtype RecipeLoading: RecipeCardLoadingProtocol
    
    var recipeCard: RecipeCardContent { get }
    var recipeCardLoading: RecipeLoading { get }
    
    var actions: RecipeCarouselActions { get set }
}

public struct RecipeCarouselActions {
    var onShowRecipeDetails: (String) -> Void
    var onRecipeCallToActionTapped: (String) -> Void
    
    public init(onShowRecipeDetails: @escaping (String) -> Void, onRecipeCallToActionTapped: @escaping (String) -> Void) {
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onRecipeCallToActionTapped = onRecipeCallToActionTapped
    }
}
