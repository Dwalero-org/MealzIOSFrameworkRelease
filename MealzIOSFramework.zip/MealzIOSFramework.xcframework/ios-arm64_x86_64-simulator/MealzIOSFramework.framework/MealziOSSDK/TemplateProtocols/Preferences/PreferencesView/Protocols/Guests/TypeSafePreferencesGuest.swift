//
//  TypeSafePreferencesGuest.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafePreferencesGuest: PreferencesGuestProtocol {
    private let _content: (PreferencesGuestParameters) -> AnyView

    public init<T: PreferencesGuestProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: PreferencesGuestParameters) -> some View {
        _content(params)
    }
}
