//
//  TypeSafePreferencesDiet.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafePreferencesDiet: PreferencesDietProtocol {
    private let _content: (PreferencesDietParameters) -> AnyView

    public init<T: PreferencesDietProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: PreferencesDietParameters) -> some View {
        _content(params)
    }
}
