//
//  PreferencesDietProtocol.swift
//  
//
//  Created by didi on 22/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the diet section of the Preferences.
 
 - dietsTag: [CheckableTag] -> The differerent types of diet (like Vegetarian)
 - onTogglePreference:  (String) -> Void: A closure that selects this diet option. Multiple options can be selected at the same time
 
 */
@available(iOS 14, *)
public protocol PreferencesDietProtocol {
    associatedtype Content: View
    func content(params: PreferencesDietParameters) -> Content
}

public struct PreferencesDietParameters {
    public let dietsTag: [CheckableTag]
    public let onTogglePreference: (String) -> Void
 
    public init(dietsTag: [CheckableTag], onTogglePreference: @escaping (String) -> Void) {
        self.dietsTag = dietsTag
        self.onTogglePreference = onTogglePreference
    }
}
