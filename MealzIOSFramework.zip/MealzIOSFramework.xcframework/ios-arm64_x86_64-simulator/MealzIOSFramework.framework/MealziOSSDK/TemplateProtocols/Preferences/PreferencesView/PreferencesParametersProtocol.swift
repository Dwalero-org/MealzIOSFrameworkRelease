//
//  PreferencesParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import Foundation

/**
 A protocol defining the necessary parameters for the Preferences Page.
 
 - guestSection:  An implementation of ``PreferencesGuestProtocol``
 - dietSection:  An implementation of ``PreferencesDietProtocol``
 - ingredientsSection:  An implementation of ``PreferencesIngredientsProtocol``
 - equipmentSection:  An implementation of ``PreferencesEquipmentProtocol``
 - footer:  An implementation of ``PreferencesFooterProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onClosed: () -> Void: A closure used to close the entire Preferences page
 - onGoToSearch: () -> Void: A closure that will open the PreferencesView page where the user can search for items to add to the ingredients they wish to avoid
 
 */
@available(iOS 14, *)
public protocol PreferencesParametersProtocol {
    associatedtype GuestSection: PreferencesGuestProtocol
    associatedtype DietSection: PreferencesDietProtocol
    associatedtype IngredientsSection: PreferencesIngredientsProtocol
    associatedtype EquipmentSection: PreferencesEquipmentProtocol
    associatedtype Footer: PreferencesFooterProtocol

    var guestSection: GuestSection { get }
    var dietSection: DietSection { get }
    var ingredientsSection: IngredientsSection { get }
    var equipmentSection: EquipmentSection { get }
    var footer: Footer { get }
    
    var actions: PreferencesActions { get set }
}

public struct PreferencesActions {
    var onClosed: () -> Void
    var onGoToSearch: () -> Void
    
    public init(onClosed: @escaping () -> Void, onGoToSearch: @escaping () -> Void) {
        self.onClosed = onClosed
        self.onGoToSearch = onGoToSearch
    }
}
