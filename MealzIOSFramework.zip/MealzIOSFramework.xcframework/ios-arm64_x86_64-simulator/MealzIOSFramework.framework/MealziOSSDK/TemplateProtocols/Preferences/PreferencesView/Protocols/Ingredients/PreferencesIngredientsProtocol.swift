//
//  PreferencesIngredientsProtocol.swift
//  
//
//  Created by didi on 22/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the Ingredient section of the Preferences. Users can also search for ingredients to blacklist
 
 - ingredientsTag: [CheckableTag] -> The differerent types of ingredient (like Eggs)
 - geometry: GeometryProxy -> The geometry so that the users can tap a tag & apply it
 - onTogglePreference:  (String) -> Void: A closure that selects this ingredient option. Multiple options can be selected at the same time,
 - onGoToSearch: @escaping () -> Void: A closure that opens up the PreferencesSearch page where users can add more blacklisted ingredients
 
 */
@available(iOS 14, *)
public protocol PreferencesIngredientsProtocol {
    associatedtype Content: View
    func content(params: PreferencesIngredientsParameters) -> Content
}

@available(iOS 14, *)
public struct PreferencesIngredientsParameters {
    public let ingredientsTag: [CheckableTag]
    public let geometry: GeometryProxy
    public let onTogglePreference: (String) -> Void
    public let onGoToSearch: () -> Void

    public init(
        ingredientsTag: [CheckableTag],
        geometry: GeometryProxy,
        onTogglePreference: @escaping (String) -> Void,
        onGoToSearch: @escaping () -> Void
    ) {
        self.ingredientsTag = ingredientsTag
        self.geometry = geometry
        self.onTogglePreference = onTogglePreference
        self.onGoToSearch = onGoToSearch
    }
}
