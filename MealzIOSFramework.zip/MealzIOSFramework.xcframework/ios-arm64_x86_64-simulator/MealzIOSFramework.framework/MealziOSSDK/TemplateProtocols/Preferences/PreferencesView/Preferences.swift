//
//  Preferences.swift
//
//
//  Created by didi on 22/09/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Preferences page where users can apply filters like dietary restrictions, equipment, etc
 
 Mandatory Parameters:
 - params:  An implementation of ``PreferencesParametersProtocol``, usually the default ``PreferencesParameters``
 
 */
@available(iOS 14, *)
public struct Preferences<
    PreferencesParameters: PreferencesParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: PreferencesParameters
    private let baseViews: BaseViews
    
    public init(
        params: PreferencesParameters,
        baseViews: BaseViews
    ) {
        self.params = params
        self.baseViews = baseViews
    }
    
    @ObservedObject private var preferencesViewModel: PreferencesVM = PreferencesVM.sharedInstance
    
    private func onApplyPreferences() {
        self.preferencesViewModel.applyPreferences()
        params.actions.onClosed()
    }
    
    private func onClosePreferences() {
        self.preferencesViewModel.resetPreferences()
        params.actions.onClosed()
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: preferencesViewModel.state?.basicState) {
                baseViews.loading.content(params: BaseLoadingParameters())
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } emptyView: {
                baseViews.empty.content(params: BaseEmptyParameters())
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } successView: {
                successContent()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
    
    func setRecipesFound() -> Int? {
        if let recipesFoundValue = preferencesViewModel.state?.recipesFound {
            return Int(recipesFoundValue)
        } else { return nil }
    }
    
    func successContent() -> some View {
        ZStack(alignment: .bottom) {
            GeometryReader { geometry in
                ScrollView {
                    VStack(alignment: .leading) {
                        params.guestSection.content(
                            params: PreferencesGuestParameters(
                                guests: preferencesViewModel.guests,
                                onGuestChanged: { guestCount in
                                    preferencesViewModel.updateGuestsNumber(guestCount)
                                })
                        )
                        params.dietSection.content(
                            params: PreferencesDietParameters(
                                dietsTag: preferencesViewModel.diets,
                                onTogglePreference: { tagId in
                                    preferencesViewModel.togglePreferenceWithId(tagId)
                                })
                        )
                        params.ingredientsSection.content(
                            params: PreferencesIngredientsParameters(
                                ingredientsTag: preferencesViewModel.ingredients,
                                geometry: geometry,
                                onTogglePreference: { tagId in
                                    preferencesViewModel.togglePreferenceWithId(tagId)
                                },
                                onGoToSearch: params.actions.onGoToSearch)
                        )
                        params.equipmentSection.content(
                            params: PreferencesEquipmentParameters(
                                equipmentsTag: preferencesViewModel.equipments,
                                onTogglePreference: { tagId in
                                    preferencesViewModel.togglePreferenceWithId(tagId)
                                })
                        )
                    }
                    .padding(.bottom, 50)
                    .padding(Dimension.sharedInstance.sPadding)
                }
            }
            params.footer.content(
                params: PreferencesFooterParameters(
                    recipesFound: setRecipesFound(),
                    onApplied: onApplyPreferences,
                    onClosed: onClosePreferences)
            )
        }
        
    }
}
