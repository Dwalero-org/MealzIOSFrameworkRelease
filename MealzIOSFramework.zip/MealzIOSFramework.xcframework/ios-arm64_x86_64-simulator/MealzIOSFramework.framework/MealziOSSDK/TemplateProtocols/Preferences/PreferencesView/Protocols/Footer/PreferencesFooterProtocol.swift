//
//  PreferencesFooterProtocol.swift
//  
//
//  Created by didi on 22/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the Footer section of the Preferences.
 
 - recipesFound: Int? -> The number of recipes that will be returned based on the current criteria
 - onApplied:  () -> Void: A closure to apply the preferences & close the page
 - onClosed:  () -> Void: A closure to close the page without applying
 
 */
@available(iOS 14, *)
public protocol PreferencesFooterProtocol {
    associatedtype Content: View
    func content(params: PreferencesFooterParameters) -> Content
}

public struct PreferencesFooterParameters {
    public let recipesFound: Int?
    public let onApplied: () -> Void
    public let onClosed: () -> Void

    public init(recipesFound: Int? = nil, onApplied: @escaping () -> Void, onClosed: @escaping () -> Void) {
        self.recipesFound = recipesFound
        self.onApplied = onApplied
        self.onClosed = onClosed
    }
}
