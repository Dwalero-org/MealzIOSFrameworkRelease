//
//  PreferencesGuestProtocol.swift
//  
//
//  Created by didi on 22/09/2023.
//

import SwiftUI

/**
 A protocol defining the guest section of the Preferences.
 
 - guests: Int? -> The number of guests that the recipes will be optimizing for
 - onGuestChanged:  (Int) -> Void: A closure to update the number of guests
 
 */
@available(iOS 14, *)
public protocol PreferencesGuestProtocol {
    associatedtype Content: View
    func content(params: PreferencesGuestParameters) -> Content
}

public struct PreferencesGuestParameters {
    public let guests: Int?
    public let onGuestChanged: (Int) -> Void
 
    public init(guests: Int? = nil, onGuestChanged: @escaping (Int) -> Void) {
        self.guests = guests
        self.onGuestChanged = onGuestChanged
    }
}
