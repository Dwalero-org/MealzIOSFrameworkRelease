//
//  PreferencesEquipmentProtocol.swift
//  
//
//  Created by didi on 22/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the equipment section of the Preferences.
 
 - equipmentsTag: [CheckableTag] -> The differerent types of equipment (like Oven)
 - onTogglePreference:  (String) -> Void: A closure that selects this diet option. Multiple options can be selected at the same time
 */
@available(iOS 14, *)
public protocol PreferencesEquipmentProtocol {
    associatedtype Content: View
    func content(params: PreferencesEquipmentParameters) -> Content
}

public struct PreferencesEquipmentParameters {
    public let equipmentsTag: [CheckableTag]
    public let onTogglePreference: (String) -> Void
 
    public init(equipmentsTag: [CheckableTag], onTogglePreference: @escaping (String) -> Void) {
        self.equipmentsTag = equipmentsTag
        self.onTogglePreference = onTogglePreference
    }
}
