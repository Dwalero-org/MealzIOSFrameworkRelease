//
//  PreferencesSearchProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Preferences Search Page.
 
 - search:  An implementation of ``SearchProtocol``
 - tagButton:  An implementation of ``BaseButtonProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onClosed: () -> Void: A closure that applies the item & closes the page
 
 */
@available(iOS 14, *)
public protocol PreferencesSearchProtocol {
    associatedtype Search: SearchProtocol
    associatedtype TagButton: BaseButtonProtocol
    
    var search: Search { get }
    var tagButton: TagButton { get }
    
    var actions: PreferencesSearchActions { get set }
}

public struct PreferencesSearchActions {
    var onClosed: () -> Void
 
    public init(onClosed: @escaping () -> Void) {
        self.onClosed = onClosed
    }
}
