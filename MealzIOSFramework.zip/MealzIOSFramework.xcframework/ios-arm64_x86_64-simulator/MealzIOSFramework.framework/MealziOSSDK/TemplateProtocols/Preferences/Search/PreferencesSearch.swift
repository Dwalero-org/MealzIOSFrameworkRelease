//
//  PreferencesSearch.swift
//  
//
//  Created by didi on 28/09/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Preferences Search page where users can search for ingredients to blacklist
 
 Mandatory Parameters:
 - params:  An implementation of ``PreferencesSearchProtocol``, usually the default ``PreferencesSearch``
 
 */
@available(iOS 14, *)
public struct PreferencesSearch<
    PreferencesSearchParameters: PreferencesSearchProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: PreferencesSearchParameters
    private let baseViews: BaseViews
    
    public init(
        params: PreferencesSearchParameters,
        baseViews: BaseViews
    ) {
        self.params = params
        self.baseViews = baseViews
    }
    
    @ObservedObject private var preferencesSearchVM = PreferencesSearchVM()
    @SwiftUI.State var searchString: String = ""
    @SwiftUI.State var buttonPressed: Bool = false
    
    private func onSelectOption(tag: Tag){
        PreferencesVM.sharedInstance.addTag(tag)
        params.actions.onClosed()
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.search.content(params: SearchParameters(searchText: $searchString) {
                    // don't expect a button on this search
                })
                .onChange(of: searchString) { value in
                    preferencesSearchVM.search(search: value)
                }
                UIStateWrapperView(uiState: preferencesSearchVM.state?.searchProposal) {
                    baseViews.loading.content(params: BaseLoadingParameters())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } emptyView: {
                    baseViews.empty.content(params: BaseEmptyParameters())
                } successView: { successContent() }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .onAppear(perform: { preferencesSearchVM.registerListeners()})
        .onDisappear(perform: { preferencesSearchVM.dispose()})
    }
    
    func successContent() -> some View {
        return VStack(alignment: .leading) {
            ForEach(preferencesSearchVM.tagsSuggestions, id: \.id) { tag in
                // Tags without name will not be displayed in search results
                if let name = tag.attributes?.name {
                    params.tagButton.content(params: BaseButtonParameters(
                        buttonText: name,
                        buttonPressed: buttonPressed
                    ) {
                        buttonPressed = true
                        onSelectOption(tag: tag)
                    })
                }
            }
            Spacer()
        }
        .padding(.bottom, 50) // so that users can see above keyboard
        .padding(Dimension.sharedInstance.sPadding)
    }
}
