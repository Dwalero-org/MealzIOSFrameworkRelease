//
//  BasketTagParametersProtocol.swift
//
//
//  Created by didi on 16/10/2023.
//

import Foundation

/**
 A protocol defining the necessary parameters for the Basket Tag
 
 - title: An implementation of ``BaseTitleProtocol`` that is each Basket Tag button,
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 
 */
@available(iOS 14, *)
public protocol BasketTagParametersProtocol {
    associatedtype Title: BaseTitleProtocol
    
    var title: Title { get }

    var actions: BasketTagActions { get set }
}

public struct BasketTagActions {
    var onShowRecipeDetails: (String) -> Void
    
    public init(onShowRecipeDetails: @escaping (String) -> Void) {
        self.onShowRecipeDetails = onShowRecipeDetails
    }
}
