//
//  BasketTag.swift
//
//
//  Created by didi on 16/10/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Basket Tags where users can the recipes associated with an ingredient.
 
 Mandatory Parameters:
 - params:  An implementation of ``BasketTagParametersProtocol``, usually the default ``BasketTagParameters``.
 - retailerProductId: String -> The productId from the retailer that the recipes should be loaded from
 
 Optional Parameters:
 - scrollAlignment: Axis.Set = .vertical -> The Basket Tags are by default scrolling vertically, but you can pass in ".horizontal" if you would prefer to have the ScrollView be horizontal.
 
 */
@available(iOS 14, *)
public struct BasketTag<
    BasketTagParameters: BasketTagParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: BasketTagParameters
    private let baseViews: BaseViews
    private let scrollAlignment: Axis.Set
    @ObservedObject private var basketTagVm: BasketTagVM
    
    public init(
        params: BasketTagParameters,
        baseViews: BaseViews,
        retailerProductId: String,
        scrollAlignment: Axis.Set = .vertical
    ) {
        self.params = params
        self.baseViews = baseViews
        self.basketTagVm = BasketTagVM(retailerProductId: retailerProductId)
        self.scrollAlignment = scrollAlignment
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: basketTagVm.state?.recipeList) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                baseViews.empty.content(params: BaseEmptyParameters())
            } successView: {
                ScrollView(scrollAlignment, showsIndicators: false) {
                    if scrollAlignment == .horizontal {
                        HStack {
                            successContent()
                        }
                    } else { successContent() }
                }
            }
            .onAppear(perform: { basketTagVm.registerListeners()})
            .onDisappear(perform: { basketTagVm.dispose()})
        }
    }
    
    func successContent() -> some View {
        ForEach(basketTagVm.recipes, id: \.self) { recipe in
            params.title.content(
                params: TitleParameters(
                    title: recipe.attributes?.title ?? "",
                    subtitle: nil
                )
            )
            .onTapGesture {
                params.actions.onShowRecipeDetails(recipe.id)
            }
        }
    }
}
