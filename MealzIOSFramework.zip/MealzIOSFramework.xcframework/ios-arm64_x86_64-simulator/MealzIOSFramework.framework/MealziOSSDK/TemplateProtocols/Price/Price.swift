//
//  Price.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Price while implementing the loading & empty states from the PriceViewModel
 
 - params: An implementation of ``PriceParametersProtocol``
 - recipeId: String -> The recipeId of the Recipe relating to this price
 - guestNumber: Int -> The number of guests that the current search or catalog is calibrated for
 
 */
// i think this can be eliminated?
@available(iOS 14, *)
public struct Price<
    PriceParameters: PriceParametersProtocol
>: View {
    private let params: PriceParameters
    private let guestNumber: Int
    @ObservedObject var viewModel: PriceVM = PriceVM()
    public init(
        params: PriceParameters,
        recipeId: String,
        guestNumber: Int
    ) {
        self.params = params
        self.guestNumber = guestNumber
        viewModel.setRecipe(recipeId: recipeId, guestNumber: Int32(guestNumber))
    }
    public var body: some View {
        UIStateWrapperView(uiState: viewModel.state?.price) {
            params.loading.content(params: BaseLoadingParameters())
        } emptyView: { params.empty.content(params: BaseEmptyParameters())
        }
        successView: {
            params.priceSuccess.content(
                price: viewModel.pricing?.price ?? 0.0,
                guests: guestNumber,
                currency: Localization.price.currency.localised)
        }
        .onAppear { viewModel.registerListeners() }
        .onDisappear(perform: { viewModel.dispose()})
    }
}
