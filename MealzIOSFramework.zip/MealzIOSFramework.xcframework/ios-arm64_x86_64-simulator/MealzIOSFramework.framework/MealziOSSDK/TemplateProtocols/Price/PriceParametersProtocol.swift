//
//  PriceParametersProtocol.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Price Component
 
 - priceSuccess:  An implementation of ``PriceSuccessProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 
 */
@available(iOS 14, *)
public protocol PriceParametersProtocol {
    associatedtype PriceSuccess: PriceSuccessProtocol
    associatedtype Loading: LoadingProtocol
    associatedtype Empty: EmptyProtocol
    
    var priceSuccess: PriceSuccess { get }
    var loading: Loading { get }
    var empty: Empty { get }
}
