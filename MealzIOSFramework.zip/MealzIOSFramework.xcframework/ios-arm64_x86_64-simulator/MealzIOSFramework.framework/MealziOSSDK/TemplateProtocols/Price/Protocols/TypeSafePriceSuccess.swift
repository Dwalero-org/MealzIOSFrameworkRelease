//
//  TypeSafePriceSuccess.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafePriceSuccess: PriceSuccessProtocol {
    private let _content: (
        Double,
        Int,
        String
    ) -> AnyView

    public init<T: PriceSuccessProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { price, guests, currency in
            AnyView(wrapped.content(
                price: price,
                guests: guests,
                currency: currency))
        }
    }

    public func content(
        price: Double,
        guests: Int,
        currency: String
    ) -> some View {
        _content(price, guests, currency)
    }
}
