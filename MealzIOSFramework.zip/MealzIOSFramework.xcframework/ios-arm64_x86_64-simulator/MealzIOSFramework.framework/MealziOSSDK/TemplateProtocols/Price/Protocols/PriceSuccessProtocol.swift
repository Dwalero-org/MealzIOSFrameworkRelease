//
//  PriceSuccessProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the price, currency, & guests of the Price Success
 
 - price: Double ->  The price of the current recipeId
 - guests: Int -> The number of guests for the catalog, can be used to get "price per person"
 - currency: String -> The currency used from localization
 */
@available(iOS 14, *)
public protocol PriceSuccessProtocol {
    associatedtype Content: View
    func content(
        price: Double,
        guests: Int,
        currency: String
    ) -> Content
}
