//
//  MealPlannerRecipeCardProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the MealPlannerRecipeCard.
 
 - recipeCardDimensions: CGSize -> the width & height of the recipe card
 - recipe: Recipe: The Recipe object of the current recipe of the Recipe Card
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onRemoveRecipeFromMealPlanner: () -> Void: A closure that deletes this recipe from the current Meal Planner Results & will show the Recipe Card Placeholder
 - onReplaceRecipeFromMealPlanner: () -> Void: A closure that opens the Meal Planner Recipe Picker where the current recipe can be repalced

 */
@available(iOS 14, *)
public protocol MealPlannerRecipeCardProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerRecipeCardParameters) -> Content
}

public struct MealPlannerRecipeCardParameters {
    public var recipeCardDimensions: CGSize
    public var recipe: Recipe
    public var onShowRecipeDetails: (String) -> Void
    public var onRemoveRecipeFromMealPlanner: () -> Void
    public var onReplaceRecipeFromMealPlanner: () -> Void
 
    public init(
        recipeCardDimensions: CGSize,
        recipe: Recipe,
        onShowRecipeDetails: @escaping (String) -> Void,
        onRemoveRecipeFromMealPlanner: @escaping () -> Void,
        onReplaceRecipeFromMealPlanner: @escaping () -> Void
    ) {
        self.recipeCardDimensions = recipeCardDimensions
        self.recipe = recipe
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onRemoveRecipeFromMealPlanner = onRemoveRecipeFromMealPlanner
        self.onReplaceRecipeFromMealPlanner = onReplaceRecipeFromMealPlanner
    }
}
