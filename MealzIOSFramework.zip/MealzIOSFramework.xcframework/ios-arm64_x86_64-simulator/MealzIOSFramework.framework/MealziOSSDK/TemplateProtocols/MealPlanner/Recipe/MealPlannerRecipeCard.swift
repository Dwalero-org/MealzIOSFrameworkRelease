//
//  MealPlannerRecipeCard.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 04/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A MealPlanner RecipeCard that handles the different states of the RecipeCardViewModel.
 
 Mandatory Parameters:
 - recipeId: String -> The id of the Recipe that the view will display
 - recipeCard:  An implementation of ``MealPlannerRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onRemoveRecipeFromMealPlanner: () -> Void: A closure that deletes this recipe from the current Meal Planner Results & will show the Recipe Card Placeholder
 - onReplaceRecipeFromMealPlanner: () -> Void: A closure that opens the Meal Planner Recipe Picker where the current recipe can be repalced
 
 */
@available(iOS 14, *)
public struct MealPlannerRecipeCard<
    CardTemplate: MealPlannerRecipeCardProtocol,
    CardLoadingTemplate: RecipeCardLoadingProtocol
>: View {
    private let recipeId: String
    private let recipeCard: CardTemplate
    private let recipeCardLoading: CardLoadingTemplate
    private let recipeCardDimensions: CGSize
    private let onShowRecipeDetails: (String) -> Void
    private let onRemoveRecipeFromMealPlanner: () -> Void
    private let onReplaceRecipeFromMealPlanner: () -> Void
    
    @StateObject var recipeViewModel = RecipeCardVM()
    public init(
        recipeId: String,
        recipeCard: CardTemplate,
        recipeCardLoading: CardLoadingTemplate,
        recipeCardDimensions: CGSize,
        onShowRecipeDetails: @escaping (String) -> Void,
        onRemoveRecipeFromMealPlanner: @escaping () -> Void,
        onReplaceRecipeFromMealPlanner: @escaping () -> Void
    ) {
        self.recipeId = recipeId
        self.recipeCard = recipeCard
        self.recipeCardLoading = recipeCardLoading
        self.recipeCardDimensions = recipeCardDimensions
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onRemoveRecipeFromMealPlanner = onRemoveRecipeFromMealPlanner
        self.onReplaceRecipeFromMealPlanner = onReplaceRecipeFromMealPlanner
    }
    
    public var body: some View {
        HStack {
            UIStateWrapperView(uiState: recipeViewModel.state?.recipeState) {
                recipeCardLoading.content(
                    params: RecipeCardLoadingParameters(recipeCardDimensions: recipeCardDimensions)
                )
            } emptyView: {
            } successView: {
                if let recipe = recipeViewModel.recipe {
                    recipeCard.content(
                        params: MealPlannerRecipeCardParameters(
                            recipeCardDimensions: recipeCardDimensions,
                            recipe: recipe,
                            onShowRecipeDetails: onShowRecipeDetails,
                            onRemoveRecipeFromMealPlanner: onRemoveRecipeFromMealPlanner,
                            onReplaceRecipeFromMealPlanner: onReplaceRecipeFromMealPlanner)
                    )
                }
            }
        }
        .onAppear {
            if recipeViewModel.recipe == nil {
                recipeViewModel.setEvent(event: RecipeContractEvent.FetchRecipeFromId(recipeId: recipeId))
            }
            recipeViewModel.registerListeners()
        }
        .onDisappear(perform: { recipeViewModel.dispose()})
    }
}
