//
//  MealPlannerCriteria.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 03/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 An object containing all the core variables for the Meal Planner Form & Results
 
 - availableBudget: Double -> The budget defined by the User
 - numberOfGuests: Int -> The number of people each Recipe should be calibrated for
 - numberOfMeals: Int -> The number of meals that should be returned in the Results
 - maxRecipesForBudget: Int -> Maximum numbers of recipes that can be chosen based on budget & number of guests.
 Will be set by API responseMaximum numbers of recipes that can be chosen based on budget & number of guests. Will be set by API response

 */
public struct MealPlannerCriteria {
    public var availableBudget: Double
    public var numberOfGuests: Int
    public var numberOfMeals: Int
    public var maxRecipesForBudget: Int

    public init(
        availableBudget: Double,
        numberOfGuests: Int,
        numberOfMeals: Int,
        maxRecipesForBudget: Int = 99
    ) {
        self.availableBudget = availableBudget
        self.numberOfGuests = numberOfGuests
        self.numberOfMeals = numberOfMeals
        self.maxRecipesForBudget = maxRecipesForBudget
    }
}

extension MealPlannerCriteria: Equatable {
    public static func == (lhs: MealPlannerCriteria, rhs: MealPlannerCriteria) -> Bool {
        return lhs.availableBudget == rhs.availableBudget &&
        lhs.numberOfGuests == rhs.numberOfGuests &&
        lhs.numberOfMeals == rhs.numberOfMeals &&
        lhs.maxRecipesForBudget == rhs.maxRecipesForBudget
    }
}
