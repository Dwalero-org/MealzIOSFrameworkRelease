//
//  MealPlannerRecapProtocol.swift
//  
//
//  Created by didi on 6/26/23.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Reca that he final page of the user journey displays the final amount & where users can navigate to a new page.
 
 - numberOfMeals: Int -> The number of recipes that the user added to their basket.
 - totalPrice: Double -> The total price of the recipes added to the basket.
 - onTapGesture: () -> Void:  A closure that navigates the user to somewhere else in the client app. The catalog, basket, home page. Up to the client.
 
 */
@available(iOS 14, *)
/// Represents the final page of the user journey displays the final amount
public protocol MealPlannerRecapProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerRecapViewParameters) -> Content
}

public struct MealPlannerRecapViewParameters {
    public var numberOfMeals: Int
    public var totalPrice: Double
    public var onTapGesture: () -> Void
    
    public init(numberOfMeals: Int, totalPrice: Double, onTapGesture: @escaping () -> Void) {
        self.numberOfMeals = numberOfMeals
        self.totalPrice = totalPrice
        self.onTapGesture = onTapGesture
    }
}
