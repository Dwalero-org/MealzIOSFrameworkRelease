//
//  MealPlannerRecapParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Meal Planner Basket Page.
 
 - success:  An implementation of ``MealPlannerRecapProtocol`` which displays the total price spent
 - background: An implementation of ``BackgroundProtocol``
 
 - onNavigateAwayFromMealPlanner: () -> Void: A closure that navigates the user to somewhere else in the client app. The catalog, basket, home page. Up to the client.
 
 */
@available(iOS 14, *)
public protocol MealPlannerRecapParametersProtocol {
    associatedtype RecapTemplate: MealPlannerRecapProtocol
    associatedtype Background: BackgroundProtocol
    
    var success: RecapTemplate { get }
    var background: Background { get }
    
    var actions: MealPlannerRecapActions { get set }
}

public struct MealPlannerRecapActions {
    public var onNavigateAwayFromMealPlanner: () -> Void
    
    public init(onNavigateAwayFromMealPlanner: @escaping () -> Void) {
        self.onNavigateAwayFromMealPlanner = onNavigateAwayFromMealPlanner
    }
}
