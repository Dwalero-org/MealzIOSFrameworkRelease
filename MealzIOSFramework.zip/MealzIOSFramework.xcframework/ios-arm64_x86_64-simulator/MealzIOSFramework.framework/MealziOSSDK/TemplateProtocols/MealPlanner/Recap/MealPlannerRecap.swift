//
//  MealPlannerRecap.swift
//
//
//  Created by didi on 6/26/23.
//

import SwiftUI

/**
 A view showing the Meal Planner basket & their recipes in their cart.
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerRecapParametersProtocol``, usually the default ``MealPlannerRecapParametersProtocol``
 
 */
@available(iOS 14, *)
public struct MealPlannerRecap<
    MealPlannerRecapParameters: MealPlannerRecapParametersProtocol
>: View {
    private let params: MealPlannerRecapParameters
    @StateObject var viewModel = MealPlannerRecapVM()
    public init(params: MealPlannerRecapParameters) {
        self.params = params
    }
    public var body: some View {
        ZStack {
            params.background.content(params: BaseBackgroundParameters())
            params.success.content(
                params: MealPlannerRecapViewParameters(
                    numberOfMeals: viewModel.numberOfMeals,
                    totalPrice: viewModel.totalPrice,
                    onTapGesture: params.actions.onNavigateAwayFromMealPlanner)
            )
        }
        .onAppear(perform: { viewModel.registerListeners()})
        .onDisappear(perform: { viewModel.dispose()})
    }
}
