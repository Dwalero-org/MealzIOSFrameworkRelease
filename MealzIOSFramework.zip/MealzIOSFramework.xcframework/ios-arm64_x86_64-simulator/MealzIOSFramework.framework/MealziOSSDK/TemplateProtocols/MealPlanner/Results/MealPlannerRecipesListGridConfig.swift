//
//  MealPlannerRecipesListGridConfig.swift
//  MiamIOSFramework
//
//  Created by didi on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 Configuration for the grid constraints of the Meal Planner Recipes List
 
 Mandatory Parameters:
 - spacing: CGSize -> The width & height of each recipeCard
 - recipeCardDimensions: CGSize -> The width & height of each recipeCard
 
 */
@available(iOS 14, *)
public struct MealPlannerRecipesListGridConfig {
    let spacing: CGSize
    let recipeCardDimensions: CGSize
    let heightOfFooter: CGFloat
    
    public init(
        spacing: CGSize = CGSize(width: 4, height: 4),
        recipeCardDimensions: CGSize = CGSize(width: 300, height: 200),
        heightOfFooter: CGFloat = 100
    ) {
        self.spacing = spacing
        self.recipeCardDimensions = recipeCardDimensions
        self.heightOfFooter = heightOfFooter
    }
}
