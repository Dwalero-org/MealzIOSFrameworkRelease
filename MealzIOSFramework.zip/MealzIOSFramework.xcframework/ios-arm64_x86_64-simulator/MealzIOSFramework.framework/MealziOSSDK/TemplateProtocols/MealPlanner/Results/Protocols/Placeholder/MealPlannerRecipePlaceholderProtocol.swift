//
//  MealPlannerRecipePlaceholderProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Results Placeholder, which users can touch to replace the spot in their Meal Planner Results
 
 - onTapGesture: () -> Void: A closure that navigates the user to the Meal Planner Recipe Picker page
 
 */
@available(iOS 14, *)
public protocol MealPlannerRecipePlaceholderProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerRecipePlaceholderParameters) -> Content
}

public struct MealPlannerRecipePlaceholderParameters {
    public var recipeCardDimensions: CGSize
    public let onTapGesture: () -> Void
    
    public init(
        recipeCardDimensions: CGSize,
        onTapGesture: @escaping () -> Void
    ) {
        self.recipeCardDimensions = recipeCardDimensions
        self.onTapGesture = onTapGesture
    }
}
