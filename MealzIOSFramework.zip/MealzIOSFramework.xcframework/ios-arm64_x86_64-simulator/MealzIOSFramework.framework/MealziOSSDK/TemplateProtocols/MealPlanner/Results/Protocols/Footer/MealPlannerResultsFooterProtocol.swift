//
//  MealPlannerResultsFooterProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 06/06/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Results Footer, where users can navigate to a new page & see their current spend.
 
 - mealPlannerCriteria: MealPlannerCriteria: An instance of ``MealPlannerCriteria`` of the desired budget, number of guests, & number of meals
 - budgetSpent: Binding<Double>: A binding double value that shows the current amount the user is spending
 - onValidateTapped: () -> Void: A closure that adds all the products to their basket & navigates the user directly to the Meal Planner Basket to see what has been added to their cart
 
 */
@available(iOS 13, *)
public protocol MealPlannerResultsFooterProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerResultsFooterParameters) -> Content
}

@available(iOS 13, *)
public struct MealPlannerResultsFooterParameters {
    public let mealPlannerCriteria: MealPlannerCriteria
    public let heightOfFooter: CGFloat
    public var budgetSpent: Binding<Double>
    public let onValidateTapped: () -> Void
    
    public init(
        mealPlannerCriteria: MealPlannerCriteria,
        heightOfFooter: CGFloat,
        budgetSpent: Binding<Double>,
        onValidateTapped: @escaping () -> Void
    ) {
        self.mealPlannerCriteria = mealPlannerCriteria
        self.heightOfFooter = heightOfFooter
        self.budgetSpent = budgetSpent
        self.onValidateTapped = onValidateTapped
    }
}
