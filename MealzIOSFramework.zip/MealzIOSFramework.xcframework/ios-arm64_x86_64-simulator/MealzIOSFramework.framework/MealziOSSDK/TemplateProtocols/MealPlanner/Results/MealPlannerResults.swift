//
//  MealPlannerResults.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 19/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Favorites page where users can see the recipes they have liked.
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerResultsParametersProtocol``, usually the default ``MealPlannerResultsParameters``
 - gridConfig:  A ``MealPlannerRecipesListGridConfig`` which selects all the bounds for the recipes list, such as spacing.
 
 Optional Parameters:
 - mealPlannerCriteria: ``MealPlannerCriteria`` -> Clients can optionally pass in a ``MealPlannerCriteria`` with the budget, number of guests, number of meals predefined.
 This is used for deeplinking or promotions. Otherwise the default will be the user's previous search.
 
 */
@available(iOS 14, *)
public struct MealPlannerResults<
    MealPlannerResultsParameters: MealPlannerResultsParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MealPlannerResultsParameters
    private let baseViews: BaseViews
    private let gridConfig: MealPlannerRecipesListGridConfig
    
    @SwiftUI.State private var recipeToReplace: String?
    @SwiftUI.State private var isLoadingRecipes = false
    @SwiftUI.State private var activelyUpdatingTextField = false
    @SwiftUI.State private var activelyEditingCriteria = false
    @SwiftUI.State private var replacingRecipe = false
    
    private var mealPlannerCriteria: MealPlannerCriteria {
        formViewModel.mealPlannerCriteria
    }
    
    @StateObject private var viewModel = MealPlannerMealsVM()
    @StateObject private var formViewModel = MealPlannerFormVM()
    
    public init(
        params: MealPlannerResultsParameters,
        baseViews: BaseViews,
        gridConfig: MealPlannerRecipesListGridConfig,
        mealPlannerCriteria: MealPlannerCriteria? = nil
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        if let mealPlannerCriteria {
            formViewModel.setBudget(amount: Int32(mealPlannerCriteria.availableBudget))
            formViewModel.setNumberOfGuests(amount: Int32(mealPlannerCriteria.numberOfGuests))
            formViewModel.setNumberOfMeals(mealCount: Int32(mealPlannerCriteria.numberOfMeals))
        }
        
        if #unavailable(iOS 16) {
            UITableView.appearance().backgroundColor = .clear
        }
    }
    
    let dimension = Dimension.sharedInstance
    let errorMessage = Localization.myBudget.noResultsForBudget.localised
    
    private var numberOfRecipesRemaining: Int {
        return viewModel.meals.compactMap { $0 }.count
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: viewModel.state?.meals) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                params.emptyResults.content(
                    params: MealPlannerResultsEmptyParameters(
                        mealPlannerCriteria: formViewModel.mealPlannerCriteria,
                        reason: errorMessage)
                )
            } successView: {
                successContent()
            }
        }
        .onAppear {
            viewModel.registerListeners()
            formViewModel.registerListeners()
        }
        .onDisappear {
            viewModel.dispose()
            formViewModel.dispose()
        }
    }
    
    private func getRecipesFromVM() {
        isLoadingRecipes = true
        formViewModel.getRecipesForBudgetConstraint(
            budget: Int32(formViewModel.mealPlannerCriteria.availableBudget),
            mealCount: Int32(formViewModel.mealPlannerCriteria.numberOfMeals),
            guestCount: Int32(formViewModel.mealPlannerCriteria.numberOfGuests)) { _, _ in
                isLoadingRecipes = false
            }
    }
    
    private func successContent() -> some View {
        ZStack {
            VStack {
                if #available(iOS 15.0, *) {
                    ScrollView { coreContent() }
                        .refreshable {
                            getRecipesFromVM()
                        }
                } else {
                    ScrollView { coreContent() }
                }
            }
            VStack {
                Spacer()
                footer()
            }
        }
    }
    
    // this is shared but parent (ScrollView) can depend on iOS15 or not
    private func coreContent() -> some View {
        VStack {
            toolbar()
            if formViewModel.errorAppeared {
                Text(errorMessage)
            }
            recipesList()
            Spacer()
                .frame(height: gridConfig.heightOfFooter)
        }
    }
    
    private func footer() -> some View {
        params.footer.content(
            params: MealPlannerResultsFooterParameters(
                mealPlannerCriteria: formViewModel.mealPlannerCriteria,
                heightOfFooter: gridConfig.heightOfFooter,
                budgetSpent: $viewModel.totalPrice) {
                    viewModel.addRecipesToGroceriesList()
                    params.actions.onNavigateToBasket()
                })
    }
    
    private func toolbar() -> some View {
        params.toolbar.content(
            params: MealPlannerResultsToolbarParameters(
                mealPlannerCriteria: $formViewModel.mealPlannerCriteria, 
                numberOfResults: numberOfRecipesRemaining,
                activelyEditingCriteria: $activelyEditingCriteria,
                activelyEditingTextField: $activelyUpdatingTextField,
                isLoadingRecipes: $isLoadingRecipes) {
                    getRecipesFromVM()
                    withAnimation { activelyEditingCriteria = false }
                }
        )
        .onChange(of: formViewModel.mealPlannerCriteria, perform: { newValue in
            updateBudget(mealPlannerCriteria: newValue)
        })
        .onChange(of: combinedMealPlannerAndGuestsCount) { newMealPlannerInfos in
            fetchAndUpdateMaxMeals()
        }
        .onAppear() {
            fetchAndUpdateMaxMeals()
        }
        .onTapGesture { withAnimation { activelyEditingCriteria = true }}
        .padding(Dimension.sharedInstance.lPadding)
    }
    
    private func fetchAndUpdateMaxMeals() {
        if formViewModel.mealPlannerCriteria.availableBudget > 0.0 && formViewModel.mealPlannerCriteria.numberOfGuests > 0 {
            formViewModel.getRecipesMaxCountForBudgetConstraint(budget: Int32(formViewModel.mealPlannerCriteria.availableBudget), guestCount: Int32(formViewModel.mealPlannerCriteria.numberOfGuests))
            updateBudget(mealPlannerCriteria: formViewModel.mealPlannerCriteria)
        }
    }
    
    private func updateBudget(mealPlannerCriteria: MealPlannerCriteria) {
        formViewModel.setBudget(amount: Int32(mealPlannerCriteria.availableBudget))
        formViewModel.setNumberOfGuests(amount: Int32(mealPlannerCriteria.numberOfGuests))
        formViewModel.setNumberOfMeals(mealCount: Int32(mealPlannerCriteria.numberOfMeals))
    }
    var combinedMealPlannerAndGuestsCount: Int {
        formViewModel.mealPlannerCriteria.numberOfGuests + Int(formViewModel.mealPlannerCriteria.availableBudget)
    }
}

@available(iOS 14, *)
extension MealPlannerResults {
    
    @available(iOS 14, *)
    private func recipesList() -> some View {
        VStack(spacing: 0) {
            if !isLoadingRecipes {
                /*  We sort on the left side of the meals enumerated array: (ex:
                 [0, meal1]
                 [1, nil]
                 [2, meal3]
                 This leads to issues when meals are replaced, as SwiftUI ForEach does not when meal1 is replaced with meal4, because the index is the same.
                 To handle this, we wrap the content in the isLoadingRecipes & have a small wait before setting isLoadingRecipes to false again after a user has replaced a recipe.
                 This is not an ideal solution.
                 if you'd like to have the ForEach depend on the meals, just change the id to 'id: \.1'
                 */
                ForEach(Array(viewModel.meals.enumerated()), id: \.0.self) { index, meal in
                    VStack(spacing: 0) {
                        if let meal {
                            MealPlannerRecipeCard(
                                recipeId: meal.recipeId,
                                recipeCard: params.recipeCard,
                                recipeCardLoading: params.recipeCardLoading,
                                recipeCardDimensions: gridConfig.recipeCardDimensions,
                                onShowRecipeDetails: { recipeId in
                                    params.actions.onShowRecipeDetails(recipeId)
                                },
                                onRemoveRecipeFromMealPlanner: {
                                    removeRecipe(meal.recipeId)
                                },
                                onReplaceRecipeFromMealPlanner: {
                                    replacingRecipe = true
                                    recipeToReplace = meal.recipeId
                                    if let totalPrice = viewModel.state?.totalPrice {
                                        viewModel.calculAvailableBudgetOnNavigateToReplaceRecipe(
                                            totalPrice: totalPrice,
                                            recipeToReplacePrice: KotlinDouble(value: meal.price))
                                    }
                                    replaceRecipe(index)
                                })
                            .id(meal.recipeId)
                        } else {
                            params.placeholder.content(params: MealPlannerRecipePlaceholderParameters(
                                recipeCardDimensions: gridConfig.recipeCardDimensions
                            ) {
                                if let totalPrice = viewModel.state?.totalPrice {
                                    viewModel.calculAvailableBudgetOnNavigateToReplaceRecipe(
                                        totalPrice: totalPrice,
                                        recipeToReplacePrice: nil)
                                }
                                self.replaceRecipe(index)
                            })
                        }
                    }
                    .frame(height: gridConfig.recipeCardDimensions.height)
                    .padding(.vertical, gridConfig.spacing.height)
                    .padding(.horizontal, gridConfig.spacing.width)
                }
            }
            else {
                Spacer()
                    .frame(height: 100.0)
                baseViews.loading.content(params: BaseLoadingParameters())
            }
        }
        .onChange(of: viewModel.meals) { newValue in
            if replacingRecipe {
                isLoadingRecipes = true
                replacingRecipe = false
                DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(600), execute: {
                    isLoadingRecipes = false
                })
            }
        }
    }
    
    private func removeRecipe(_ recipeId: String) {
        viewModel.removeRecipe(recipeId)
    }
    
    private func replaceRecipe(_ index: Int) {
        params.actions.onOpenReplaceRecipe(index)
    }
}
