//
//  MealPlannerResultsEmptyProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Empty Results, where users see what was wrong with their search
 
 - mealPlannerCriteria: MealPlannerCriteria -> An implementation of ``MealPlannerCriteria`` that has the budget, number of guests, etc
 - reason: String -> A simple text of what was wrong with their search
 
 */
@available(iOS 14, *)
public protocol MealPlannerResultsEmptyProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerResultsEmptyParameters) -> Content
}

public struct MealPlannerResultsEmptyParameters {
    public var mealPlannerCriteria: MealPlannerCriteria
    public var reason: String
    
    public init(mealPlannerCriteria: MealPlannerCriteria, reason: String) {
        self.mealPlannerCriteria = mealPlannerCriteria
        self.reason = reason
    }
}
