//
//  MealPlannerResultsParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Meal Planner Results Page.
 
 - toolbar:  An implementation of ``MealPlannerResultsToolbarProtocol``
 - footer:  An implementation of ``MealPlannerResultsFooterProtocol``
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - placeholder:  An implementation of ``MealPlannerRecipePlaceholderProtocol``
 - emptyResults:  An implementation of ``MealPlannerResultsEmptyProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onOpenReplaceRecipe: (Int) -> Void: A closure that opens the MealPlanner RecipePicker Page where users can replace the tapped recipe.
 - onNavigateToBasket: () -> Void: A closure that navigates the user to the Meal Planner Basket Page where they can edit the products in their basket.
 
 */
@available(iOS 14, *)
public protocol MealPlannerResultsParametersProtocol {
    associatedtype ToolbarTemplate: MealPlannerResultsToolbarProtocol
    associatedtype FooterTemplate: MealPlannerResultsFooterProtocol
    associatedtype CardTemplate: MealPlannerRecipeCardProtocol
    associatedtype LoadingCardTemplate: RecipeCardLoadingProtocol
    associatedtype PlaceholderCardTemplate: MealPlannerRecipePlaceholderProtocol
    associatedtype EmptyMealPlanner: MealPlannerResultsEmptyProtocol
    
    var toolbar: ToolbarTemplate { get }
    var footer: FooterTemplate { get }
    var recipeCard: CardTemplate { get }
    var recipeCardLoading: LoadingCardTemplate { get }
    var placeholder: PlaceholderCardTemplate { get }
    var emptyResults: EmptyMealPlanner { get }
    
    var actions: MealPlannerResultsActions { get set }
}

public struct MealPlannerResultsActions {
    public var onShowRecipeDetails: (String) -> Void
    public var onOpenReplaceRecipe: (Int) -> Void
    public var onNavigateToBasket: () -> Void
    
    public init(
        onShowRecipeDetails: @escaping (String) -> Void,
        onOpenReplaceRecipe: @escaping (Int) -> Void,
        onNavigateToBasket: @escaping () -> Void
    ) {
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onOpenReplaceRecipe = onOpenReplaceRecipe
        self.onNavigateToBasket = onNavigateToBasket
    }
}
