//
//  TypeSafeMealPlannerRecipePlaceholder.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeMealPlannerRecipePlaceholder: MealPlannerRecipePlaceholderProtocol {
    private let _content: (MealPlannerRecipePlaceholderParameters ) -> AnyView

    public init<T: MealPlannerRecipePlaceholderProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MealPlannerRecipePlaceholderParameters) -> some View {
        _content(params)
    }
}
