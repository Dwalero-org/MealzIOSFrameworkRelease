//
//  MealPlannerResultsToolbarProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Form Input on the Results page, where users enter in their desired budget, number of guests, & number of meals
 
 - mealPlannerCriteria: Binding<MealPlannerCriteria>: A binding ``MealPlannerCriteria`` of the desired budget, number of guests, & number of meals
 - activelyUpdatingTextField: Binding<Bool>: A binding boolean that, when true, will prohibit users from saving the form & navigating to the next page.
 - isLoadingRecipes: Binding<Bool> -> A boolean that should show a loader when true as the recipes are currently being fetched.
 - onValidateTapped: () -> Void: A closure that refreshes the recipe results based on the new criteria
 
 */
@available(iOS 14, *)
public protocol MealPlannerResultsToolbarProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerResultsToolbarParameters) -> Content
}

@available(iOS 14, *)
public struct MealPlannerResultsToolbarParameters {
    public let mealPlannerCriteria: Binding<MealPlannerCriteria>
    public let numberOfResults: Int
    @Binding public var activelyEditingCriteria: Bool
    @Binding public var activelyEditingTextField: Bool
    @Binding public var isLoadingRecipes: Bool
    public let onValidateTapped: () -> Void
 
    public init(
        mealPlannerCriteria: Binding<MealPlannerCriteria>,
        numberOfResults: Int,
        activelyEditingCriteria: Binding<Bool>,
        activelyEditingTextField: Binding<Bool>,
        isLoadingRecipes: Binding<Bool>,
        onValidateTapped: @escaping () -> Void
    ) {
        self.mealPlannerCriteria = mealPlannerCriteria
        self.numberOfResults = numberOfResults
        _activelyEditingCriteria = activelyEditingCriteria
        _activelyEditingTextField = activelyEditingTextField
        _isLoadingRecipes = isLoadingRecipes
        self.onValidateTapped = onValidateTapped
    }
}
