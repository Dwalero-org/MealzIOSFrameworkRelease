//
//  MealPlannerRecipePickerParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the Meal Planner Basket Page.
 
 - search:  An implementation of ``SearchProtocol``
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - noResults:  An implementation of ``CatalogRecipesListNoResultsProtocol``
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onSelectRecipeForMealPlanner: (String) -> Void: A closure that  selects the current recipe for the meal planner & navigates the user back to the Meal Planner Results page
 - onOpenFiltersOptions: (SingletonFilterViewModel) -> Void: A closure that navigates the user to the Filters page, passing in the MealPlanner Filters View Model
 
 */
@available(iOS 14, *)
public protocol MealPlannerRecipePickerParametersProtocol {
    associatedtype SearchTemplate: SearchProtocol
    associatedtype NoResults: CatalogRecipesListNoResultsProtocol
    associatedtype CardTemplate: CatalogRecipeCardProtocol
    associatedtype RecipeLoading: RecipeCardLoadingProtocol

    var search: SearchTemplate { get }
    var noResults: NoResults { get }
    var recipeCard: CardTemplate { get }
    var recipeCardLoading: RecipeLoading { get }

    var actions: MealPlannerRecipePickerActions { get set }
}

public struct MealPlannerRecipePickerActions {
    public let onShowRecipeDetails: (String) -> Void
    public let onSelectRecipeForMealPlanner: () -> Void
    public let onOpenFiltersOptions: (FilterInstance) -> Void
 
    public init(
        onShowRecipeDetails: @escaping (String) -> Void,
        onSelectRecipeForMealPlanner: @escaping () -> Void,
        onOpenFiltersOptions: @escaping (FilterInstance) -> Void
    ) {
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onSelectRecipeForMealPlanner = onSelectRecipeForMealPlanner
        self.onOpenFiltersOptions = onOpenFiltersOptions
    }
}
