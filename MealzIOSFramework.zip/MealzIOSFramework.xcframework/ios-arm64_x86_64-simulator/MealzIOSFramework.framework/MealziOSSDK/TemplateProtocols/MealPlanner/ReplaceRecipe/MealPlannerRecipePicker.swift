//
//  MealPlannerRecipePicker.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 25/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Meal Planner Catalog page where users can select a recipe to replace a different one
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerRecipePickerParametersProtocol``, usually the default ``MealPlannerRecipePickerParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 - indexOfReplacedRecipe: Int -> The index in the Meal Planner Results of the recipe being replaced
 
 */
@available(iOS 14, *)
public struct MealPlannerRecipePicker<
    MealPlannerRecipePickerParameters: MealPlannerRecipePickerParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MealPlannerRecipePickerParameters
    private let baseViews: BaseViews
    private let gridConfig: CatalogRecipesListGridConfig
    private let indexOfReplacedRecipe: Int
    
    public init(
        params: MealPlannerRecipePickerParameters,
        baseViews: BaseViews,
        gridConfig: CatalogRecipesListGridConfig,
        indexOfReplacedRecipe: Int
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        self.indexOfReplacedRecipe = indexOfReplacedRecipe
        _viewModel = StateObject(wrappedValue: MealPlannerReplaceRecipeViewModel())
    }
    
    @StateObject private var viewModel: MealPlannerReplaceRecipeViewModel
    private var filterInstance = FilterInstance(filterType: .mealPlanner)
    @SwiftUI.State private var searchText = ""
    @SwiftUI.State private var showSearchField = false
    @SwiftUI.State private var isLoading = false
    @SwiftUI.State private var openedFilters = false
    
    func searchTextChanged(newValue: String) {
        viewModel.recipes = []
        viewModel.search(input: newValue)
    }
    
    func filtersChanged() {
        if openedFilters {
            viewModel.recipes = []
            viewModel.doInitPage()
        }
    }
    
    var catalogContent: CatalogContent {
        if searchText != "" { return CatalogContent.wordSearch }
        else if openedFilters { return CatalogContent.filterSearch }
        else { return CatalogContent.categoriesList }
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.search.content(
                    params: SearchParameters(
                        searchText: $searchText,
                        onApply: {
                            openedFilters = true
                            params.actions.onOpenFiltersOptions(
                                filterInstance
                            )
                        }
                    )
                )
                .onChange(of: searchText) { newValue in
                    searchTextChanged(newValue: newValue)
                }
                UIStateWrapperView(uiState: viewModel.state?.recipes) {
                    baseViews.loading.content(params: BaseLoadingParameters())
                } emptyView: {
                    params.noResults.content(
                        params: CatalogRecipesListNoResultsParameters(
                            catalogContent: catalogContent,
                            searchText: searchText,
                            onNoResultsRedirect: params.actions.onSelectRecipeForMealPlanner)
                    )
                } successView: { successContent() }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .onAppear {
            viewModel.registerListeners()
            filtersChanged()
            openedFilters = false
        }
        .onDisappear {
            if !openedFilters { viewModel.filterInstance.clear() }
            viewModel.dispose()
        }
    }
    
    func successContent() -> some View {
        ScrollView {
            LazyVGrid(columns: Array(
                repeating: GridItem(.flexible()),
                count: gridConfig.numberOfColumns),
                      spacing: 0
            ) {
                ForEach(viewModel.recipes.indices, id: \.self) { index in
                    CatalogRecipeCard(
                        viewModel.recipes[index],
                        numberOfGuests: Int(BudgetRepository.companion.guestCount),
                        recipeCardDimensions: gridConfig.recipeCardDimensions,
                        cardTemplate: params.recipeCard,
                        loadingTemplate: params.recipeCardLoading,
                        onShowRecipeDetails: params.actions.onShowRecipeDetails,
                        onCallToAction: { recipeId in
                            viewModel.addRecipeToMealPlanner(recipeId: recipeId, index: Int32(indexOfReplacedRecipe))
                            params.actions.onSelectRecipeForMealPlanner()
                        }
                    )
                    .padding(.horizontal, gridConfig.spacing.width)
                    .padding(.vertical, gridConfig.spacing.height)
                    .id(viewModel.recipes[index].id)
                    .onAppear {
                        if index == viewModel.recipes.count - 1 { // last item
                            viewModel.loadPage()
                        }
                    }
                }
            }
        }
    }
}
