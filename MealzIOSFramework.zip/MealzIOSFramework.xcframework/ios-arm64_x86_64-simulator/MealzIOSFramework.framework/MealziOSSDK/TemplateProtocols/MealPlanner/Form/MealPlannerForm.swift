//
//  MealPlannerForm.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 19/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Meal Planner basket & their recipes in their cart.
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerFormParametersProtocol``, usually the default ``MealPlannerFormParametersProtocol``
 
 Optional Parameters:
 - mealPlannerCriteria: ``MealPlannerCriteria`` -> Clients can optionally pass in a ``MealPlannerCriteria`` with the budget, number of guests, number of meals predefined.
 This is used for deeplinking or promotions. Otherwise the default will be the user's previous search.
 
 */
@available(iOS 14, *)
public struct MealPlannerForm<
    MealPlannerFormParameters: MealPlannerFormParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MealPlannerFormParameters
    private let baseViews: BaseViews
    @SwiftUI.State private var showError = false
    @SwiftUI.State private var isFetchingRecipes = false
    @SwiftUI.State private var activelyUpdatingTextField = false
    @StateObject private var viewModel = MealPlannerFormVM()
    
    private let errorMessage = Localization.myBudget.noResultsForBudget.localised
    public init(
        params: MealPlannerFormParameters,
        baseViews: BaseViews,
        mealPlannerCriteria: MealPlannerCriteria? = nil
    ) {
        self.params = params
        self.baseViews = baseViews
        if let mealPlannerCriteria {
            updateCriteria(mealPlannerCriteria: mealPlannerCriteria)
        }
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.form.content(
                    params: MealPlannerFormViewParameters(
                        mealPlannerCriteria: $viewModel.mealPlannerCriteria,
                        activelyUpdatingTextField: $activelyUpdatingTextField,
                        isFetchingRecipes: isFetchingRecipes
                    ) { _ in
                        showError = false // Reset error display before calling the API.
                        isFetchingRecipes.toggle()
                        viewModel.getRecipesForBudgetConstraint(
                            budget: Int32(viewModel.mealPlannerCriteria.availableBudget),
                            mealCount: Int32(viewModel.mealPlannerCriteria.numberOfMeals),
                            guestCount: Int32(viewModel.mealPlannerCriteria.numberOfGuests)) { recipes, error in
                                guard error == nil, let recipes else {
                                    showError.toggle()
                                    return
                                }
                                params.actions.onNavigateToMealPlannerResults(recipes)
                                isFetchingRecipes.toggle()
                            }
                    })
                .onChange(of: viewModel.mealPlannerCriteria) { newCriteria in
                    updateCriteria(mealPlannerCriteria: newCriteria)
                }
                .onChange(of: combinedBudgetAndGuestsCount) { _ in
                    fetchAndUpdateMaxMeals()
                }
                .onAppear {
                    fetchAndUpdateMaxMeals()
                    viewModel.onInitComponent()
                }
                if showError {
                    errorView(errorMessage)
                }
                Spacer()
            }
        }
        .onAppear(perform: { viewModel.registerListeners()})
        .onDisappear(perform: { viewModel.dispose()})
    }
    
    // TODO: use error template
    private func errorView(_ errorMessage: String) -> some View {
        VStack(alignment: .leading, spacing: 8.0) {
            Image.mealzIcon(icon: .alert)
                .padding([.top, .leading], 12.0)
            Text(errorMessage)
                .foregroundColor(Color.mealzColor(.danger))
                .lineLimit(5)
                .padding([.leading, .trailing, .bottom], 12.0)
        }
        .background(RoundedRectangle(cornerRadius: 6.0).foregroundColor(Color.mealzColor(.errorBackground)))
    }
    
    private func fetchAndUpdateMaxMeals() {
        if viewModel.mealPlannerCriteria.availableBudget > 0.0 &&
            viewModel.mealPlannerCriteria.numberOfGuests > 0 {
            viewModel.getRecipesMaxCountForBudgetConstraint(
                budget: Int32(viewModel.mealPlannerCriteria.availableBudget),
                guestCount: Int32(viewModel.mealPlannerCriteria.numberOfGuests))
            updateCriteria(mealPlannerCriteria: viewModel.mealPlannerCriteria)
        }
    }
    
    private func updateCriteria(mealPlannerCriteria: MealPlannerCriteria) {
        viewModel.setBudget(amount: Int32(mealPlannerCriteria.availableBudget))
        viewModel.setNumberOfGuests(amount: Int32(mealPlannerCriteria.numberOfGuests))
        viewModel.setNumberOfMeals(mealCount: Int32(mealPlannerCriteria.numberOfMeals))
    }
    
    var combinedBudgetAndGuestsCount: Int {
        viewModel.mealPlannerCriteria.numberOfGuests + Int(viewModel.mealPlannerCriteria.availableBudget)
    }
}
