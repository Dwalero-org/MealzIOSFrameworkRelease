//
//  MealPlannerFormParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Meal Planner Form Page.
 
 - form:  An implementation of ``MealPlannerFormProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onNavigateToMealPlannerResults: ([String]) -> Void: A closure that navigates the user to the Meal Planner Results where they can see the meals generated for them by their input.
 
 */
@available(iOS 14, *)
public protocol MealPlannerFormParametersProtocol {
    associatedtype Form: MealPlannerFormProtocol
    
    var form: Form { get }
    
    var actions: MealPlannerFormActions { get set }
}

public struct MealPlannerFormActions {
    public var onNavigateToMealPlannerResults: ([String]) -> Void
    
    public init(onNavigateToMealPlannerResults: @escaping ([String]) -> Void) {
        self.onNavigateToMealPlannerResults = onNavigateToMealPlannerResults
    }
}
