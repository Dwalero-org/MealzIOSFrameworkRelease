//
//  MealPlannerFormProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Form Input, where users enter in their desired budget, number of guests, & number of meals
 
 - mealPlannerCriteria: Binding<MealPlannerCriteria>: A binding ``MealPlannerCriteria`` of the desired budget, number of guests, & number of meals
 - activelyUpdatingTextField: Binding<Bool>: A binding boolean that, when true, will prohibit users from saving the form & navigating to the next page.
 - isFetchingRecipes: Bool -> A boolean that should show a loader when true as the recipes are currently being fetched.
 - onFormValidated: (``MealPlannerCriteria``) -> Void: A closure that navigates the user to the Meal Planner Results page after fetching recipe suggestions for the given form input.
 
 */
@available(iOS 14, *)
public protocol MealPlannerFormProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerFormViewParameters) -> Content
}

@available(iOS 14, *)
public struct MealPlannerFormViewParameters {
    public var mealPlannerCriteria: Binding<MealPlannerCriteria>
    public var activelyUpdatingTextField: Binding<Bool>
    public var isFetchingRecipes: Bool
    public var onFormValidated: (MealPlannerCriteria) -> Void
    
    public init(
        mealPlannerCriteria: Binding<MealPlannerCriteria>,
        activelyUpdatingTextField: Binding<Bool>,
        isFetchingRecipes: Bool,
        onFormValidated: @escaping (MealPlannerCriteria) -> Void
    ) {
        self.mealPlannerCriteria = mealPlannerCriteria
        self.activelyUpdatingTextField = activelyUpdatingTextField
        self.isFetchingRecipes = isFetchingRecipes
        self.onFormValidated = onFormValidated
    }
}
