//
//  BasketProduct.swift
//
//
//  Created by Diarmuid McGonagle on 09/01/2024.
//

import Foundation
import mealzcore
import SwiftUI

@available(iOS 14, *)
internal struct BasketProduct<ProductTemplate: BasketProductProtocol>: View {
    private let productTemplate: ProductTemplate
    private let replaceProduct: () -> Void
    @StateObject private var productVM: BasketEntryInRecipeVM
    
    internal init(
        productVM: BasketEntryInRecipeViewModel,
        productTemplate: ProductTemplate,
        replaceProduct: @escaping () -> Void
    ) {
        self.replaceProduct = replaceProduct
        _productVM = StateObject(wrappedValue: BasketEntryInRecipeVM(instance: productVM))
        self.productTemplate = productTemplate
    }
    
    internal var body: some View {
        return VStack {
            if let presentBasketEntry = productVM.entry, let item = presentBasketEntry.selectedItem?.attributes {
                let data = BasketProductData(
                    price: presentBasketEntry.price,
                    name: presentBasketEntry.name.capitalizingFirstLetter(),
                    description: presentBasketEntry.detailedDescription,
                    pictureURL: presentBasketEntry.pictureURL,
                    sharedRecipeCount: Int(presentBasketEntry.shareInRecipeCount),
                    unitPrice: presentBasketEntry.unitPrice,
                    isReloading: productVM.state?.status == .locked || productVM.state?.status == .loading,
                    ean: item.ean
                )
                productTemplate.content(
                    params: BasketProductParameters(
                        data: data,
                        quantity: $productVM.productQuantity,
                        onDeleteProduct: productVM.ignoreProduct,
                        onQuantityChanged: productVM.updateQuantity,
                        onChangeProduct: {
                            productVM.replaceProduct()
                            replaceProduct()
                        }
                    )
                )
            } else { EmptyView() } // this should never happen
        }
    }
}
