//
//  TypeSafeBasketRecipeOverview.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafeBasketRecipeOverview: BasketRecipeOverviewProtocol {
    private let _content: (BasketRecipeOverviewParameters) -> AnyView

    public init<T: BasketRecipeOverviewProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: BasketRecipeOverviewParameters) -> some View {
        _content(params)
    }
}
