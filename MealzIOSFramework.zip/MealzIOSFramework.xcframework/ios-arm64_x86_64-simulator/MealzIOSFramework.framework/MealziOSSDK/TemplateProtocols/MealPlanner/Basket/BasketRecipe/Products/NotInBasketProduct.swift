//
//  NotInBasketProduct.swift
//
//
//  Created by Diarmuid McGonagle on 09/01/2024.
//

import Foundation
import mealzcore
import SwiftUI

@available(iOS 14, *)
internal struct NotInBasketProduct<ProductTemplate: NotInBasketProductProtocol>: View {
    private let productTemplate: ProductTemplate
    private let guestsCount: Int
    private let defaultRecipeGuest: Int
    @StateObject private var productVM: BasketEntryInRecipeVM
    
    internal init(
        productVM: BasketEntryInRecipeViewModel,
        productTemplate: ProductTemplate,
        guestsCount: Int,
        defaultRecipeGuest: Int
    ) {
        _productVM = StateObject(wrappedValue: BasketEntryInRecipeVM(instance: productVM))
        self.productTemplate = productTemplate
        self.guestsCount = guestsCount
        self.defaultRecipeGuest = defaultRecipeGuest
    }
    
    internal var body: some View {
        func callback(available: Bool) -> (() -> Void)? {
            if !available { return nil }
            return {
                productVM.addProduct()
            }
        }
        return VStack {
            if let entry = productVM.entry {
                let ingredient = productVM.ingredient
                productTemplate.content(
                    params: NotInBasketProductParameters(
                    ingredientName: ingredient.name,
                    ingredientQuantity: ingredient.attributes?.quantity ?? "0",
                    ingredientUnit: ingredient.attributes?.unit ?? "",
                    guestsCount: guestsCount,
                    defaultRecipeGuest: defaultRecipeGuest,
                    onAddToBasket: callback(available: !entry.isUnavailable)
                )
                    )
            } else { EmptyView() } // this should never happen
        }
    }
}
