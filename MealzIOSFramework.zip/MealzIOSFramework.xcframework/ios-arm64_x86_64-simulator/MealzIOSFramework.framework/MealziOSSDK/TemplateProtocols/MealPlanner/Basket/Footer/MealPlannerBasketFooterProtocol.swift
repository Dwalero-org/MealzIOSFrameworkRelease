//
//  MealPlannerBasketFooterProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Basket Footer, where users can navigate to a new page.
 
 - onNavigateToRecap: () -> Void: A closure that navigates the user to the Meal Planner Recap page
 - onNavigateToBasket: () -> Void: A closure that navigates the user directly to their Basket to see what has been added to their cart
 
 */
@available(iOS 14, *)
public protocol MealPlannerBasketFooterProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerBasketFooterParamaters) -> Content
}

public struct MealPlannerBasketFooterParamaters {
    public let footerHeight: CGFloat
    public let totalPrice: Double
    public let isLoading: Bool
    public let onNavigateToRecap: () -> Void
    public let onNavigateToBasket: () -> Void
    
    public init(
        footerHeight: CGFloat,
        totalPrice: Double,
        isLoading: Bool,
        onNavigateToRecap: @escaping () -> Void,
        onNavigateToBasket: @escaping () -> Void
    ) {
        self.footerHeight = footerHeight
        self.totalPrice = totalPrice
        self.isLoading = isLoading
        self.onNavigateToRecap = onNavigateToRecap
        self.onNavigateToBasket = onNavigateToBasket
    }
}
