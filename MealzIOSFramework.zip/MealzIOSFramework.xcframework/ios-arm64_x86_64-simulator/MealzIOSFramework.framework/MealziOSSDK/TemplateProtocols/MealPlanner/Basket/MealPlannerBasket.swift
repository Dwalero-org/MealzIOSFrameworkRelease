//
//  MealPlannerBasket.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 07/06/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Meal Planner basket & their recipes in their cart.
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerBasketParametersProtocol``, usually the default ``MealPlannerBasketParameters``
 - basketRecipesParams:  An implementation of ``BasketRecipeParametersProtocol``, usually the default ``BasketRecipeParameters``.
 This will contain the templates for the recipe card overviews, products, etc
 - gridConfig:  A ``BasketRecipesGridConfig`` which selects all the bounds for the basket recipes list, such as the spacing, recipe card height & width, etc.
 
 */
@available(iOS 14, *)
public struct MealPlannerBasket<
    MealPlannerBasketParameters: MealPlannerBasketParametersProtocol,
    BasketRecipesParameters: BasketRecipeParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MealPlannerBasketParameters
    private let basketRecipesParams: BasketRecipesParameters
    private let baseViews: BaseViews
    private let gridConfig: BasketRecipesGridConfig
    @StateObject private var mealPlannerBasketVM = MealPlannerBasketPreviewVM()
    
    public init(
        params: MealPlannerBasketParameters,
        basketRecipesParams: BasketRecipesParameters,
        baseViews: BaseViews,
        gridConfig: BasketRecipesGridConfig
    ) {
        self.params = params
        self.basketRecipesParams = basketRecipesParams
        self.baseViews = baseViews
        self.gridConfig = gridConfig
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            ComponentUIStateWrapperView(uiState: mealPlannerBasketVM.state?.status) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                baseViews.empty.content(params: BaseEmptyParameters())
            } successView: {
                successContent()
            }
        }
        .onAppear(perform: { mealPlannerBasketVM.registerListeners()})
        .onDisappear(perform: { mealPlannerBasketVM.dispose()})
    }
    
    func successContent() -> some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(mealPlannerBasketVM.recipesVMs) { recipeVM in
                        ExpandableBasketRecipe(
                            params: basketRecipesParams,
                            recipeRowViewModel: recipeVM,
                            gridConfig: gridConfig)
                    }
                    .padding(.vertical, gridConfig.recipeSpacing.height)
                    .padding(.horizontal, gridConfig.recipeSpacing.width)
                }
            }
            .padding([.bottom], gridConfig.heightOfFooter)
            params.footer.content(
                params: MealPlannerBasketFooterParamaters(
                    footerHeight: gridConfig.heightOfFooter,
                    totalPrice: mealPlannerBasketVM.totalPriceS,
                    isLoading: mealPlannerBasketVM.isLoading,
                    onNavigateToRecap: params.actions.onNavigateToRecap,
                    onNavigateToBasket: params.actions.onNavigateToBasket
                )
            )
        }
    }
}
