//
//  TypeSafeMealPlannerBasketFooter.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeMealPlannerBasketFooter: MealPlannerBasketFooterProtocol {
    private let _content: (MealPlannerBasketFooterParamaters) -> AnyView

    public init<T: MealPlannerBasketFooterProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MealPlannerBasketFooterParamaters) -> some View {
        _content(params)
    }
}
