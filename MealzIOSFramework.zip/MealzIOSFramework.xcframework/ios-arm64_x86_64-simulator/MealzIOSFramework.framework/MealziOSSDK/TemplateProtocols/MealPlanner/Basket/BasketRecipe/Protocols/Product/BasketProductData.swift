//
//  BasketProductData.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore

/**
 An object containing all the items the Basket Product card needs.
 
 - price: Double -> The price of the product
 - name: String ->  Name of the product
 - description: String -> Description of the product
 - pictureURL: URL ->  Checked imageURL  of the product
 - sharedRecipeCount: Int ->  How many other recipes share this product
 - pricePerUnit: Double -> Usually Price per KG
 - isLoading: Bool -> If the product is currently set to loading from the core

 */
public struct BasketProductData {
    public let price: Double
    public let name: String
    public let description: String
    public let pictureURL: URL
    public let sharedRecipeCount: Int
    public let unitPrice: Double
    public let isReloading: Bool
    public let ean: String

    public init(
        price: Double,
        name: String,
        description: String,
        pictureURL: URL,
        sharedRecipeCount: Int,
        unitPrice: Double,
        isReloading: Bool,
        ean: String
    ) {
        self.price = price
        self.name = name
        self.description = description
        self.pictureURL = pictureURL
        self.sharedRecipeCount = sharedRecipeCount
        self.unitPrice = unitPrice
        self.isReloading = isReloading
        self.ean = ean
    }
}

public struct FakeBasketProductData {
    public init() {}
    public func generateSingleRandomData() -> BasketProductData {
        let randomTitles = ["Tibo's mustard", "Vincent's ketchup", "Tom's Russian Sauce", "Vianney's Cream", "Kevin's Wasabi", "Aglae's BBQ Sauce", "Camille A's Sun-dried tomato", "Didi's Potato"]
        let randomIndex = Int.random(in: 0..<randomTitles.count)
        let randomDouble = Double.random(in: 0..<40)
        let roundedDouble = Double(round(100*randomDouble)/100)
        return BasketProductData(
            price: randomDouble,
            name: randomTitles[randomIndex],
            description: "My description",
            pictureURL: (URL(string: "https://picsum.photos/400/300") ?? URL(string: ""))!,
            sharedRecipeCount: randomIndex,
            unitPrice: roundedDouble,
            isReloading: false,
            ean: ""
           )
    }
    public func createListOfRandomDatas() -> [BasketProductData] {
        var data = [BasketProductData]()
        for _ in 0..<5 {
            data.append(generateSingleRandomData())
        }
        return data
    }
}
