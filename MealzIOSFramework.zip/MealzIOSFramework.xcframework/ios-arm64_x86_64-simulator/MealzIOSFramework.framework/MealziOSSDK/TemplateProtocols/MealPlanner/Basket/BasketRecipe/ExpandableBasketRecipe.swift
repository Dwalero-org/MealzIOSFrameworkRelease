//
//  ExpandableBasketRecipe.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 An ExpandableBasketRecipe that handles basket recipe overview, products in basket, products out of basket.
 
 Mandatory Parameters:
 - params:  An implementation of ``BasketRecipeParametersProtocol``
 - recipe: Recipe -> The Recipe that the view will display
 - gridConfig:  An implementation of ``BasketRecipesGridConfig`` which has the view constraints like spacing
 
 */
@available(iOS 14, *)
public struct ExpandableBasketRecipe<BasketRecipeParameters: BasketRecipeParametersProtocol>: View {
    private let params: BasketRecipeParameters
    private let gridConfig: BasketRecipesGridConfig
    
    @StateObject private var recipeRowViewModel: MealPlannerBasketPreviewRecipeRowVM
    @SwiftUI.State var showProducts = false
    @SwiftUI.State var replacingProduct = false // this is used to prevent STOP listening to events on replacing a product
    
    public init(
        params: BasketRecipeParameters,
        recipeRowViewModel: MealPlannerBasketPreviewRecipeRowViewModel,
        gridConfig: BasketRecipesGridConfig
    ) {
        self.params = params
        self.gridConfig = gridConfig
        _recipeRowViewModel = StateObject(wrappedValue: MealPlannerBasketPreviewRecipeRowVM(instance: recipeRowViewModel))
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            UIStateWrapperView(uiState: recipeRowViewModel.state?.recipe) {
                params.recipeOverviewLoading.content(params: RecipeCardLoadingParameters(
                    recipeCardDimensions: gridConfig.recipeOverviewDimensions
                ))
            }
        emptyView: { /* there is no empty state */ }
        successView: { successContent() }
        }
        .onAppear {
            recipeRowViewModel.instance.registerListeners()
            replacingProduct = false
        }
        .onDisappear {
            if !replacingProduct { recipeRowViewModel.instance.dispose() }
        }
    }
    
    func successContent() -> some View {
        return VStack {
            if let recipe = recipeRowViewModel.recipe, let rowState = recipeRowViewModel.recipeRowStateS {
                params.recipeOverview.content(
                    params: BasketRecipeOverviewParameters(
                        recipeCardDimensions: gridConfig.recipeOverviewDimensions,
                        data: BasketRecipeData(
                            recipe: recipe,
                            price: rowState.recipePrice,
                            guests: recipeRowViewModel.guests,
                            isReloading: rowState.recipePriceRefreshing || rowState.recipeDeleting || recipeRowViewModel.guestCountUpdating,
                            totalProductCount: Int(rowState.allFoundProductCount),
                            isExpandable: gridConfig.isExpandable,
                            isExpanded: showProducts
                        ),
                        onDeleteRecipe: {
                            recipeRowViewModel.instance.deleteRecipe()
                        }, onExpand: {
                            withAnimation { showProducts.toggle() }
                        }, onUpdateGuests: { guestNumber in
                            recipeRowViewModel.instance.setEvent(event: DynamicRecipeDetailContractEvent.UpdateGuests(guests: Int32(guestNumber)))
                        }, onShowRecipeDetails: { value in
                            params.actions.onShowRecipeDetails(value)
                        }
                    )
                )
                if showProducts {
                    ForEach(recipeRowViewModel.foundProducts) { productVM in
                        BasketProduct(
                            productVM: productVM,
                            productTemplate: params.basketProduct) {
                                replacingProduct = true
                                params.actions.onReplaceProduct(productVM.ingredient.id)
                            }
                            .padding(.vertical, gridConfig.productSpacing.height)
                            .padding(.horizontal, gridConfig.productSpacing.width)
                    }
                    .animation(Animation.spring())
                    .padding(.bottom, Dimension.sharedInstance.mPadding)
                    if !recipeRowViewModel.deletedProducts.isEmpty {
                        NotInBasketTitle(
                            products: recipeRowViewModel.deletedProducts,
                            title: String(format: String.localizedStringWithFormat(
                                Localization.basket.removedProducts(
                                    numberOfProducts: Int32(recipeRowViewModel.deletedProducts.count)).localised, recipeRowViewModel.deletedProducts.count), recipeRowViewModel.deletedProducts.count),
                            guestsCount: recipeRowViewModel.guests,
                            defaultRecipeGuest: Int(recipeRowViewModel.recipe?.attributes?.numberOfGuests ?? 4),
                            productTemplate: params.removedIngredients,
                            buttonTemplate: params.removedIngredientsToggleButton)
                    }
                    if !recipeRowViewModel.oftenDeletedProducts.isEmpty {
                        NotInBasketTitle(
                            products: recipeRowViewModel.oftenDeletedProducts,
                            title: String(format: String.localizedStringWithFormat(
                                Localization.basket.ownedProducts(
                                    numberOfProducts: Int32(recipeRowViewModel.oftenDeletedProducts.count)).localised,
                                recipeRowViewModel.oftenDeletedProducts.count), recipeRowViewModel.oftenDeletedProducts.count),
                            guestsCount: recipeRowViewModel.guests,
                            defaultRecipeGuest: Int(recipeRowViewModel.recipe?.attributes?.numberOfGuests ?? 4),
                            productTemplate: params.ingredientsAtHome,
                            buttonTemplate: params.ingredientsAtHomeToggleButton)
                    }
                    if !recipeRowViewModel.unavailableProducts.isEmpty {
                        NotInBasketTitle(
                            products: recipeRowViewModel.unavailableProducts,
                            title: String(format: String.localizedStringWithFormat(
                                Localization.basket.unavailableProducts(
                                    numberOfProducts: Int32(recipeRowViewModel.unavailableProducts.count)).localised,
                                recipeRowViewModel.unavailableProducts.count), recipeRowViewModel.unavailableProducts.count),
                            guestsCount: recipeRowViewModel.guests,
                            defaultRecipeGuest: Int(recipeRowViewModel.recipe?.attributes?.numberOfGuests ?? 4),
                            productTemplate: params.unavailableIngredients,
                            buttonTemplate: params.unavailableIngredientsToggleButton)
                    }
                }
            }
        }.background(showProducts ? Color.white : Color.clear)
    }
}
