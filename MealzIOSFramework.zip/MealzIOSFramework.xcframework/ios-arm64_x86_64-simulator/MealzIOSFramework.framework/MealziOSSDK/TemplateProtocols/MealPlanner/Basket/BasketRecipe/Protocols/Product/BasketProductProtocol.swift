//
//  BasketProductProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 An object containing all the items the Basket Product card needs.
 
 - quantity: Binding<Int> ->  Binding integer of how many items of the current product are in the basket
 - data: BasketProductData -> an implementation of the ``BasketProductData``
 - actions: BasketRecipeActions -> an implementation of the ``BasketProductActions``
 */
@available(iOS 14, *)
public protocol BasketProductProtocol {
    associatedtype Content: View
    func content(params: BasketProductParameters) -> Content
}

@available(iOS 14, *)
public struct BasketProductParameters {
    public let data: BasketProductData
    public var quantity: Binding<Int>
    public let onDeleteProduct: () -> Void
    public let onQuantityChanged: (Int) -> Void
    public let onChangeProduct: () -> Void
    
    public init(
        data: BasketProductData,
        quantity: Binding<Int>,
        onDeleteProduct: @escaping () -> Void,
        onQuantityChanged: @escaping (Int) -> Void,
        onChangeProduct: @escaping () -> Void
    ) {
        self.data = data
        self.quantity = quantity
        self.onDeleteProduct = onDeleteProduct
        self.onQuantityChanged = onQuantityChanged
        self.onChangeProduct = onChangeProduct
    }
}
