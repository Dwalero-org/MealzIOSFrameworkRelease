//
//  NotInBasketProductProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the optional or unavailable ingredients in the Basket Recipe.
 These are the ingredients that have already been removed from the basket or are presumed to be owned at home (like salt)

 - item: BasketEntry -> the ingredient being referenced, such as "Bananas"
 - onAddToBasket:  (() -> Void)? -> A closure that adds the product to the basket if it is feasible.
 In your implementation, you should check if onAddToBasket exists before calling it
 
 */
@available(iOS 14, *)
public protocol NotInBasketProductProtocol {
    associatedtype Content: View
    func content(params: NotInBasketProductParameters) -> Content
}

public struct NotInBasketProductParameters {
    public let ingredientName: String
    public let ingredientQuantity: String
    public let ingredientUnit: String
    public let guestsCount: Int
    public let defaultRecipeGuest: Int
    public var onAddToBasket: (() -> Void)?
 
    public init(
        ingredientName: String,
        ingredientQuantity: String,
        ingredientUnit: String,
        guestsCount: Int,
        defaultRecipeGuest: Int,
        onAddToBasket: (() -> Void)? = nil
    ) {
        self.ingredientName = ingredientName
        self.ingredientQuantity = ingredientQuantity
        self.ingredientUnit = ingredientUnit
        self.guestsCount = guestsCount
        self.defaultRecipeGuest = defaultRecipeGuest
        self.onAddToBasket = onAddToBasket
    }
}
