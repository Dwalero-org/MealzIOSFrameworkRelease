//
//  TypeSafeNotInBasketProduct.swift
//
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafeNotInBasketProduct: NotInBasketProductProtocol {
    private let _content: (NotInBasketProductParameters) -> AnyView
    
    public init<T: NotInBasketProductProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }
    
    public func content(params: NotInBasketProductParameters) -> some View {
        _content(params)
    }
}
