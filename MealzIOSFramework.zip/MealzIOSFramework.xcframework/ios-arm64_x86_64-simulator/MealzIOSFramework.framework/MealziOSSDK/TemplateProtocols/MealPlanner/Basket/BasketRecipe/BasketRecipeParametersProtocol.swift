//
//  BasketRecipeParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the BasketRecipe.
 
 - recipeOverview:  An implementation of ``BasketRecipeOverviewProtocol``
 - recipeOverviewLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - basketProduct:  An implementation of ``BasketProductProtocol``
 - ingredientsAtHomeToggleButton:  An implementation of ``BaseButtonProtocol``
 - removedIngredientsToggleButton: An implementation of ``BaseButtonProtocol``
 - unavailableIngredientsToggleButton: An implementation of ``BaseButtonProtocol``
 - ingredientsAtHome:  An implementation of ``OptionalIngredientsProtocol``
 - removedIngredients: An implementation of ``OptionalIngredientsProtocol``
 - unavailableIngredients: An implementation of ``UnavailableIngredientsProtocol``
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onReplaceProduct: (String) -> Void: A closure that opens the ItemSelector page where a user can replace an ingredient with a different product from a different brand. 
 This will navigate to a standalone page of ItemSelector.
 
 */
@available(iOS 14, *)
public protocol BasketRecipeParametersProtocol {
    associatedtype RecipeOverview: BasketRecipeOverviewProtocol
    associatedtype RecipeOverviewLoading: RecipeCardLoadingProtocol
    associatedtype BasketProduct: BasketProductProtocol
    associatedtype IngredientsAtHomeToggleButton: BaseButtonProtocol
    associatedtype RemovedIngredientsToggleButton: BaseButtonProtocol
    associatedtype UnavailableIngredientsToggleButton: BaseButtonProtocol
    associatedtype IngredientsAtHome: NotInBasketProductProtocol
    associatedtype RemovedIngredients: NotInBasketProductProtocol
    associatedtype UnavailableIngredients: NotInBasketProductProtocol
    
    var recipeOverview: RecipeOverview { get }
    var recipeOverviewLoading: RecipeOverviewLoading { get }
    var basketProduct: BasketProduct { get }
    var ingredientsAtHomeToggleButton: IngredientsAtHomeToggleButton { get }
    var removedIngredientsToggleButton: RemovedIngredientsToggleButton { get }
    var unavailableIngredientsToggleButton: UnavailableIngredientsToggleButton { get }
    var ingredientsAtHome: IngredientsAtHome { get }
    var removedIngredients: RemovedIngredients { get }
    var unavailableIngredients: UnavailableIngredients { get }
    
    var actions: BasketRecipeActions { get set }
}

public struct BasketRecipeActions {
    public var onShowRecipeDetails: (String) -> Void
    public var onReplaceProduct: (String) -> Void
 
    public init(onShowRecipeDetails: @escaping (String) -> Void, onReplaceProduct: @escaping (String) -> Void) {
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onReplaceProduct = onReplaceProduct
    }
}
