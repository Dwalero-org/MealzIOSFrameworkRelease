//
//  MealPlannerBasketParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Meal Planner Basket Page.
 
 - footer:  An implementation of ``MealPlannerBasketFooterProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onNavigateToRecap: () -> Void: A closure that navigates the user to the Meal Planner Recap page
 - onNavigateToBasket: () -> Void: A closure that navigates the user directly to their Basket to see what has been added to their cart
 
 */
@available(iOS 14, *)
public protocol MealPlannerBasketParametersProtocol {
    associatedtype FooterTemplate: MealPlannerBasketFooterProtocol
    
    var footer: FooterTemplate { get }
    
    var actions: MealPlannerBasketActions { get set }
}

public struct MealPlannerBasketActions {
    public var onNavigateToRecap: () -> Void
    public var onNavigateToBasket: () -> Void
 
    public init(onNavigateToRecap: @escaping () -> Void, onNavigateToBasket: @escaping () -> Void) {
        self.onNavigateToRecap = onNavigateToRecap
        self.onNavigateToBasket = onNavigateToBasket
    }
}
