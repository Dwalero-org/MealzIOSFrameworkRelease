//
//  BasketRecipesGridConfig.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 Configuration for the grid constraints of the BasketRecipes List
 
 Mandatory Parameters:
 - recipeSpacing: CGSize -> The vertical & horizontal space between each recipe. ex: CGSize(width: 5, height: 6)
 - productSpacing: CGSize -> The vertical & horizontal space between each product. ex: CGSize(width: 5, height: 6)
 - recipeOverviewDimensions: CGSize -> the width & height of each recipe overview
 - isExpandable: Bool -> decides whether or not the products can be toggled to preserve screen space

 */
@available(iOS 14, *)
public struct BasketRecipesGridConfig {
    let recipeSpacing: CGSize
    let productSpacing: CGSize
    let recipeOverviewDimensions: CGSize
    let heightOfFooter: CGFloat
    let isExpandable: Bool
    
    public init(
        recipeSpacing: CGSize = CGSize(width: 4, height: 4),
        productSpacing: CGSize = CGSize(width: 4, height: 4),
        recipeOverviewDimensions: CGSize = CGSize(width: 300, height: 150),
        heightOfFooter: CGFloat = 80,
        isExpandable: Bool = true
    ) {
        self.recipeSpacing = recipeSpacing
        self.productSpacing = productSpacing
        self.recipeOverviewDimensions = recipeOverviewDimensions
        self.heightOfFooter = heightOfFooter
        self.isExpandable = isExpandable
    }
}
