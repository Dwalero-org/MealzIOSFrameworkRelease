//
//  BasketRecipeOverviewProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 An object containing all the items the BasketRecipe card needs.
 
 - recipeCardDimensions: CGSize ->  The width & height of the recipe overview
 - data: BasketRecipeData -> an implementation of the ``BasketRecipeData``
 - actions: BasketRecipeActions -> an implementation of the ``BasketRecipeActions``
 */
@available(iOS 14, *)
public protocol BasketRecipeOverviewProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: BasketRecipeOverviewParameters) -> Content
}

public struct BasketRecipeOverviewParameters {
    public let recipeCardDimensions: CGSize
    public let data: BasketRecipeData
    public let onDeleteRecipe: () -> Void
    public let onExpand: () -> Void
    public let onUpdateGuests: (Int) -> Void
    public let onShowRecipeDetails: (String) -> Void
 
    public init(
        recipeCardDimensions: CGSize,
        data: BasketRecipeData,
        onDeleteRecipe: @escaping () -> Void,
        onExpand: @escaping () -> Void,
        onUpdateGuests: @escaping (Int) -> Void,
        onShowRecipeDetails: @escaping (String) -> Void
    ) {
        self.recipeCardDimensions = recipeCardDimensions
        self.data = data
        self.onDeleteRecipe = onDeleteRecipe
        self.onExpand = onExpand
        self.onUpdateGuests = onUpdateGuests
        self.onShowRecipeDetails = onShowRecipeDetails
    }
}
