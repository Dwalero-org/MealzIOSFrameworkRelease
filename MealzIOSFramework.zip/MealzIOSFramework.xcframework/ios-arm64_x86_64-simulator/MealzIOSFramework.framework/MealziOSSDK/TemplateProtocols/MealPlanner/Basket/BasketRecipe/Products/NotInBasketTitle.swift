//
//  NotInBasketTitle.swift
//
//
//  Created by Diarmuid McGonagle on 09/01/2024.
//

import Foundation
import mealzcore
import SwiftUI

@available(iOS 14, *)
internal struct NotInBasketTitle<
    ProductTemplate: NotInBasketProductProtocol, ButtonTemplate: BaseButtonProtocol
>: View {
    private let productTemplate: ProductTemplate
    private let buttonTemplate: ButtonTemplate
    @SwiftUI.State var isExpanded: Bool = false
    private let products: [BasketEntryInRecipeViewModel]
    private let title: String
    private let guestsCount: Int
    private let defaultRecipeGuest: Int
    
    internal init(
        products: [BasketEntryInRecipeViewModel],
        title: String,
        guestsCount: Int,
        defaultRecipeGuest: Int,
        productTemplate: ProductTemplate,
        buttonTemplate: ButtonTemplate
    ) {
        self.products = products
        self.title = title
        self.productTemplate = productTemplate
        self.buttonTemplate = buttonTemplate
        self.defaultRecipeGuest = defaultRecipeGuest
        self.guestsCount = guestsCount
    }
    
    internal var body: some View {
        buttonTemplate.content(
            params: BaseButtonParameters(
                buttonText: title,
                buttonPressed: isExpanded,
                onButtonAction: { isExpanded.toggle() }
            )
        )
        if isExpanded {
            ForEach(products) { product in
                NotInBasketProduct(
                    productVM: product,
                    productTemplate: productTemplate,
                    guestsCount: 4,
                    defaultRecipeGuest: 4)
            }
        }
    }
}
