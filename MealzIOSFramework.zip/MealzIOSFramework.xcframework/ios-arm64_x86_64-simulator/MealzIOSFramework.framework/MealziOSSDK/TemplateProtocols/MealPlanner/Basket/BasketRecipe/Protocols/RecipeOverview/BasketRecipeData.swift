//
//  BasketRecipeData.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore

/**
 An object containing all the items the BasketRecipe card needs.
 
 - id: String ->  The recipeID of the meal. This is derived from the passed in recipe
 - recipe: Recipe -> The Recipe object of the meal
 - price: Double -> The price of the meal
 - guests: Int ->  The number of guests associated with the recipe
 - isReloading: Bool -> Boolean to indicate if the current recipe is being updated. this should be used to give feedback to the user after actions
 - totalProductCount: Int -> The total amount of articles in the basket from this recipe
 - isExpandable: Bool -> If the ingredients are able to be toggled in view & out of view
 - isExpanded: Bool -> If the ingredients are currently being shown

 */
public struct BasketRecipeData: Identifiable {
    public var id: String
    public let recipe: Recipe
    public let price: Double
    public let guests: Int
    public let isReloading: Bool
    public let totalProductCount: Int
    public let isExpandable: Bool
    public let isExpanded: Bool

    public init(
        recipe: Recipe,
        price: Double,
        guests: Int,
        isReloading: Bool,
        totalProductCount: Int,
        isExpandable: Bool,
        isExpanded: Bool
    ) {
        self.id = recipe.id
        self.recipe = recipe
        self.price = price
        self.guests = guests
        self.isReloading = isReloading
        self.totalProductCount = totalProductCount
        self.isExpandable = isExpandable
        self.isExpanded = isExpanded
    }
}
