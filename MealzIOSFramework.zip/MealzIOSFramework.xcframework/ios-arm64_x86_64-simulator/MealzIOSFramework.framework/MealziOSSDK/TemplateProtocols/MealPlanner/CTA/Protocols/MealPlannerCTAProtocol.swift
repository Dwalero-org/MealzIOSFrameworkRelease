//
//  MealPlannerCTAProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the Meal Planner Call To Action that navigates users to the Meal Planner Feature.
 Typically this component is going to appear on the home page of a client app or in the catalog.
 
 - onTapGesture: () -> Void: A closure that navigates the user to the Meal Planner Feature
 
 */
@available(iOS 14, *)
public protocol MealPlannerCTAProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MealPlannerCTAViewParameters) -> Content
}

public struct MealPlannerCTAViewParameters {
    public let onTapGesture: () -> Void
    
    public init(onTapGesture: @escaping () -> Void) {
        self.onTapGesture = onTapGesture
    }
}
