//
//  MealPlannerCTAParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

/**
 A protocol defining the necessary parameters for the Meal Planner Call To Action, which navigates the users to the Meal Planner
 
 - callToAction: An implementation of ``MealPlannerCTAProtocol``
 
 - onNavigateToMealPlannerForm: () -> Void: A closure that navigates the user to the Meal Planner Feature
 
 */
@available(iOS 14, *)
public protocol MealPlannerCTAParametersProtocol {
    associatedtype CallToAction: MealPlannerCTAProtocol
    
    var callToAction: CallToAction { get }
    
    var actions: MealPlannerCTAActions { get set }
}

public struct MealPlannerCTAActions {
    public var onNavigateToMealPlannerForm: () -> Void
    
    public init(onNavigateToMealPlannerForm: @escaping () -> Void) {
        self.onNavigateToMealPlannerForm = onNavigateToMealPlannerForm
    }
}
