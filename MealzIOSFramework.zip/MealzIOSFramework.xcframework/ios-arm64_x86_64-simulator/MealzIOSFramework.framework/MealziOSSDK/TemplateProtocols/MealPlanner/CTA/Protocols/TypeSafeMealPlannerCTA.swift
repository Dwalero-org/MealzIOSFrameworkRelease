//
//  TypeSafeMealPlannerCTA.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeMealPlannerCTA: MealPlannerCTAProtocol {
    private let _content: (MealPlannerCTAViewParameters) -> AnyView

    public init<T: MealPlannerCTAProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MealPlannerCTAViewParameters) -> some View {
        _content(params)
    }
}
