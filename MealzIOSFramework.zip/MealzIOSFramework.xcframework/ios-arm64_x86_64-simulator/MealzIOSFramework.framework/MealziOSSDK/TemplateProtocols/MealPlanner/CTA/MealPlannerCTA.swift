//
//  MealPlannerCTA.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/04/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A view showing the Meal Planner Call To Action that navigates users to the Meal Planner Feature
 
 Mandatory Parameters:
 - params:  An implementation of ``MealPlannerCTAParametersProtocol``, usually the default ``MealPlannerCTAParameters``
 
 */
@available(iOS 14, *)
public struct MealPlannerCTA<
    MealPlannerCTAPageParameters: MealPlannerCTAParametersProtocol
>: View {
    private let params: MealPlannerCTAPageParameters
    public init(params: MealPlannerCTAPageParameters) {
        self.params = params
    }
    public var body: some View {
        HStack {
            params.callToAction.content(
                params: MealPlannerCTAViewParameters(
                    onTapGesture: params.actions.onNavigateToMealPlannerForm
                )
            )
        }
    }
}
