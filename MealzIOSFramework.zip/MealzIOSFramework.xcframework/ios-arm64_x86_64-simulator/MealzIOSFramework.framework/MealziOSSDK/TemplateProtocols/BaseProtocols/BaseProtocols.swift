//
//  BaseProtocols.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation

/**
 A protocol defining the necessary parameters for each standalone page
 
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``

 */
@available(iOS 14, *)
public protocol BaseViewsProtocol {
    associatedtype Loading: LoadingProtocol
    associatedtype Empty: EmptyProtocol
    associatedtype Background: BackgroundProtocol

    var loading: Loading { get }
    var empty: Empty { get }
    var background: Background { get }
}
