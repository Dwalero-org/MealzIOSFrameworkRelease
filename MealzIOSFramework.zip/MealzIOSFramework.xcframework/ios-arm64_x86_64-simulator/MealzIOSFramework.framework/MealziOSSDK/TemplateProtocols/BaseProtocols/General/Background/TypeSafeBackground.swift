//
//  TypeSafeBackground.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeBackground: BackgroundProtocol {
    private let _content: (BaseBackgroundParameters) -> AnyView

    public init<T: BackgroundProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params)
                .frame(maxWidth: .infinity, maxHeight: .infinity)) }
    }

    public func content(params: BaseBackgroundParameters) -> some View {
        _content(params) }
}
