//
//  BaseButtonProtocol.swift
//  
//
//  Created by didi on 28/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for an average button
 
 - buttonText: String -> text that displays on the button
 - onButtonAction: @escaping () -> Void A closure that executes the function passed in
 */
@available(iOS 14, *)
public protocol BaseButtonProtocol {
    associatedtype Content: View
    func content(params: BaseButtonParameters) -> Content
}

public struct BaseButtonParameters {
    public let buttonText: String
    public let buttonPressed: Bool
    public let onButtonAction: () -> Void
    
    public init(
        buttonText: String,
        buttonPressed: Bool,
        onButtonAction: @escaping () -> Void
    ) {
        self.buttonText = buttonText
        self.buttonPressed = buttonPressed
        self.onButtonAction = onButtonAction
    }
}
