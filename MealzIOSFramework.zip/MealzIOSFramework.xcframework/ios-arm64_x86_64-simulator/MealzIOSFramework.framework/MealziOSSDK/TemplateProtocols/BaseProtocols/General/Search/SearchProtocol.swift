//
//  SearchProtocol.swift
//  
//
//  Created by didi on 21/09/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for an average button
 
 - searchText: Binding<String> -> text result from the user input, bindable
 - onApply: @escaping () -> Void: A closure that executes the function passed in
 */
@available(iOS 14, *)
public protocol SearchProtocol {
    associatedtype Content: View
    func content(params: SearchParameters) -> Content
}

@available(iOS 14, *)
public struct SearchParameters {
    public let searchText: Binding<String>
    public let onApply: () -> Void
    
    public init(searchText: Binding<String>, onApply: @escaping () -> Void) {
        self.searchText = searchText
        self.onApply = onApply
    }
}
