//
//  TypeSafeError.swift
//  MiamIOSFramework
//
//  Created by Miam on 19/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeError: ErrorProtocol {
    private let _content: (BaseErrorParameters) -> AnyView

    public init<T: ErrorProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: BaseErrorParameters) -> some View {
        _content(params)
    }
}
