//
//  EmptyProtocol.swift
//
//
//  Created by didi on 08/08/2023.
//
import SwiftUI
import mealzcore

/**
 A protocol defining the Loader view while content is loaded in. The default is just a round progress loader
 
 - onOptionalCallBack: (() -> Void)? -> An closure for pages that need to redirect on empty (like empty favorites, myMeals)
 */
@available(iOS 14, *)
public protocol EmptyProtocol {
    associatedtype Content: View
    func content(params: BaseEmptyParameters) -> Content
}

public struct BaseEmptyParameters {
    public let onOptionalCallback: (() -> Void)?
    
    public init(onOptionalCallback: (() -> Void)? = nil) {
        self.onOptionalCallback = onOptionalCallback
    }
}
