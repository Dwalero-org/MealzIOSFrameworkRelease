//
//  LoadingProtocol.swift
//
//
//  Created by didi on 08/08/2023.
//
import SwiftUI
import mealzcore

/**
 A protocol defining the Loader view while content is loaded in. The default is just a round progress loader
 */
@available(iOS 14, *)
public protocol LoadingProtocol {
    associatedtype Content: View
    func content(params: BaseLoadingParameters) -> Content
}

public struct BaseLoadingParameters {
    public init() {}
}
