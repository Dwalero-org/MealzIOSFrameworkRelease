//
//  TypeSafeEmpty.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeEmpty: EmptyProtocol {
    private let _content: (BaseEmptyParameters) -> AnyView

    public init<T: EmptyProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: BaseEmptyParameters) -> some View {
        _content(params)
    }
}
