//
//  RecipeCardLoadingProtocol.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 29/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for a loading recipe card
 
 - recipeCardDimensions: CGSize -> Sets the width & height for the loading recipe card
 */
@available(iOS 14, *)
public protocol RecipeCardLoadingProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeCardLoadingParameters) -> Content
}

public struct RecipeCardLoadingParameters {
    public let recipeCardDimensions: CGSize
    
    public init(recipeCardDimensions: CGSize) {
        self.recipeCardDimensions = recipeCardDimensions
    }
}
