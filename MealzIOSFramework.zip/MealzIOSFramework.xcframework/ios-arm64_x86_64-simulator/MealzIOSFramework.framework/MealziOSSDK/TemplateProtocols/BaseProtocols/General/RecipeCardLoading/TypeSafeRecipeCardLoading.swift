//
//  TypeSafeRecipeCardLoading.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeCardLoading: RecipeCardLoadingProtocol {
    private let _content: (RecipeCardLoadingParameters) -> AnyView

    public init<T: RecipeCardLoadingProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeCardLoadingParameters) -> some View {
        _content(params)
    }
}
