//
//  ErrorProtocol.swift
//  MiamIOSFramework
//
//  Created by Miam on 19/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public protocol ErrorProtocol {
    associatedtype Content: View
    func content(params: BaseErrorParameters) -> Content
}

public struct BaseErrorParameters {
    public let onOptionalCallback: (() -> Void)?
    
    public init(onOptionalCallback: (() -> Void)?) {
        self.onOptionalCallback = onOptionalCallback
    }
}
