//
//  TypeSafeBaseButton.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeBaseButton: BaseButtonProtocol {
    private let _content: (BaseButtonParameters) -> AnyView

    public init<T: BaseButtonProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: BaseButtonParameters) -> some View { _content(params) }
}
