//
//  BaseTitleProtocol.swift
//  
//
//  Created by didi on 21/09/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for an average title
 
 - title: String -> main text
 - subtitle: String? ->  subtext
 */
@available(iOS 14, *)
public protocol BaseTitleProtocol {
    associatedtype Content: View
    func content(params: TitleParameters) -> Content
}

public struct TitleParameters {
    public let title: String
    public let subtitle: String?

    public init(title: String, subtitle: String?) {
        self.title = title
        self.subtitle = subtitle
    }
}
