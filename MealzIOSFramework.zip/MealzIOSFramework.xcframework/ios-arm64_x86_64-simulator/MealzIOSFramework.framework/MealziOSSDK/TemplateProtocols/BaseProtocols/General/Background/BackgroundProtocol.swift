//
//  BackgroundProtocol.swift
//
//
//  Created by didi on 09/08/2023.
//
import SwiftUI
import mealzcore

/**
 A protocol defining the Background view while content is loaded in. The default is just white
 */
@available(iOS 14, *)
public protocol BackgroundProtocol {
    associatedtype Content: View
    func content(params: BaseBackgroundParameters) -> Content
}

public struct BaseBackgroundParameters {
    public init() {}
}
