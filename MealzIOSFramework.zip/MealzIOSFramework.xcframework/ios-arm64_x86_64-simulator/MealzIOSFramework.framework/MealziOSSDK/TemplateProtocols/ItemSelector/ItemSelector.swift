//
//  ItemSelector.swift
//  MiamIOSFramework
//
//  Created by Miam on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import mealzcore
import Foundation
import SwiftUI

/**
 A view showing the ItemSelector page where users can replace an ingredient
 
 Mandatory Parameters:
 - params:  An implementation of ``ItemSelectorParametersProtocol``, usually the default ``ItemSelectorParameters``
 - recipeId: String -> the corresponding RecipeId that the ingredient is associated with
 
 */
@available(iOS 14, *)
public struct ItemSelector<
    ItemSelectorParameters: ItemSelectorParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: ItemSelectorParameters
    private let baseViews: BaseViews
    private let ingredientId: String?
    private let basketEntryId: String?
    
    @ObservedObject var itemSelectorViewModel: ItemSelectorVM
    @SwiftUI.State var searchText: String = ""
    
    public init(
        params: ItemSelectorParameters,
        baseViews: BaseViews,
        ingredientId: String? = nil,
        basketEntryId: String? = nil
    ) {
        self.params = params
        self.baseViews = baseViews
        self.ingredientId = ingredientId
        self.basketEntryId = basketEntryId
        _itemSelectorViewModel = ObservedObject(wrappedValue: ItemSelectorVM())
        if let ingredientId, ingredientId != "" {
            itemSelectorViewModel.setIngredientId(id: ingredientId)
        } else if let basketEntryId, basketEntryId != "" {
            itemSelectorViewModel.setBasketEntryId(basketEntryId: basketEntryId)
        } else { 
            itemSelectorViewModel.setStandalone()
        }
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.searchBar.content(params: SearchParameters(
                    searchText: $searchText) {
                        itemSelectorViewModel.searchFromText(text: searchText)
                    })
                if let ingredientId {
                    params.title.content(
                        params: TitleParameters(
                            title: itemSelectorViewModel.ingredientName,
                            subtitle: QuantityFormatter.companion.readableFloatNumber(
                                value: QuantityFormatter.companion.realQuantities(
                                    quantity: String(itemSelectorViewModel.ingredientQuantity),
                                    currentGuest: Int32(itemSelectorViewModel.guestCount),
                                    recipeGuest: Int32(itemSelectorViewModel.defaultRecipeGuest)
                                ),
                                unit: itemSelectorViewModel.ingredientUnit)
                        )
                    )
                }
                ScrollView {
                    if let product = itemSelectorViewModel.selectedItem {
                        params.selectedProduct.content(params: ItemSelectorSelectedProductParameters(
                            product: product,
                            onSeeItemDetails: params.actions.onSeeProductDetails
                        ))
                    }
                    UIStateWrapperView(uiState: itemSelectorViewModel.localState?.items,
                   loadingView: {
                        baseViews.loading.content(params: BaseLoadingParameters())
                    }, emptyView: {
                        emptyContent()
                    }, successView: {
                        params.productOptions.content(params: ItemSelectorOptionProductsParameters(
                            products: itemSelectorViewModel.items,
                            onItemSelected: { item in
                                itemSelectorViewModel.setItem(item: item)
                                params.actions.onItemSelected()
                            }, onSeeItemDetails: params.actions.onSeeProductDetails)
                        )
                    }, idle: VStack {
                        idleContent()
                    })
                    .frame(maxWidth: .infinity)
                    .padding(.top, Dimension.sharedInstance.lPadding)
                }
                
            }
        }
        .onAppear {
            itemSelectorViewModel.registerListeners()
        }
        .onDisappear() {
            itemSelectorViewModel.dispose()
        }
    }
    
    func emptyContent() -> some View {
        let title = itemSelectorViewModel.emptyState == .noResultsAfterSearch
        ? Localization.itemSelector.notFoundTitle.localised
        : Localization.itemSelector.noSubstitution.localised
        let subtitle = itemSelectorViewModel.emptyState == .noResultsAfterSearch
        ? Localization.itemSelector.notFoundSubtitle.localised
        : nil
        return params.noResults.content(
            params: ItemSelectorNoResultsParameters(
                title: title,
                subtitle: subtitle,
                hasNoSubstitutes: itemSelectorViewModel.emptyState == .noSubstituteProducts,
                goBack: params.actions.onItemSelected)
        )
    }
    
    func idleContent() -> some View {
        let title = Localization.itemSelector.search.localised
        return params.noResults.content(
            params: ItemSelectorNoResultsParameters(
                title: title,
                subtitle: nil,
                hasNoSubstitutes: true,
                goBack: params.actions.onItemSelected)
        )
    }
}
