//
//  ItemSelectorParameters.swift
//  MiamIOSFramework
//
//  Created by Miam on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import SwiftUI

/**
 A protocol defining the necessary parameters for the Item Selector Page.
 
 - selectedProduct:  An implementation of ``ItemSelectorSelectedProductProtocol``
 - productOptions:  An implementation of ``ItemSelectorOptionProductsProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onItemSelected: () -> Void: A closure to call once item has been selected (it should a naviagtion function)
 
 */
@available(iOS 14, *)
public protocol ItemSelectorParametersProtocol {
    associatedtype SearchBar: SearchProtocol
    associatedtype ProductTitle: BaseTitleProtocol
    associatedtype SelectedProduct: ItemSelectorSelectedProductProtocol
    associatedtype ProductOptions: ItemSelectorOptionProductsProtocol
    associatedtype NoResults: ItemSelectorNoResultsProtocol
    
    var searchBar: SearchBar { get }
    var title: ProductTitle { get }
    var selectedProduct: SelectedProduct { get }
    var productOptions: ProductOptions { get }
    var noResults: NoResults { get }
    
    var actions: ItemSelectorActions { get set }
}

public struct ItemSelectorActions {
    var onItemSelected: () -> Void
    var onSeeProductDetails: (String) -> Void
    
    public init(onItemSelected: @escaping () -> Void, onSeeProductDetails: @escaping (String) -> Void) {
        self.onItemSelected = onItemSelected
        self.onSeeProductDetails = onSeeProductDetails
    }
}
