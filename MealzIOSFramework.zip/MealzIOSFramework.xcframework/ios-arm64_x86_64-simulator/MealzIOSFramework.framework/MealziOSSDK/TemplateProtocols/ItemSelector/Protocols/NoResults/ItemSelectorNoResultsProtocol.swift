//
//  ItemSelectorNoResultsProtocol.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI

/**
 A protocol defining the Product Options on the Item Selector Page.
 
 - products: [Item] -> the replacement proucts from different brands
 - onItemSelected: @escaping (Item) -> Void -> A closure that will select this product & navigate back to the Basket
 
 */
@available(iOS 14, *)
public protocol ItemSelectorNoResultsProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: ItemSelectorNoResultsParameters) -> Content
}

public struct ItemSelectorNoResultsParameters {
    public let title: String
    public let subtitle: String?
    public let hasNoSubstitutes: Bool
    public let goBack: () -> Void
    
    public init(title: String, subtitle: String? = nil, hasNoSubstitutes: Bool, goBack: @escaping () -> Void) {
        self.title = title
        self.subtitle = subtitle
        self.hasNoSubstitutes = hasNoSubstitutes
        self.goBack = goBack
    }
}
