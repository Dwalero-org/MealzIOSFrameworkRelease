//
//  ItemsSelectorSelectedProduct.swift
//  MiamIOSFramework
//
//  Created by Miam on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the Selected Product, the product being replaced, on the Item Selector Page.
 
 - product: PricedItem -> the product being replaced

 */
@available(iOS 14, *)
public protocol ItemSelectorSelectedProductProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: ItemSelectorSelectedProductParameters) -> Content
}

public struct ItemSelectorSelectedProductParameters {
    public let product: Item
    public let onSeeItemDetails: (String) -> Void
    
    public init(product: Item, onSeeItemDetails: @escaping (String) -> Void) {
        self.product = product
        self.onSeeItemDetails = onSeeItemDetails
    }
}
