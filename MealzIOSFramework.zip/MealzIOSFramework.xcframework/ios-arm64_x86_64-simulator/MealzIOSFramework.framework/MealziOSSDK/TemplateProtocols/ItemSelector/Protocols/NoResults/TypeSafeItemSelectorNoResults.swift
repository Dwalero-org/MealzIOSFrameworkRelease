//
//  TypeSafeItemSelectorNoResults.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeItemSelectorNoResults: ItemSelectorNoResultsProtocol {
    private let _content: (ItemSelectorNoResultsParameters) -> AnyView

       public init<T: ItemSelectorNoResultsProtocol>(_ wrapped: T) where T.Content: View {
           self._content = {  params  in
               AnyView(wrapped.content(params: params))
           }
       }

       public func content(params: ItemSelectorNoResultsParameters) -> some View {
           _content(params)
       }
}
