//
//  ItemSelectorProductOptions.swift
//  MiamIOSFramework
//
//  Created by Miam on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the Product Options on the Item Selector Page.
 
 - products: [Item] -> the replacement proucts from different brands
 - onItemSelected: @escaping (Item) -> Void -> A closure that will select this product & navigate back to the Basket
 
 */
@available(iOS 14, *)
public protocol ItemSelectorOptionProductsProtocol {
    associatedtype Content: View

    @ViewBuilder func content(params: ItemSelectorOptionProductsParameters) -> Content
}

public struct ItemSelectorOptionProductsParameters {
    public let products: [Item]
    public let onItemSelected: (Item) -> Void
    public let onSeeItemDetails: (String) -> Void
    
    public init(products: [Item], onItemSelected: @escaping (Item) -> Void, onSeeItemDetails: @escaping (String) -> Void) {
        self.products = products
        self.onItemSelected = onItemSelected
        self.onSeeItemDetails = onSeeItemDetails
    }
}
