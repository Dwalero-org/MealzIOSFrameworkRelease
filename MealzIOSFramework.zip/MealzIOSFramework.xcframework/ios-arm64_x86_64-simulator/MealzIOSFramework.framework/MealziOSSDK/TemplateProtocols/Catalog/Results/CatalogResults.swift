//
//  CatalogResults.swift
//
//
//  Created by didi on 08/08/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Favorites page where users can see the recipes they have liked.
 
 Mandatory Parameters:
 - params:  An implementation of ``CatalogParametersProtocol``, usually the default ``CatalogParameters``
 - recipesListParams:  An implementation of ``RecipesListParametersProtocol``, usually the default ``RecipesListParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 
 Optional Parameters:
 - categoryId: String -> The CatalogVM can optionally take a category & title in on init to set the Catalog to show these recipes
 - title: String -> The CatalogVM can optionally take a category & title in on init to set the Catalog to show these recipes
 - usesPreferences: Bool = false -> The CatalogVM can optionally use Preferences, where the user can filter based on dietary options like Vegetarian, equipment at home, etc
 - mealsInBasketButtonAlignment: Alignment = .bottom -> where the MealInBasketButton will go on the view
 
 */
@available(iOS 14, *)
public struct CatalogResults<
    CatalogParameters: CatalogParametersProtocol,
    RecipesListParameters: CatalogRecipesListParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: CatalogParameters
    private let recipesListParams: RecipesListParameters
    private let baseViews: BaseViews
    public let gridConfig: CatalogRecipesListGridConfig
    private let usesPreferences: Bool
    private let showMealsInBasketButton: Bool
    private let mealsInBasketButtonAlignment: Alignment
    private let isFavorite: Bool
    
    @ObservedObject public var catalogViewModel: CatalogVM
    private var filterInstance = FilterInstance(filterType: .catalog)
    
    public init(
        params: CatalogParameters,
        recipesListParams: RecipesListParameters,
        baseViews: BaseViews,
        categoryId: String? = nil,
        title: String? = nil,
        usesPreferences: Bool = false,
        mealsInBasketButtonAlignment: Alignment = .bottom,
        showMealsInBasketButton: Bool = false,
        gridConfig: CatalogRecipesListGridConfig,
        isFavorite: Bool
    ) {
        if let categoryId = categoryId, let title = title {
            self.catalogViewModel = CatalogVM(categoryID: categoryId, title: title)
        } else {
            self.catalogViewModel = CatalogVM()
        }
        self.params = params
        self.recipesListParams = recipesListParams
        self.baseViews = baseViews
        self.usesPreferences = usesPreferences
        self.showMealsInBasketButton = showMealsInBasketButton
        self.mealsInBasketButtonAlignment = mealsInBasketButtonAlignment
        self.gridConfig = gridConfig
        self.isFavorite = isFavorite
    }
    
    private func determineCurrentContent() -> CatalogContent {
        let state = filterInstance.viewModel.currentState
        if state.isFavorite {
            return .favorite
        } else if catalogViewModel.currentState.content == .category {
            return .category
        } else if let searchString = state.searchString, !searchString.isEmpty {
            return .wordSearch
        } else {  return .categoriesList }
    }
    
    var titleText: String {
        let currentContent = determineCurrentContent()  // Determine the current content first

        switch currentContent {
        case .favorite:
            return Localization.catalog.favoriteTitle.localised
        case .category:
            return catalogViewModel.currentState.openedCategoryTitle
        case .wordSearch:
            if let searchString = filterInstance.viewModel.currentState.searchString, !searchString.isEmpty {
                return "\(Localization.catalog.searchPrefix.localised) \"\(searchString)\""
            } else { return Localization.catalog.searchTitle.localised } // return default
        case .categoriesList:
            return Localization.catalog.searchTitle.localised
        default:
            return Localization.catalog.searchTitle.localised
        }
    }
    
    public var body: some View {
        

        return ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack(alignment: .center, spacing: 0.0) {
                let catalogParams = CatalogToolbarParameters(
                    numberOfActiveFilters: Int(filterInstance.viewModel.getActiveFilterCount()),
                    usesPreferences: usesPreferences,
                    isFavorite: self.isFavorite,
                    onFiltersTapped: {
                        params.actions.onFiltersTapped(filterInstance)
                    },
                    onSearchTapped: { params.actions.onSearchTapped(filterInstance) },
                    onFavoritesTapped: params.actions.onFavoritesTapped,
                    onPreferencesTapped: params.actions.onPreferencesTapped
                )
                params.resultsToolbar.content(params: catalogParams)
                UIStateWrapperView(uiState: catalogViewModel.state?.categories) {
                    baseViews.loading.content(params: BaseLoadingParameters())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } emptyView: {
                    baseViews.empty.content(params: BaseEmptyParameters())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } successView: {
                    ZStack {
                        CatalogRecipesList(
                            params: recipesListParams,
                            title: titleText,
                            categorySubtitle: catalogViewModel.currentState.subtitle ?? "",
                            gridConfig: gridConfig,
                            catalogContent: determineCurrentContent(),
                            filterInstance: filterInstance,
                            categoryId: // pass nil if categoryId == ""
                            catalogViewModel.currentState.openedCategoryId.isEmpty ? nil : catalogViewModel.currentState.openedCategoryId
                        )
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(.horizontal, gridConfig.spacing.width)
                        .padding(.vertical, gridConfig.spacing.height)
                        if showMealsInBasketButton {
                            MealsInBasketButton(
                                params: params.mealsInBasketButton,
                                onNavigateToMyMeals: params.actions.onMealsInBasketButtonTapped
                            )
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: mealsInBasketButtonAlignment)
                        }
                    }
                }
                Spacer()
            }
        }
        .onAppear(perform: catalogViewModel.registerListeners)
        .onDisappear {
            catalogViewModel.dispose()
        }
    }
}
