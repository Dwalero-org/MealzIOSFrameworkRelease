//
//  CatalogView.swift
//
//
//  Created by didi on 08/08/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Favorites page where users can see the recipes they have liked.
 
 Mandatory Parameters:
 - params:  An implementation of ``CatalogParametersProtocol``, usually the default ``CatalogParameters``
 - catalogPackageRowParams:  An implementation of ``CatalogPackageRowParametersProtocol``, usually the default ``CatalogPackageRowParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 
 Optional Parameters:
 - categoryId: String -> The CatalogVM can optionally take a category & title in on init to set the Catalog to show these recipes
 - title: String -> The CatalogVM can optionally take a category & title in on init to set the Catalog to show these recipes
 - usesPreferences: Bool = false -> The CatalogVM can optionally use Preferences, where the user can filter based on dietary options like Vegetarian, equipment at home, etc
 - mealsInBasketButtonAlignment: Alignment = .bottom -> where the MealInBasketButton will go on the view
 
 */
@available(iOS 14, *)
public struct CatalogView<
    CatalogParameters: CatalogParametersProtocol,
    CatalogPackageRowParameters: CatalogPackageRowParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: CatalogParameters
    private let catalogPackageRowParams: CatalogPackageRowParameters
    private let baseViews: BaseViews
    private let gridConfig: CatalogRecipesListGridConfig
    private let mealsInBasketButtonAlignment: Alignment
    private var usesPreferences: Bool
    
    @ObservedObject public var catalogViewModel: CatalogVM
    private var filterInstance = FilterInstance(filterType: .catalog)
    
    public init(
        params: CatalogParameters,
        catalogPackageRowParams: CatalogPackageRowParameters,
        baseViews: BaseViews,
        categoryId: String? = nil,
        title: String? = nil,
        usesPreferences: Bool = false,
        mealsInBasketButtonAlignment: Alignment = .bottom,
        gridConfig: CatalogRecipesListGridConfig
    ) {
        if let categoryId = categoryId, let title = title {
            self.catalogViewModel = CatalogVM(categoryID: categoryId, title: title)
        } else {
            self.catalogViewModel = CatalogVM()
        }
        self.params = params
        self.catalogPackageRowParams = catalogPackageRowParams
        self.baseViews = baseViews
        self.usesPreferences = usesPreferences
        self.gridConfig = gridConfig
        self.mealsInBasketButtonAlignment = mealsInBasketButtonAlignment
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack(alignment: .center, spacing: 0.0) {
                let catalogParams = CatalogToolbarParameters(
                    numberOfActiveFilters: Int(filterInstance.viewModel.getActiveFilterCount()),
                    usesPreferences: usesPreferences,
                    onFiltersTapped: {
                        params.actions.onFiltersTapped(filterInstance)
                    },
                    onSearchTapped: { params.actions.onSearchTapped(filterInstance) },
                    onFavoritesTapped: {
                        catalogViewModel.setEvent(event: CatalogContractEvent.GoToFavorite())
                        params.actions.onFavoritesTapped()
                    },
                    onPreferencesTapped: params.actions.onPreferencesTapped
                )
                params.catalogToolbar.content(params: catalogParams)
                UIStateWrapperView(uiState: catalogViewModel.state?.categories) {
                    baseViews.loading.content(params: BaseLoadingParameters())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } emptyView: {
                    baseViews.empty.content(params: BaseEmptyParameters())
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } successView: {
                    GeometryReader { geometry in
                        ZStack {
                            ScrollView {
                                showMealPlanner()
                                successContent()
                                    .padding(.bottom, 50)
                            }
                            VStack {
                                Spacer()
                                Color.mealzColor(.white)
                                    .frame(height: geometry.safeAreaInsets.bottom)
                            }.ignoresSafeArea()
                            MealsInBasketButton(
                                params: params.mealsInBasketButton,
                                onNavigateToMyMeals: params.actions.onMealsInBasketButtonTapped
                            )
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: mealsInBasketButtonAlignment)
                        }
                        .onDisappear { // moved to inside Success so that if you navigate to results early, packages are still saved
                            catalogViewModel.dispose()
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onAppear {
            catalogViewModel.registerListeners()
            catalogViewModel.goToCategoriesList()
            filterInstance.clearFilters()
        }
        
    }
    
    func showMealPlanner() -> some View {
        return VStack {
            if let launchMealPlanner = params.actions.onLaunchMealPlanner {
                params.mealPlannerCTA.content(params: MealPlannerCTAViewParameters() {
                    launchMealPlanner()
                })
                .padding(Dimension.sharedInstance.mPadding)
            } else {
                Spacer().frame(width: 0, height: 0)
            }
        }
    }
    
    func successContent() -> some View {
        LazyVStack {
            ForEach(catalogViewModel.packages) { package in
                CatalogPackageRow.init(
                    params: catalogPackageRowParams,
                    gridConfig: gridConfig,
                    package: package) {
                        catalogViewModel.goToCategory(
                            categoryId: package.package.id,
                            categoryTitle: package.package.attributes?.title ?? "",
                            subtitle: package.package.subtitle)
                    }
                    .id(package.id)
                    .padding(.horizontal, gridConfig.spacing.width)
                    .padding(.vertical, gridConfig.spacing.height)
            }
        }
        .padding(.vertical, Dimension.sharedInstance.mPadding)
    }
}
