//
//  CatalogParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import Foundation
import mealzcore

/**
 A protocol defining the necessary parameters for the Catalog Page.
 
 - catalogToolbar:  An implementation of ``CatalogToolbarProtocol``. This will be shown on the main CatalogPage. With default Miam implementation, it will contain the Favorites button
 - resultsToolbar:  An implementation of ``CatalogToolbarProtocol``. This will be shown on the Results Page (after pressing favorites, filtering, or seaching).
 /// With default Miam implementation, it will NOT contain the Favorites button
 - mealPlannerCTA:  An implementation of ``MealPlannerCTAProtocol``. This will be shown on the main CatalogPage if launchMealPlanner function has content.
 - mealsInBasketButton:  An implementation of ``MealsInBasketButtonParametersProtocol``. Parameters for MyMealsButton. 
 The passed in parameters should also define where in the view the button is.
 For example, if you want the button at the bottom, it should have a .frame(alignment: .bottom)
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onFiltersTapped: (FilterInstance) -> Void: A closure that navigates to the FiltersPage when the user taps on Filter Button.
 - onSearchTapped: (FilterInstance) -> Void: A closure that navigates to the SearchPage when the user taps on Search Button.
 - onFavoritesTapped: () -> Void: A closure that navigates to the CatalogResultsPage when the user taps on Favorites Button.
 - onPreferencesTapped: () -> Void: A closure that navigates to the PreferencesPage when the user taps on Preferences Button.
 - onLaunchMealPlanner: (() -> Void)?: An optional closure that navigates to the MealPlanner when the user taps on MealPlanner Button.
 - onMealsInBasketButtonTapped: () -> Void: A closure that navigates to the MyMeals Page when the user taps on MyMeals Button.
 */
@available(iOS 14, *)
public protocol CatalogParametersProtocol {

    associatedtype CatalogToolbar: CatalogToolbarProtocol
    associatedtype ResultsToolbar: CatalogToolbarProtocol
    associatedtype MealPlannerCTA: MealPlannerCTAProtocol
    associatedtype MealsInBasketButton: MealsInBasketButtonParametersProtocol
    
    var catalogToolbar: CatalogToolbar { get }
    var resultsToolbar: ResultsToolbar { get }
    var mealPlannerCTA: MealPlannerCTA { get }
    var mealsInBasketButton: MealsInBasketButton { get }
    
    var actions: CatalogActions { get set }
}


public struct CatalogActions {
    var onFiltersTapped: (FilterInstance) -> Void
    var onSearchTapped: (FilterInstance) -> Void
    var onFavoritesTapped: () -> Void
    var onPreferencesTapped: () -> Void
    var onLaunchMealPlanner: (() -> Void)?
    var onMealsInBasketButtonTapped: () -> Void
    
    public init(
        onFiltersTapped: @escaping (FilterInstance) -> Void,
        onSearchTapped: @escaping (FilterInstance) -> Void,
        onFavoritesTapped: @escaping () -> Void,
        onPreferencesTapped: @escaping () -> Void,
        onLaunchMealPlanner: (() -> Void)? = nil,
        onMealsInBasketButtonTapped: @escaping () -> Void
    ) {
        self.onFiltersTapped = onFiltersTapped
        self.onSearchTapped = onSearchTapped
        self.onFavoritesTapped = onFavoritesTapped
        self.onPreferencesTapped = onPreferencesTapped
        self.onLaunchMealPlanner = onLaunchMealPlanner
        self.onMealsInBasketButtonTapped = onMealsInBasketButtonTapped
    }
}

