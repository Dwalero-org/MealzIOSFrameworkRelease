//
//  CatalogToolbarProtocol.swift
//
//
//  Created by didi on 08/08/2023.
//
import SwiftUI
import mealzcore

/**
 A protocol defining the call to action on the Filters Page. This has two buttons, one to clear & another to apply
 
 - usesPreferences: Bool -> The CatalogVM can optionally use Preferences, where the user can filter based on dietary options like Vegetarian, equipment at home, etc
 - onFiltersTapped: () -> Void -> A closure to navigate to the Filters View
 - onSearchTapped: () -> Void -> A closure to navigate to the Catalog Search View
 - onFavoritesTapped: () -> Void -> A closure to navigate to the Favorites View
 - onPreferencesTapped: () -> Void -> A closure to navigate to the Preferences View
 */
@available(iOS 14, *)
public protocol CatalogToolbarProtocol {
    associatedtype Content: View
    func content(
        params: CatalogToolbarParameters
    ) -> Content
}

public struct CatalogToolbarParameters {
    public let numberOfActiveFilters: Int
       public let usesPreferences: Bool
       public let isFavorite: Bool
       public let onFiltersTapped: () -> Void
       public let onSearchTapped: () -> Void
       public let onFavoritesTapped: () -> Void
       public let onPreferencesTapped: () -> Void
    
    public init(
        numberOfActiveFilters: Int,
        usesPreferences: Bool,
        isFavorite: Bool = false,
        onFiltersTapped: @escaping () -> Void,
        onSearchTapped: @escaping () -> Void,
        onFavoritesTapped: @escaping () -> Void,
        onPreferencesTapped: @escaping () -> Void
    ) {
        self.numberOfActiveFilters = numberOfActiveFilters
        self.usesPreferences = usesPreferences
        self.isFavorite = isFavorite
        self.onFiltersTapped = onFiltersTapped
        self.onSearchTapped = onSearchTapped
        self.onFavoritesTapped = onFavoritesTapped
        self.onPreferencesTapped = onPreferencesTapped
    }
}
