//
//  CatalogSearchParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for Catalog Search.
 
 - search:  An implementation of ``SearchProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``

 - onApplied: () -> Void: A closure that updates the Filters Singleton witht he current search & closes the page, this should navigate to the Catalog Results Page
 
 */
@available(iOS 14, *)
public protocol CatalogSearchParametersProtocol {
    associatedtype Search: SearchProtocol
    // eventually will need recommendations

    var search: Search { get }
    
    var actions: CatalogSearchActions { get set }
}

public struct CatalogSearchActions {
    var onApplied: () -> Void
    
    public init(onApplied: @escaping () -> Void) {
        self.onApplied = onApplied
    }
}
