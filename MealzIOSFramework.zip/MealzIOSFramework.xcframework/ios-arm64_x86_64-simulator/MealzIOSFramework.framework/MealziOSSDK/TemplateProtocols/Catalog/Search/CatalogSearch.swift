//
//  CatalogSearch.swift
//
//
//  Created by didi on 07/08/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the CatalogSearch page where users can search for Recipes
 
 Mandatory Parameters:
 - params:  An implementation of ``CatalogSearchParametersProtocol``, usually the default ``CatalogSearchParameters``
 - filterInstance:  A ``FilterInstance``. This will usually be passed in by the button that launches it. Can be Catalog or also MealPlannerCatalog
 
 */
@available(iOS 14, *)
public struct CatalogSearch<
    CatalogSearchParameters: CatalogSearchParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: CatalogSearchParameters
    private let baseViews: BaseViews
    @ObservedObject var filtersViewModel: FiltersVM
    @SwiftUI.State var searchString: String = ""
    
    public init(
        params: CatalogSearchParameters,
        baseViews: BaseViews,
        filterInstance: FilterInstance
    ) {
        self.params = params
        self.baseViews = baseViews
        self.filtersViewModel = FiltersVM(filterInstance: filterInstance)
    }
    
    private func onApplySearch() {
        self.filtersViewModel.applyFilter()
        params.actions.onApplied()
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.search.content(
                    params: SearchParameters(
                        searchText: $searchString,
                        onApply: onApplySearch
                    ))
                .onChange(of: searchString) { str in
                    filtersViewModel.search(searchString: str)
                }
                Spacer()
            }.padding(Dimension.sharedInstance.lPadding)
        }
    }
}
