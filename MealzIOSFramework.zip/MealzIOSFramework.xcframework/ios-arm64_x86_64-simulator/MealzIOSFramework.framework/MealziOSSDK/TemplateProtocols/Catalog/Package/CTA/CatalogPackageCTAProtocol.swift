//
//  CatalogPackageCTAProtocol.swift
//
//
//  Created by didi on 10/08/2023.
//
import SwiftUI

/**
 A protocol defining the call to action on the CatalogPackage Rows.
 
 - onSeeAllRecipes: () -> Void -> A closure that navigates with the Catalog Results Page
 - title: String -> Main text
 - subtitle: String? ->  Subtext
 */
@available(iOS 14, *)
public protocol CatalogPackageCTAProtocol {
    associatedtype Content: View
    func content(
        params: CatalogPackageCTAParameters
    ) -> Content
}

public struct CatalogPackageCTAParameters {
    public let title: String
    public let subtitle: String?
    public let onSeeAllRecipes: () -> Void
    
    public init(title: String, subtitle: String? = nil, onSeeAllRecipes: @escaping () -> Void) {
        self.title = title
        self.subtitle = subtitle
        self.onSeeAllRecipes = onSeeAllRecipes
    }
}

