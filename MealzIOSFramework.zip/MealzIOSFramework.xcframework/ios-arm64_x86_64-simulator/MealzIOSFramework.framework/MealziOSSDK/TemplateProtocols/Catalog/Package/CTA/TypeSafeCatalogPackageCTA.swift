//
//  TypeSafeCatalogPackageCTA.swift
//  
//
//  Created by didi on 09/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeCatalogPackageCTA: CatalogPackageCTAProtocol {
    private let _content: (
        CatalogPackageCTAParameters
    ) -> AnyView

    public init<T: CatalogPackageCTAProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(
        params: CatalogPackageCTAParameters
    ) -> some View {
        _content(params)
    }
}
