//
//  CatalogPackageRow.swift
//
//
//  Created by didi on 10/08/2023.
//

import SwiftUI
import mealzcore

/**
 A CatalogPackageRow t
 
 Mandatory Parameters:
 - params:  An implementation of ``CatalogPackageRowParametersProtocol``, usually the default ``CatalogPackageRowParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 - package: CatalogPackage ->  The collection of Recipes that the PackageRow is showing
 - setCurrentPackage: () -> Void: A closure to set the current package
 
 */
@available(iOS 14, *)
public struct CatalogPackageRow<
    CatalogPackageRowParameters: CatalogPackageRowParametersProtocol
>: View {
    public let params: CatalogPackageRowParameters
    public let gridConfig: CatalogRecipesListGridConfig
    public let package: CatalogPackage
    public let setCurrentPackage: () -> Void
    
    public init(
        params: CatalogPackageRowParameters,
        gridConfig: CatalogRecipesListGridConfig,
        package: CatalogPackage,
        setCurrentPackage: @escaping () -> Void
    ) {
        self.params = params
        self.gridConfig = gridConfig
        self.package = package
        self.setCurrentPackage = setCurrentPackage
    }
    
    public var body: some View {
        VStack {
            params.callToAction.content(
                params: CatalogPackageCTAParameters(
                    title: package.title,
                    subtitle: package.subtitle ?? "") {
                        setCurrentPackage()
                        params.actions.onSeeAllRecipes(package.id, package.title)
                    }
            )
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack {
                    ForEach(package.recipes, id: \.self) { recipe in
                        CatalogRecipeCard(
                            recipe.id,
                            recipeCardDimensions: gridConfig.recipeCardDimensions,
                            cardTemplate: params.recipeCard,
                            loadingTemplate: params.recipeCardLoading,
                            onShowRecipeDetails: params.actions.onShowRecipeDetails,
                            onCallToAction: params.actions.onRecipeCallToActionTapped)
                        .id(recipe.id)
                    }
                }
            }
        }
    }
}
