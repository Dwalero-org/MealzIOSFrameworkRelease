//
//  CatalogPackageRowParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Catalog Package Rows, or Catagories.
 
 - callToAction:  An implementation of ``CatalogPackageCTAProtocol``. This will invite the user to see all the recipes in this collection
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``. Each Recipe will appear like this
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``. Compoenent when the recipe cards are loading
 
 - onSeeAllRecipes: (String, String) -> Void: A closure to see all the recipes of the collection in the next page. 
 The first String is the catagoryId & the second is the catagoryTitle, both of which will be passed into the CatalogResultsPage
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onRecipeCallToActionTapped: (String) -> Void: A closure that executes the callback in the recipeCard CTA. 
 This is often a navigation to the Basket, but it can also be used on MealPlanner to navigate back to the MealPlanner Results
 
 */
@available(iOS 14, *)
public protocol CatalogPackageRowParametersProtocol {
    associatedtype CallToAction: CatalogPackageCTAProtocol
    associatedtype RecipeCardContent: CatalogRecipeCardProtocol
    associatedtype RecipeLoading: RecipeCardLoadingProtocol

    var callToAction: CallToAction { get }
    var recipeCard: RecipeCardContent { get }
    var recipeCardLoading: RecipeLoading { get }

    var actions: CatalogPackageRowActions { get set }
}

public struct CatalogPackageRowActions {
    var onSeeAllRecipes: (String, String) -> Void
    var onShowRecipeDetails: (String) -> Void
    var onRecipeCallToActionTapped: (String) -> Void
    
    public init(
        onSeeAllRecipes: @escaping (String, String) -> Void,
        onShowRecipeDetails: @escaping (String) -> Void,
        onRecipeCallToActionTapped: @escaping (String) -> Void
    ) {
        self.onSeeAllRecipes = onSeeAllRecipes
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onRecipeCallToActionTapped = onRecipeCallToActionTapped
    }
}
