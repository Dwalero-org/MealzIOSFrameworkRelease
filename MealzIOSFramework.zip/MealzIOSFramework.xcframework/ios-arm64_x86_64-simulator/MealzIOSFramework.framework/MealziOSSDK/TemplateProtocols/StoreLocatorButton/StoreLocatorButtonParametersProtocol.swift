//
//  StoreLocatorButtonParametersProtocol.swift
//  MealzIOSFramework
//
//  Created by miam x didi on 29/04/2024.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the MyProducts Page.
 - productCard:  An implementation of ``MyProductsProductCardProtocol``
 - actions: MyProductsActions
 */
@available(iOS 14, *)
public protocol StoreLocatorButtonParametersProtocol {
    associatedtype CallToAction: BaseButtonProtocol
    var callToAction: CallToAction { get }
    var actions: StoreLocatorButtonActions { get set }
}

public struct StoreLocatorButtonActions {
    var changeStore: () -> Void
    
    public init(
        changeStore: @escaping () -> Void
    ) {
        self.changeStore = changeStore
    }
}
