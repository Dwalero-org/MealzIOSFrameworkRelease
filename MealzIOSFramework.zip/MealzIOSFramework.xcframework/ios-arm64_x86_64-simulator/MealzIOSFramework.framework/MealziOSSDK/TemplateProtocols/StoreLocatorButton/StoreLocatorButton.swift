//
//  StoreLocatorButton.swift
//  MealzIOSFramework
//
//  Created by miam x didi on 29/04/2024.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct StoreLocatorButton<StoreLocatorParameters: StoreLocatorButtonParametersProtocol>: View {
    private let params: StoreLocatorParameters
    @ObservedObject private var viewModel: StoreLocatorButtonVM = StoreLocatorButtonVM()
    
    public init(params: StoreLocatorParameters) {
        self.params = params
    }
    public var body: some View {
        let storeName = viewModel.currentPOSName ?? Localization.storeLocatorButton.defaultText.localised
        return params.callToAction.content(params: BaseButtonParameters(
            buttonText: storeName,
            buttonPressed: false,
            onButtonAction: params.actions.changeStore))
        .onAppear { viewModel.registerListeners() }
        .onDisappear { viewModel.dispose() }
    }
}
