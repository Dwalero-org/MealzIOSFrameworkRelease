//
//  Favorites.swift
//
//
//  Created by didi on 08/08/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Favorites page where users can see the recipes they have liked.
 
 Mandatory Parameters:
 - params:  An implementation of ``FavoritesParametersProtocol``, usually the default ``FavoritesParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as number of columns & spacing.
 
 */
@available(iOS 14, *)
public struct Favorites<
    FavoritesParameters: FavoritesParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: FavoritesParameters
    private let baseViews: BaseViews
    public let gridConfig: CatalogRecipesListGridConfig
    @ObservedObject var favoritesViewModel = FavoritesVM()
    
    public init(
        params: FavoritesParameters,
        baseViews: BaseViews,
        gridConfig: CatalogRecipesListGridConfig
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: favoritesViewModel.state?.favoritesRecipes) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                baseViews.empty.content(params: BaseEmptyParameters(onOptionalCallback: params.actions.onNoResultsRedirect))
            } successView: { successContent() }
            .onAppear(perform: { favoritesViewModel.registerListeners()})
            .onDisappear(perform: { favoritesViewModel.dispose()})
        }
    }
    
    func successContent() -> some View {
        ScrollView {
            params.title.content(params: TitleParameters(title: Localization.favorites.title.localised, subtitle: Localization.favorites.goToCatalog.localised))
            LazyVGrid(
                columns: Array(
                    repeating: GridItem(.flexible()),
                    count: gridConfig.numberOfColumns),
                spacing: 0
            ) {
                ForEach(favoritesViewModel.favorites, id: \.self) { recipe in
                    CatalogRecipeCard(
                        recipe.id,
                        recipeCardDimensions: gridConfig.recipeCardDimensions,
                        cardTemplate: params.recipeCard,
                        loadingTemplate: params.recipeCardLoading,
                        onShowRecipeDetails: params.actions.onShowRecipeDetails,
                        onCallToAction: params.actions.onRecipeCallToActionTapped)
                    .padding(.vertical, gridConfig.spacing.height)
                    .padding(.horizontal, gridConfig.spacing.width)
                }
            }
        }
    }
}
