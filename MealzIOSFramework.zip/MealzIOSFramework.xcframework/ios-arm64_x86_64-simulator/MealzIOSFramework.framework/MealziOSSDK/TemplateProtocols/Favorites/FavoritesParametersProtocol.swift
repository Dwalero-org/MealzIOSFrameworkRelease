//
//  FavoritesParametersProtocol.swift
//  
//
//  Created by didi on 11/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the Favorites Page.
 - title:  An implementation of ``BaseTitleProtocol``
 - recipeCard:  An implementation of ``CatalogRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 - onNoResultsRedirect: () -> Void: A closure that navigates the user to a different page when the user doesn't have any favorite options. This should usually navigate to the CatalogView
 - onRecipeCallToActionTapped: (String) -> Void: A closure that executes the function in the "Call To Action" of the recipe card. This is usally "add to basket", so the navigation is to the Basket
 
 */
@available(iOS 14, *)
public protocol FavoritesParametersProtocol {
    associatedtype Title: BaseTitleProtocol
    associatedtype RecipeCardContent: CatalogRecipeCardProtocol
    associatedtype RecipeLoading: RecipeCardLoadingProtocol
    
    var title: Title { get }
    var recipeCard: RecipeCardContent { get }
    var recipeCardLoading: RecipeLoading { get }
    
    var actions: FavoritesActions { get set }
}

public struct FavoritesActions {
    var onShowRecipeDetails: (String) -> Void
    var onNoResultsRedirect: () -> Void
    var onRecipeCallToActionTapped: (String) -> Void
    
    public init(
        onShowRecipeDetails: @escaping (String) -> Void,
        onNoResultsRedirect: @escaping () -> Void,
        onRecipeCallToActionTapped: @escaping (String) -> Void
    ) {
        self.onNoResultsRedirect = onNoResultsRedirect
        self.onShowRecipeDetails = onShowRecipeDetails
        self.onRecipeCallToActionTapped = onRecipeCallToActionTapped
    }
}
