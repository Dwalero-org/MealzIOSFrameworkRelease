//
//  TypeSafeRecipeDetailsIgnoredProducts.swift
//  
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsIgnoredProduct: RecipeDetailsIgnoredProductProtocol {
    private let _content: (RecipeDetailsIgnoredProductParameters) -> AnyView

    public init<T: RecipeDetailsIgnoredProductProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeDetailsIgnoredProductParameters) -> some View {
        _content(params)
    }
}
