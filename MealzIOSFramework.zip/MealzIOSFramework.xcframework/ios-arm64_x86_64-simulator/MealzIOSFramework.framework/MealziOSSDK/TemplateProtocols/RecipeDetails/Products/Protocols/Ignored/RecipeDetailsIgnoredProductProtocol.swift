//
//  RecipeDetailsIgnoredProductProtocol.swift
//  
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for Recipe Details Ingredients Section
 
 - infos: an instance of ``RecipeDetailsProductsParameters``
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsIgnoredProductProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsIgnoredProductParameters) -> Content
}

@available(iOS 13, *)
public struct RecipeDetailsIgnoredProductParameters {
    public let ingredientName: String
    public let ingredientQuantity: String?
    public let ingredientUnit: String?
    public let guestsCount: Int
    public let defaultRecipeGuest: Int
    public let onChooseProduct: () -> Void
 
    public init(
        ingredientName: String,
        ingredientQuantity: String? = nil,
        ingredientUnit: String? = nil,
        guestsCount: Int,
        defaultRecipeGuest: Int,
        onChooseProduct: @escaping () -> Void
    ) {
        self.ingredientName = ingredientName
        self.ingredientQuantity = ingredientQuantity
        self.ingredientUnit = ingredientUnit
        self.guestsCount = guestsCount
        self.defaultRecipeGuest = defaultRecipeGuest
        self.onChooseProduct = onChooseProduct
    }
}
