//
//  RecipeDetailsUnaddedProductProtocol.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for Recipe Details Ingredients Section
 
 - infos: an instance of ``RecipeDetailsProductsParameters``
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsUnaddedProductProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsUnaddedProductParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsUnaddedProductParameters {
    public let data: RecipeProductData
    public let productStatus: ComponentUiState
    public let onAddProduct: () -> Void
    public let onIgnoreProduct: () -> Void
    public let onChooseProduct: () -> Void
 
    public init(
        data: RecipeProductData,
        productStatus: ComponentUiState,
        onAddProduct: @escaping () -> Void,
        onIgnoreProduct: @escaping () -> Void,
        onChooseProduct: @escaping () -> Void
    ) {
        self.data = data
        self.productStatus = productStatus
        self.onAddProduct = onAddProduct
        self.onIgnoreProduct = onIgnoreProduct
        self.onChooseProduct = onChooseProduct
    }
}

