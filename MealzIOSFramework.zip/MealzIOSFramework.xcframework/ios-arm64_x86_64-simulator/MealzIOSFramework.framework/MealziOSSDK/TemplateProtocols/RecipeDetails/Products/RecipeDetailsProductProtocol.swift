//
//  RecipeDetailsProductProtocol.swift
//
//
//  Created by Diarmuid McGonagle on 11/01/2024.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the Recipe Details Page.
 
 - header:  An implementation of ``RecipeDetailsHeaderProtocol``. The content of the header in the recipe details.
 - sponsor:  An implementation of ``RecipeDetailsSponsorProtocol``. The content of the sponsor button in the recipe details.
 - ingredients:  An implementation of ``RecipeDetailsIngredientsProtocol``. The content of the ingredients list in the recipe details.
 - steps:  An implementation of ``RecipeDetailsStepsProtocol``. The content of the steps in the recipe details.
 - footer:  An implementation of ``RecipeDetailsFooterProtocol``. TThe content of the footer in the recipe details.
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onClosed: () -> Void: A closure that is called when the close button is pressed.
 - onSponsorDetailsTapped: (Sponsor) -> Void: A closure that is called when the sponsor details button is pressed.
 - onContinueToBasket: (() -> Void)?: An optional closure that is called when the continue to basket button is pressed.
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsProductProtocol {
    associatedtype IgnoredProduct: RecipeDetailsIgnoredProductProtocol
    associatedtype UnaddedProduct: RecipeDetailsUnaddedProductProtocol
    associatedtype AddedProduct: RecipeDetailsAddedProductProtocol
    associatedtype LoadingProduct: LoadingProtocol

    var ignoredProduct: IgnoredProduct { get }
    var unaddedProduct: UnaddedProduct { get }
    var addedProduct: AddedProduct { get }
    var loadingProduct: LoadingProduct { get }
}

