//
//  TypeSafeRecipeDetailsAddedProducts.swift
//
//
//  Created by Damien Walerowicz on 03/01/2024.
//
import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsAddedProduct: RecipeDetailsAddedProductProtocol {
    private let _content: (RecipeDetailsAddedProductParameters) -> AnyView

    public init<T: RecipeDetailsAddedProductProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeDetailsAddedProductParameters) -> some View {
        _content(params)
    }
}
