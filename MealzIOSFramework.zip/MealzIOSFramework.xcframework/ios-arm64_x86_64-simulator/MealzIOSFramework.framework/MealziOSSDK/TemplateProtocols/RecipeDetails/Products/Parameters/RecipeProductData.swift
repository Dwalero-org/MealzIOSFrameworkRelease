//
//  RecipeProductData.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import SwiftUI

/**
 An object containing all the items the Basket Product card needs.
 
 - price: Double -> The price of the product
 - name: String ->  Name of the product
 - description: String -> Description of the product
 - pictureURL: URL ->  Checked imageURL  of the product
 - sharedRecipeCount: Int ->  How many other recipes share this product
 - pricePerUnit: Double -> Usually Price per KG
 - isLoading: Bool -> If the product is currently set to loading from the core

 */
@available(iOS 14, *)
public struct RecipeProductData {
    public let unitPrice: Double
    public let name: String
    public let brand: String?
    public let capacity: String
    public let productQuantity: Int
    public let productUnit: String
    public let formattedProductPrice: String
    public let pictureURL: String
    public let ingredientName: String
    public let ingredientQuantity: Float
    public let ingredientUnit: String?
    public let numberOfOtherRecipesSharingThisIngredient: Int
    public let guestsCount: Binding<Int>
    public let defaultRecipeGuest: Int
    public let isSponsored: Bool
    public let ean: String

    public init(
        unitPrice: Double,
        formattedProductPrice: String,
        name: String,
        capacity: String,
        pictureURL: String,
        brand: String?,
        productQuantity: Int,
        productUnit: String,
        ingredientName: String,
        ingredientQuantity: Float,
        ingredientUnit: String?,
        numberOfOtherRecipesSharingThisIngredient: Int,
        guestsCount: Binding<Int>,
        defaultRecipeGuest: Int,
        isSponsored: Bool,
        ean: String
    ) {
        self.unitPrice = unitPrice
        self.formattedProductPrice = formattedProductPrice
        self.name = name
        self.capacity = capacity
        self.pictureURL = pictureURL
        self.brand = brand
        self.productQuantity = productQuantity
        self.productUnit = productUnit
        self.ingredientName = ingredientName
        self.ingredientQuantity = ingredientQuantity
        self.ingredientUnit = ingredientUnit
        self.numberOfOtherRecipesSharingThisIngredient = numberOfOtherRecipesSharingThisIngredient
        self.guestsCount = guestsCount
        self.defaultRecipeGuest = defaultRecipeGuest
        self.isSponsored = isSponsored
        self.ean = ean
    }
}

//public struct FakeRecipeProductData {
//    public init() {}
//    public func generateSingleRandomData() -> RecipeProductData {
//        let randomTitles = ["Tibo's mustard", "Vincent's ketchup", "Tom's Russian Sauce", "Vianney's Cream", "Kevin's Wasabi", "Aglae's BBQ Sauce", "Camille A's Sun-dried tomato", "Didi's Potato"]
//        let randomIndex = Int.random(in: 0..<randomTitles.count)
//        let randomDouble = Double.random(in: 0..<40)
//        let roundedDouble = Double(round(100*randomDouble)/100)
//        return RecipeProductData(
//            price: randomDouble,
//            name: randomTitles[randomIndex],
//            description: "My description",
//            pictureURL: (URL(string: "https://picsum.photos/400/300") ?? URL(string: ""))!,
//            sharedRecipeCount: randomIndex,
//            unitPrice: roundedDouble
//        )
//    }
//    public func createListOfRandomDatas() -> [RecipeProductData] {
//        var data = [RecipeProductData]()
//        for _ in 0..<5 {
//            data.append(generateSingleRandomData())
//        }
//        return data
//    }
//}
