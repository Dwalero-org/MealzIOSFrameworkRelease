//
//  RecipeDetailsAddedProductProtocol.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for Recipe Details Ingredients Section
 
 - infos: an instance of ``RecipeDetailsProductsParameters``
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsAddedProductProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsAddedProductParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsAddedProductParameters {
    public let data: RecipeProductData
    public let updatingQuantity: Bool
    @Binding public var productQuantityPressed: Bool
    public let onDeleteProduct: () -> Void
    public let onChangeProduct: () -> Void
    public let updateProductQuantity: (Int) -> Void
 
    public init(
        data: RecipeProductData,
        updatingQuantity: Bool,
        productQuantityPressed: Binding<Bool>,
        onDeleteProduct: @escaping () -> Void,
        onChangeProduct: @escaping () -> Void,
        updateProductQuantity: @escaping (Int) -> Void
    ) {
        self.data = data
        _productQuantityPressed = productQuantityPressed
        self.updatingQuantity = updatingQuantity
        self.onDeleteProduct = onDeleteProduct
        self.onChangeProduct = onChangeProduct
        self.updateProductQuantity = updateProductQuantity
    }
}
