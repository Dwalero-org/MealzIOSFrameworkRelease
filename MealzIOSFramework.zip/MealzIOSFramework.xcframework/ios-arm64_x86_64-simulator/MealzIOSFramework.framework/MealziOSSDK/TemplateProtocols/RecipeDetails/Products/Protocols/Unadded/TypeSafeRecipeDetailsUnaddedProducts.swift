//
//  TypeSafeRecipeDetailsUnaddedProducts.swift
//
//
//  Created by Damien Walerowicz on 03/01/2024.
//
import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsUnaddedProduct: RecipeDetailsUnaddedProductProtocol {
    private let _content: (RecipeDetailsUnaddedProductParameters) -> AnyView

    public init<T: RecipeDetailsUnaddedProductProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeDetailsUnaddedProductParameters) -> some View {
        _content(params)
    }
}
