//
//  RecipeDetailsProducts.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import Foundation
import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct RecipeDetailsProduct<
    ProductParameters: RecipeDetailsProductProtocol
>: View {
    let params: ProductParameters
    var guestCount: Binding<Int>
    let defaultRecipeGuest: Int
    @StateObject var productVM: BasketEntryInRecipeVM
    @SwiftUI.State var productQuantityPressed: Bool = false
    
    init(
        params: ProductParameters,
        BasketEntryInRecipeViewModel: BasketEntryInRecipeViewModel,
        guestCount: Binding<Int>,
        defaultRecipeGuest: Int
    ) {
        self.params = params
        self.guestCount = guestCount
        self.defaultRecipeGuest = defaultRecipeGuest
        _productVM = StateObject(wrappedValue: BasketEntryInRecipeVM(instance: BasketEntryInRecipeViewModel))
    }
    
    public var body: some View {
        VStack { // we do NOT use component UI State bc the image reloads everytime if so
            if productVM.instance.currentState.status == ComponentUiState.loading {
                params.loadingProduct.content(params: BaseLoadingParameters())
            } else { successContent(guestCount: guestCount) }
        }
            .onAppear { productVM.instance.registerListeners() }
            .onDisappear { productVM.instance.dispose() }
    }
    
    func successContent(guestCount: Binding<Int>) -> some View {
        VStack {
            if let entry = productVM.entry, let item = entry.selectedItem?.attributes {
                let capacity = (entry.selectedItem?.attributes?.capacityVolume ?? "") + " " + (entry.selectedItem?.attributes?.capacityUnit ?? "")
                let ingredient = productVM.ingredient
                let data = RecipeProductData(
                    unitPrice: entry.unitPrice,
                    formattedProductPrice: entry.unitPrice.currencyFormatted,
                    name: item.name,
                    capacity: capacity,
                    pictureURL: item.image ?? "",
                    brand: item.brand,
                    productQuantity: productVM.productQuantity,
                    productUnit: item.capacityUnit ?? "",
                    ingredientName: ingredient.name,
                    ingredientQuantity: QuantityFormatter.companion.realQuantities(
                        quantity: String(ingredient.attributes?.quantity ?? ""),
                        currentGuest: Int32(guestCount.wrappedValue),
                        recipeGuest: Int32(defaultRecipeGuest
                    )),
                    ingredientUnit: ingredient.attributes?.unit,
                    numberOfOtherRecipesSharingThisIngredient: entry.attributes?.recipeIds?.count ?? 0,
                    guestsCount: guestCount,
                    defaultRecipeGuest: defaultRecipeGuest,
                    isSponsored: productVM.instance.isSponsored(),
                    ean: item.ean
                )
                
                switch entry.status {
                    
                case "initial":
                    params.unaddedProduct.content(
                        params: RecipeDetailsUnaddedProductParameters(
                            data: data,
                            productStatus: productVM.state?.status ?? ComponentUiState.idle,
                            onAddProduct: productVM.addProduct,
                            onIgnoreProduct: productVM.ignoreProduct,
                            onChooseProduct: productVM.replaceProduct
                        )
                    )
                case "active":
                    params.addedProduct.content(
                        params: RecipeDetailsAddedProductParameters(
                            data: data, 
                            updatingQuantity: productVM.instance.currentState.status == ComponentUiState.locked, 
                            productQuantityPressed: $productQuantityPressed,
                            onDeleteProduct: productVM.ignoreProduct,
                            onChangeProduct: productVM.replaceProduct,
                            updateProductQuantity: { qty in
                                productVM.updateQuantity(quantity: qty)
                            }
                        )
                    )
                case "ignored", "deleted":
                    params.ignoredProduct.content(
                        params: RecipeDetailsIgnoredProductParameters(
                            ingredientName: ingredient.name,
                            ingredientQuantity: ingredient.attributes?.quantity,
                            ingredientUnit: ingredient.attributes?.unit,
                            guestsCount: guestCount.wrappedValue,
                            defaultRecipeGuest: defaultRecipeGuest,
                            onChooseProduct: productVM.replaceProduct)
                    )
                default:
                    params.loadingProduct.content(params: BaseLoadingParameters())
                }
            }
        }
    }
}
