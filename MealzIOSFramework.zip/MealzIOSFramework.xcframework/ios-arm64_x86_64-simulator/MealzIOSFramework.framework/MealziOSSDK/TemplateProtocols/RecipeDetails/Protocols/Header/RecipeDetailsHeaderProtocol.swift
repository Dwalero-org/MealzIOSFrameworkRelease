//
//  RecipeDetailsHeaderProtocol.swift
//  
//
//  Created by didi on 7/6/23.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for Recipe Details Header
 
 - infos: an instance of ``RecipeDetailsHeaderParameters``
 - steps: [RecipeDetailTags] -> Each of the Tags to display after the title
 - onRecipeDetailsClosed: () -> Void: A closure used to close the Recipe Details & go back to the previous page
 - onUpdateGuests:  (Int) -> Void: A closure allowing the user to update the number of guests the recipe is tailored for 
 */
@available(iOS 14, *)
public protocol RecipeDetailsHeaderProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsHeaderParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsHeaderParameters {
    public let mediaURL: String?
    public let title: String
    public let difficulty: Int
    public let totalTime: String
    public let preparationTime: String
    public let cookingTime: String
    public let restingTime: String
    public let isLikeEnabled: Bool
    public let recipeId: String
    public let recipeGuests: Int
    public let currentGuests: Int
    public let guestUpdating: Bool
    public let isForMealPlanner: Bool
    public let tags: [RecipeDetailTags]
    
    public let onRecipeDetailsClosed: () -> Void
    public let onUpdateGuests: (Int) -> Void
    
    public init(
        mediaURL: String?,
        title: String,
        difficulty: Int,
        totalTime: String,
        preparationTime: String,
        cookingTime: String,
        restingTime: String,
        isLikeEnabled: Bool,
        recipeId: String,
        recipeGuests: Int,
        currentGuests: Int,
        guestUpdating: Bool,
        isForMealPlanner: Bool,
        tags: [RecipeDetailTags],
        onRecipeDetailsClosed: @escaping () -> Void,
        onUpdateGuests: @escaping (Int) -> Void
    ) {
        self.mediaURL = mediaURL
        self.title = title
        self.difficulty = difficulty
        self.totalTime = totalTime
        self.preparationTime = preparationTime
        self.cookingTime = cookingTime
        self.restingTime = restingTime
        self.isLikeEnabled = isLikeEnabled
        self.recipeId = recipeId
        self.recipeGuests = recipeGuests
        self.currentGuests = currentGuests
        self.guestUpdating = guestUpdating
        self.isForMealPlanner = isForMealPlanner
        self.tags = tags
        self.onRecipeDetailsClosed = onRecipeDetailsClosed
        self.onUpdateGuests = onUpdateGuests
    }
}
