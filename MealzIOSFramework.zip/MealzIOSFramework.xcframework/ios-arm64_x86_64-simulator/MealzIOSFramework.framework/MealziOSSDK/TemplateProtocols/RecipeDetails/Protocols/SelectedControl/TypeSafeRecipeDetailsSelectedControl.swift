//
//  File.swift
//  
//
//  Created by Damien Walerowicz on 02/01/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsSelectedControl: RecipeDetailsSelectedControlProtocol {
    private let _content: (RecipeDetailsSelectedControlParameters) -> AnyView

    public init<T: RecipeDetailsSelectedControlProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeDetailsSelectedControlParameters) -> some View {
        _content(params)
    }
}
