//
//  RecipeDetailsFooterProtocol.swift
//  
//
//  Created by didi on 7/6/23.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for Recipe Details Footer
 
 - recipeId: String -> The recipeId of the current Recipe
 - guestCount: Int -> The numberOfGuests set by the catalog that launched the RecipeDetails
 - isInCart: Bool -> Recipe is currently in the user's cart
 - onContinueToBasket: (() -> Void)?: An optional closure that can be used to navigate the user to the basket. Calling this will also add the Recipe to the user's basket
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsFooterProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsFooterParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsFooterParameters {
    public let totalPriceOfProductsAdded: Double
    public let totalPriceOfProductsAddedPerGuest: Double
    public let totalPriceOfRemainingProducts: Double
    public let recipeStickerPrice: Double
    public let numberOfGuests: Int
    public let priceStatus: ComponentUiState
    public let ingredientsStatus: IngredientStatus
    public let isAddingAllIngredients: Bool
    public let cookOnlyMode: Bool
    public let currentSelectedTab: SelectedControlPage
    public let callToAction: () -> Void
 
    public init(
        totalPriceOfProductsAdded: Double,
        totalPriceOfProductsAddedPerGuest: Double,
        totalPriceOfRemainingProducts: Double,
        recipeStickerPrice: Double,
        numberOfGuests: Int,
        priceStatus: ComponentUiState,
        ingredientsStatus: IngredientStatus,
        isAddingAllIngredients: Bool,
        cookOnlyMode: Bool,
        currentSelectedTab: SelectedControlPage,
        callToAction: @escaping () -> Void
    ) {
        self.totalPriceOfProductsAdded = totalPriceOfProductsAdded
        self.totalPriceOfProductsAddedPerGuest = totalPriceOfProductsAddedPerGuest
        self.totalPriceOfRemainingProducts = totalPriceOfRemainingProducts
        self.recipeStickerPrice = recipeStickerPrice
        self.numberOfGuests = numberOfGuests
        self.priceStatus = priceStatus
        self.ingredientsStatus = ingredientsStatus
        self.isAddingAllIngredients = isAddingAllIngredients
        self.cookOnlyMode = cookOnlyMode
        self.currentSelectedTab = currentSelectedTab
        self.callToAction = callToAction
    }
}
