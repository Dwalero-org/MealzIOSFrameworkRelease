//
//  RecipeDetailsStepsProtocol.swift
//  
//
//  Created by didi on 7/6/23.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the Recipe Details Steps Section
 
 - activeStep: Binding<Int> -> The active cooking step the user is on. For example, the first step is usually "Cut the vegetables."
 - steps: [RecipeStep] -> Each of the steps to display that the user can interact with. For example, a step could be "Add a pinch of salt."
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsStepsProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsStepsParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsStepsParameters {
    public let activeStep: Binding<Int>
    public let steps: [RecipeStep]
 
    public init(activeStep: Binding<Int>, steps: [RecipeStep]) {
        self.activeStep = activeStep
        self.steps = steps
    }
}
