//
//  TypeSafeRecipeDetailsHeader.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsHeader: RecipeDetailsHeaderProtocol {
    private let _content: (RecipeDetailsHeaderParameters) -> AnyView

    public init<T: RecipeDetailsHeaderProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: RecipeDetailsHeaderParameters) -> some View {
        _content(params)
    }
}
