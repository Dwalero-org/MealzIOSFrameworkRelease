//
//  File.swift
//  
//
//  Created by Damien Walerowicz on 02/01/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public protocol RecipeDetailsSelectedControlProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsSelectedControlParameters) -> Content
}

@available(iOS 14, *)
public struct RecipeDetailsSelectedControlParameters {
    @Binding public var selection: SelectedControlPage
    
    public init(selection: Binding<SelectedControlPage>) {
        _selection = selection
    }
}
