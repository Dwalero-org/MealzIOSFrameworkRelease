//
//  RecipeDetailsIngredientsParameters.swift
//  
//
//  Created by didi on 7/6/23.
//

import Foundation
import mealzcore

/**
 Data object for the Recipe Details Ingredients section
 
 - ingredients: [Ingredient]: Ingredients included in the Recipe.
 - recipeGuests: Int: How many guests the recipe is ideal for, sourced from VM.
 - currentGuests: Int: The current number of guests.
 - guestUpdating: Bool: A flag indicating whether the counter is being updated.
 
 */
public struct RecipeDetailsIngredientsParameters {
    public let ingredients: [Ingredient]
    public let recipeGuests: Int
    public let currentGuests: Int

    public init(
        ingredients: [Ingredient],
        recipeGuests: Int,
        currentGuests: Int
    ) {
        self.ingredients = ingredients
        self.recipeGuests = recipeGuests
        self.currentGuests = currentGuests
    }
}
