//
//  RecipeDetailsSponsorProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the Recipes Details Sponsor Section
 
 - sponsor: Sponsor -> the content & details about the Brand currently sponsoring the recipe
 - onSponsorTapped: () -> Void: A closure that navigates to the Sponsor Details page
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsSponsorProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: RecipeDetailsSponsorParameters) -> Content
}

public struct RecipeDetailsSponsorParameters {
    public let sponsor: Sponsor
    public let onSponsorTapped: () -> Void
 
    public init(sponsor: Sponsor, onSponsorTapped: @escaping () -> Void) {
        self.sponsor = sponsor
        self.onSponsorTapped = onSponsorTapped
    }
}
