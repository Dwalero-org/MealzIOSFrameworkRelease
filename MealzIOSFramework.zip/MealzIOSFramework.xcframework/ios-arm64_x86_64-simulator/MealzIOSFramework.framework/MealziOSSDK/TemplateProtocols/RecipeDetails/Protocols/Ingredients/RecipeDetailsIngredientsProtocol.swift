//
//  RecipeDetailsIngredientsProtocol.swift
//  
//
//  Created by didi on 7/6/23.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for Recipe Details Ingredients Section
 
 - data: an instance of ``RecipeDetailsIngredientsParameters``
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsIngredientsProtocol {
    associatedtype Content: View
    @ViewBuilder func content(
        params: RecipeDetailsIngredientsParameters
    ) -> Content
}
