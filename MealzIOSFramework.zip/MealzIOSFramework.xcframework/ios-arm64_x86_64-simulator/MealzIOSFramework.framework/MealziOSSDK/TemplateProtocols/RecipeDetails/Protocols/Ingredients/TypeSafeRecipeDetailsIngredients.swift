//
//  TypeSafeRecipeDetailsIngredients.swift
//  
//
//  Created by didi on 10/10/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct TypeSafeRecipeDetailsIngredients: RecipeDetailsIngredientsProtocol {
    private let _content: (
        RecipeDetailsIngredientsParameters
    ) -> AnyView

    public init<T: RecipeDetailsIngredientsProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(
        params: RecipeDetailsIngredientsParameters
    ) -> some View {
        _content(params)
    }
}
