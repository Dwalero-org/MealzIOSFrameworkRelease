//
//  RecipeDetailsParametersProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 04/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the necessary parameters for the Recipe Details Page.
 
 - header:  An implementation of ``RecipeDetailsHeaderProtocol``. The content of the header in the recipe details.
 - sponsor:  An implementation of ``RecipeDetailsSponsorProtocol``. The content of the sponsor button in the recipe details.
 - ingredients:  An implementation of ``RecipeDetailsIngredientsProtocol``. The content of the ingredients list in the recipe details.
 - steps:  An implementation of ``RecipeDetailsStepsProtocol``. The content of the steps in the recipe details.
 - footer:  An implementation of ``RecipeDetailsFooterProtocol``. TThe content of the footer in the recipe details.
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onClosed: () -> Void: A closure that is called when the close button is pressed.
 - onSponsorDetailsTapped: (Sponsor) -> Void: A closure that is called when the sponsor details button is pressed.
 - onContinueToBasket: (() -> Void)?: An optional closure that is called when the continue to basket button is pressed.
 
 */
@available(iOS 14, *)
public protocol RecipeDetailsParametersProtocol {
    associatedtype Header: RecipeDetailsHeaderProtocol
    associatedtype SponsorButton: RecipeDetailsSponsorProtocol
    associatedtype SelectedControl : RecipeDetailsSelectedControlProtocol
    associatedtype Title : BaseTitleProtocol
    associatedtype Ingredients: RecipeDetailsIngredientsProtocol
    associatedtype Steps: RecipeDetailsStepsProtocol
    associatedtype Footer: RecipeDetailsFooterProtocol
    
    associatedtype IngredientsAtHomeToggleButton: BaseButtonProtocol
    associatedtype UnavailableIngredientsToggleButton: BaseButtonProtocol
    associatedtype IngredientsAtHome: NotInBasketProductProtocol
    associatedtype UnavailableIngredients: NotInBasketProductProtocol
    
    var header: Header { get }
    var sponsor: SponsorButton { get }
    var selectedControl: SelectedControl { get }
    var numberOfIngredientsTitle: Title { get }
    var ingredients: Ingredients { get }
    var steps: Steps { get }
    var footer: Footer { get }
    
    var ingredientsAtHomeToggleButton: IngredientsAtHomeToggleButton { get }
    var unavailableIngredientsToggleButton: UnavailableIngredientsToggleButton { get }
    var ingredientsAtHome: IngredientsAtHome { get }
    var unavailableIngredients: UnavailableIngredients { get }
    
    var actions: RecipeDetailsActions { get set }
}

public struct RecipeDetailsActions {
    var onClosed: () -> Void
    var onSponsorDetailsTapped: (Sponsor) -> Void
    var onContinueToBasket: (() -> Void)?
    var onReplaceProduct: (String) -> Void
    
    public init(
        onClosed: @escaping () -> Void,
        onSponsorDetailsTapped: @escaping (Sponsor) -> Void,
        onContinueToBasket: (() -> Void)? = nil,
        onReplaceProduct: @escaping (String) -> Void
    ) {
        self.onClosed = onClosed
        self.onSponsorDetailsTapped = onSponsorDetailsTapped
        self.onContinueToBasket = onContinueToBasket
        self.onReplaceProduct = onReplaceProduct
    }
}
