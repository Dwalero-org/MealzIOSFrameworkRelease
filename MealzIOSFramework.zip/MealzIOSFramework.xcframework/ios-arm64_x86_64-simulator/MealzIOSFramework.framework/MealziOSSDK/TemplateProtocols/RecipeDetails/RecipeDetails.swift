//
//  RecipeDetails.swift
//
//
//  Created by Walerowicz on 13/12/2023.
//

/**
 This is a template view for displaying recipe details. It includes a header, ingredients list, steps, and a footer.
 
 Mandatory Parameters:
 - params: The RecipeDetailsParameters
 - recipeId: The ID of the recipe.
 - isForMealPlanner: A flag to indicate whether the recipe is for meal planner (using the budget) or not. Default is false.
 Setting true will use the guest count set by the user corresponding to the meal planner instead of the default guest count stored in the recipe itself.
 
 */

import Foundation
import SwiftUI
import mealzcore


@available(iOS 14, *)
public struct RecipeDetailTags: Identifiable {
    public let mealzIcon: Image?
    public let iconUrl: URL?
    public let text: String
    public let tagName: String
    public var id = UUID()
}

public enum SelectedControlPage: Int {
    case shopping
    case cooking
}

@available(iOS 14, *)
public struct RecipeDetails<
    RecipeDetailsParameters: RecipeDetailsParametersProtocol,
    ProductParameters: RecipeDetailsProductProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: RecipeDetailsParameters
    private let productParams: ProductParameters
    private let baseViews: BaseViews
    /// The ID of the recipe. This is used to fetch the recipe details from the server.
    public var recipeId: String
    private var isForMealPlanner: Bool
    
    /// The view model for the recipe card. It fetches and stores the recipe details.
    @StateObject var viewModel: DynamicRecipeDetailsVM
    
    public init(
        params: RecipeDetailsParameters,
        productParams: ProductParameters,
        baseViews: BaseViews,
        recipeId: String,
        isForMealPlanner: Bool = false
    ) {
        self.params = params
        self.productParams = productParams
        self.baseViews = baseViews
        self.recipeId = recipeId
        self.isForMealPlanner = isForMealPlanner
        _viewModel = StateObject(wrappedValue:
                                    DynamicRecipeDetailsVM(
                                        continueShopping: params.actions.onClosed,
                                        changeProduct: params.actions.onReplaceProduct
                                    )
        )
    }
    
    var difficulty: String {
        get {
            switch(viewModel.recipe?.difficulty ?? 0) {
            case 1:
                return Localization.recipe.lowDifficulty.localised
            case 2:
                return Localization.recipe.mediumDifficulty.localised
            default:
                return Localization.recipe.highDifficulty.localised
            }
        }
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(
                uiState: viewModel.state?.recipe,
                loadingView: {
                    baseViews.loading.content(params: BaseLoadingParameters())
                },
                emptyView: {
                    baseViews.empty.content(params: BaseEmptyParameters())
                },
                successView: {
                    SuccessView(
                        params: params,
                        productParams: productParams,
                        baseViews: baseViews,
                        recipeId: recipeId,
                        isForMealPlanner: isForMealPlanner,
                        viewModel: viewModel)
                })}.onAppear {
                    viewModel.registerListeners()
                    if viewModel.recipe == nil {
                        viewModel.setEvent(event: DynamicRecipeDetailContractEvent.SetRecipeId(recipeId: recipeId))
                    }
                }
                .onDisappear { viewModel.dispose() }
    }
}

@available(iOS 14, *)
extension RecipeDetails {
    internal struct SuccessView: View {
        private let params: RecipeDetailsParameters
        private let productParams: ProductParameters
        private let baseViews: BaseViews
        /// The ID of the recipe. This is used to fetch the recipe details from the server.
        public var recipeId: String
        private var isForMealPlanner: Bool
        @ObservedObject var viewModel: DynamicRecipeDetailsVM
        @SwiftUI.State private var selection: SelectedControlPage
        
        init(params: RecipeDetailsParameters,
             productParams: ProductParameters,
             baseViews: BaseViews,
             recipeId: String,
             isForMealPlanner: Bool,
             viewModel: DynamicRecipeDetailsVM) {
            self.params = params
            self.productParams = productParams
            self.baseViews = baseViews
            self.recipeId = recipeId
            self.isForMealPlanner = isForMealPlanner
            self.viewModel = viewModel
            self._selection = State(initialValue: isForMealPlanner ? .cooking : .shopping)
        }
        
        var difficulty: String {
            get {
                switch(viewModel.recipe?.difficulty ?? 0) {
                case 1:
                    return Localization.recipe.lowDifficulty.localised
                case 2:
                    return Localization.recipe.mediumDifficulty.localised
                default:
                    return Localization.recipe.highDifficulty.localised
                }
            }
        }
        
        var body: some View {
            var tags: [RecipeDetailTags] = []
            if let recipe = viewModel.recipe {
                if recipe.preparationTimeIos != "0m" && recipe.preparationTimeIos != "0s"{
                    tags.append(RecipeDetailTags(
                        mealzIcon: Image.mealzIcon(icon: .knife),
                        iconUrl: nil,
                        text: recipe.preparationTimeIos,
                        tagName: Localization.recipe.preparationTime.localised
                    ))
                }
                if recipe.cookingTimeIos != "0m" && recipe.cookingTimeIos != "0s" {
                    tags.append(RecipeDetailTags(
                        mealzIcon: Image.mealzIcon(icon: .pan),
                        iconUrl: nil,
                        text: recipe.cookingTimeIos,
                        tagName: Localization.recipe.cookTime.localised
                    ))
                }
                tags.append(RecipeDetailTags(
                    mealzIcon: Image.mealzIcon(icon: .chefHat),
                    iconUrl: nil,
                    text: difficulty,
                    tagName: Localization.catalog.difficulty.localised
                ))
                if let recipeTags = recipe.relationships?.tags?.data {
                    for tag in recipeTags {
                        if let attributes = tag.attributes {
                            let iconUrl: URL? = if let url = attributes.iconUrl { URL(string: url) } else { nil }
                            tags.append(RecipeDetailTags(
                                mealzIcon: nil,
                                iconUrl: iconUrl,
                                text: attributes.name,
                                tagName: attributes.tagTypeId
                            ))
                        }
                    }
                }
            }
            
            return VStack(spacing: 0) {
                ScrollView {
                    if let recipe = viewModel.recipe {
                        if recipe.isSponsored, let sponsors = recipe.relationships?.sponsors?.data {
                            ForEach(sponsors, id: \.id) { sponsor in
                                params.sponsor.content(
                                    params: RecipeDetailsSponsorParameters(sponsor: sponsor) {
                                        params.actions.onSponsorDetailsTapped(sponsor)
                                    })
                            }
                        }
                        headerContent(
                            recipe: recipe,
                            tags: tags
                        )
                    }
                    
                    if !isForMealPlanner {
                        SelectedControl(selection: $selection, params: params)
                    } else { Color.clear.padding(.top, Dimension.sharedInstance.mPadding) }
                    
                    switch(selection) {
                    case .shopping:
                        showProductsAndAlternatives()
                    case .cooking:
                        if let ingredients = viewModel.recipe?.relationships?.ingredients?.data {
                            IngredientsContent(
                                ingredients: ingredients,
                                params: params,
                                numberOfGuests: Int(viewModel.recipe?.attributes?.numberOfGuests ?? 4),
                                currentGuests: Int(viewModel.guest)
                            )
                        }
                        if let steps = viewModel.recipe?.sortedStep {
                            StepsContent(steps: steps, params: params)
                        }
                    }
                }
                RecipeDetailsFooter(
                    footerContent: params.footer,
                    loading: baseViews.loading,
                    recipeId: recipeId,
                    cookOnlyMode: isForMealPlanner,
                    currentSelectedTab: selection,
                    footerVM: viewModel.dynamicRecipeDetailFooterViewModel
                )
            }
        }
    }
}

@available(iOS 14, *)
extension RecipeDetails.SuccessView {
    func showProductsAndAlternatives() -> some View {
        VStack {
            if let ingredients = viewModel.recipe?.relationships?.ingredients?.data {
                params.numberOfIngredientsTitle.content(params: TitleParameters(
                    title: String(format: String.localizedStringWithFormat(
                        Localization.recipe.numberOfIngredients(
                            numberOfIngredients: Int32(ingredients.count)).localised,
                        ingredients.count), ingredients.count),
                    subtitle: nil))
            }
            ForEach(viewModel.canBeAddedProducts) { BasketEntryInRecipeViewModel in
                RecipeDetailsProduct(
                    params: productParams,
                    BasketEntryInRecipeViewModel: BasketEntryInRecipeViewModel,
                    guestCount: $viewModel.guest,
                    defaultRecipeGuest: Int(viewModel.recipe?.attributes?.numberOfGuests ?? 4))
            }
            if !viewModel.oftenDeletedProducts.isEmpty {
                NotInBasketTitle(
                    products: viewModel.oftenDeletedProducts,
                    title: String(format: String.localizedStringWithFormat(
                        Localization.basket.ownedProducts(
                            numberOfProducts: Int32(viewModel.oftenDeletedProducts.count)).localised,
                        viewModel.oftenDeletedProducts.count),
                                  viewModel.oftenDeletedProducts.count),
                    guestsCount: viewModel.guest,
                    defaultRecipeGuest: Int(viewModel.recipe?.attributes?.numberOfGuests ?? 4),
                    productTemplate: params.ingredientsAtHome,
                    buttonTemplate: params.ingredientsAtHomeToggleButton)
            }
            if !viewModel.unavailableProducts.isEmpty {
                NotInBasketTitle(
                    products: viewModel.unavailableProducts,
                    title: String(format: String.localizedStringWithFormat(
                        Localization.basket.unavailableProducts(
                            numberOfProducts: Int32(viewModel.unavailableProducts.count)).localised,
                        viewModel.unavailableProducts.count),
                                  viewModel.unavailableProducts.count),
                    guestsCount: viewModel.guest,
                    defaultRecipeGuest: Int(viewModel.recipe?.attributes?.numberOfGuests ?? 4),
                    productTemplate: params.unavailableIngredients,
                    buttonTemplate: params.unavailableIngredientsToggleButton)
            }
        }
    }
}


@available(iOS 14, *)
extension RecipeDetails.SuccessView {
    func headerContent(recipe: Recipe, tags: [RecipeDetailTags]) -> some View {
        return VStack {
            params.header.content(
                params: RecipeDetailsHeaderParameters(
                    mediaURL: recipe.attributes?.mediaUrl,
                    title: recipe.attributes?.title ?? "",
                    difficulty: Int(truncating: recipe.attributes?.difficulty ?? 1),
                    totalTime: recipe.totalTime,
                    preparationTime: recipe.preparationTimeIos,
                    cookingTime: recipe.cookingTimeIos,
                    restingTime: recipe.restingTimeIos,
                    isLikeEnabled: viewModel.isLikeEnabled,
                    recipeId: recipeId,
                    recipeGuests: Int(recipe.attributes?.numberOfGuests ?? 4),
                    currentGuests: Int(viewModel.guest),
                    guestUpdating: Bool(viewModel.guestUpdating),
                    isForMealPlanner: isForMealPlanner,
                    tags: tags,
                    onRecipeDetailsClosed: params.actions.onClosed,
                    onUpdateGuests: { newGuest in
                        viewModel.setEvent(event: DynamicRecipeDetailContractEvent.UpdateGuests(guests: Int32(newGuest)))
                        viewModel.guest = newGuest
                    })
            )
        }
    }
}

@available(iOS 14, *)
extension RecipeDetails {
    internal struct IngredientsContent: View {
        private let ingredients: [Ingredient]
        private let params: RecipeDetailsParameters
        private let numberOfGuests: Int
        private let currentGuests: Int
        init(
            ingredients: [Ingredient],
            params: RecipeDetailsParameters,
            numberOfGuests: Int,
            currentGuests: Int
        ) {
            self.ingredients = ingredients
            self.params = params
            self.numberOfGuests = numberOfGuests
            self.currentGuests = currentGuests
        }
        var body: some View {
            params.ingredients.content(
                params:
                    RecipeDetailsIngredientsParameters(
                        ingredients: ingredients,
                        recipeGuests: numberOfGuests,
                        currentGuests: currentGuests
                    ))
        }
    }
}

@available(iOS 14, *)
extension RecipeDetails {
    internal struct SelectedControl: View {
        private let params: RecipeDetailsParameters
        
        @Binding var selection: SelectedControlPage
        init(selection: Binding<SelectedControlPage>, params: RecipeDetailsParameters) {
            _selection = selection
            self.params = params
        }
        
        var body: some View {
            return params.selectedControl.content(
                params: RecipeDetailsSelectedControlParameters(selection: $selection))
        }
    }
}

@available(iOS 14, *)
extension RecipeDetails {
    internal struct StepsContent: View {
        private let steps: [RecipeStep]
        private let params: RecipeDetailsParameters
        init(steps: [RecipeStep], params: RecipeDetailsParameters) {
            self.steps = steps
            self.params = params
        }
        /// A state variable that stores the index of the currently active step in the recipe.
        @SwiftUI.State private var activeStep = -1
        var body: some View {
            return params.steps.content(
                params: RecipeDetailsStepsParameters(
                    activeStep: $activeStep,
                    steps: steps)
            )
        }
    }
}
