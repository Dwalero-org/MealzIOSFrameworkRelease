//
//  RecipeDetailsFooter.swift
//
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import Foundation
import mealzcore
import SwiftUI

@available(iOS 14, *)
public struct RecipeDetailsFooter<
    FooterTemplate: RecipeDetailsFooterProtocol,
    FooterLoadingTemplate: LoadingProtocol
>: View {
    let footerContent: FooterTemplate
    let loading: FooterLoadingTemplate
    let cookOnlyMode: Bool
    @ObservedObject var footerVM: RecipeDetailsFooterVM
    let currentSelectedTab: SelectedControlPage
    
    @ObservedObject var priceVM: PriceVM = PriceVM()
    
    init(
        footerContent: FooterTemplate,
        loading: FooterLoadingTemplate,
        recipeId: String,
        cookOnlyMode: Bool,
        currentSelectedTab: SelectedControlPage,
        footerVM: DynamicRecipeDetailFooterViewModel
    ) {
        self.footerContent = footerContent
        self.loading = loading
        self.cookOnlyMode = cookOnlyMode
        _footerVM = ObservedObject(wrappedValue: RecipeDetailsFooterVM(instance: footerVM))
        self.currentSelectedTab = currentSelectedTab
        if cookOnlyMode { priceVM.setRecipeForMealPlanner(recipeId: recipeId) }
        else {
            priceVM.setRecipe(recipeId: recipeId, guestNumber: Int32(Int(footerVM.currentState.guests ?? 4)))
        }
    }
    
    public var body: some View {
        VStack {
            if let ingredientStatus = footerVM.ingredientStatus {
                footerContent.content(
                    params: RecipeDetailsFooterParameters(
                        totalPriceOfProductsAdded: footerVM.price ?? 0,
                        totalPriceOfProductsAddedPerGuest: footerVM.pricePerGuest ?? 0,
                        totalPriceOfRemainingProducts : footerVM.priceForRemainingProduct ?? 0,
                        recipeStickerPrice: priceVM.pricing?.price ?? 0.0,
                        numberOfGuests: Int(footerVM.state?.guests ?? 4),
                        priceStatus: footerVM.priceStatus ?? ComponentUiState.loading,
                        ingredientsStatus: ingredientStatus,
                        isAddingAllIngredients: footerVM.isAddingAllIngredients,
                        cookOnlyMode: cookOnlyMode,
                        currentSelectedTab: currentSelectedTab,
                        callToAction: footerVM.onContinueShopping
                    )
                )
            }
        }
        .onAppear(perform: {
            footerVM.instance.registerListeners()
            priceVM.registerListeners()
        })
        .onDisappear(perform: {
            footerVM.instance.dispose()
            priceVM.dispose()
        })
    }
}
