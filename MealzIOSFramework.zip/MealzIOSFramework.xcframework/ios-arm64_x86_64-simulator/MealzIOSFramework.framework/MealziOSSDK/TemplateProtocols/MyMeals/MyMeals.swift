//
//  MyMeals.swift
//  MiamIOSFramework
//
//  Created by didi on 02/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the MyMeals page where users can see the recipes in their basket.
 
 Mandatory Parameters:
 - params:  An implementation of ``MyMealsParametersProtocol``, usually the default ``MyMealsParameters``
 - gridConfig:  A ``CatalogRecipesListGridConfig`` which selects all the bounds for the recipes list, such as the spacing, recipe card height & width, etc.
 
 */
@available(iOS 14, *)
public struct MyMeals<
    MyMealsParameters: MyMealsParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MyMealsParameters
    private let baseViews: BaseViews
    @ObservedObject private var myMealsViewModel: MyMealVM
    let gridConfig: CatalogRecipesListGridConfig
    
    // when embedded in MyBasket
    public init(
        params: MyMealsParameters,
        baseViews: BaseViews,
        gridConfig: CatalogRecipesListGridConfig,
        myMealsViewModel: MyMealVM
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        _myMealsViewModel = ObservedObject(wrappedValue: myMealsViewModel)
    }
    
    // when standalone
    public init(
        params: MyMealsParameters,
        baseViews: BaseViews,
        gridConfig: CatalogRecipesListGridConfig
    ) {
        self.params = params
        self.baseViews = baseViews
        self.gridConfig = gridConfig
        self.myMealsViewModel = MyMealVM()
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            VStack {
                params.title.content(params: TitleParameters(
                    title:
                        String(format: String.localizedStringWithFormat(
                            Localization.myMeals.mealsAdded(numberOfMeals: Int32(myMealsViewModel.recipes.count)).localised,
                            myMealsViewModel.recipes.count),
                               myMealsViewModel.recipes.count),
                    subtitle: Localization.myMeals.goToCatalog.localised))
                params.itemSelectorCTA.content(params: BaseButtonParameters(
                    buttonText: Localization.myBasket.needSomethingElse.localised,
                    buttonPressed: false,
                    onButtonAction: {
                        if let open = params.actions.openItemSelector { open(nil) }
                    })
                )
                UIStateWrapperView(uiState: myMealsViewModel.state?.recipes) {
                    baseViews.loading.content(params: BaseLoadingParameters())
                } emptyView: {
                    baseViews.empty.content(params: BaseEmptyParameters(
                        onOptionalCallback: params.actions.onNoResultsRedirect))
                } successView: {
                    SuccessContent(params: params, baseViews: baseViews, myMealsViewModel: myMealsViewModel, gridConfig: gridConfig)
                }
            }
            .onAppear { myMealsViewModel.registerListeners() }
            .onDisappear { myMealsViewModel.dispose() }
        }
    }
    
    struct SuccessContent: View {
        private let params: MyMealsParameters
        private let baseViews: BaseViews
        @ObservedObject private var myMealsViewModel: MyMealVM
        let gridConfig: CatalogRecipesListGridConfig
        
        init(params: MyMealsParameters, baseViews: BaseViews, myMealsViewModel: MyMealVM, gridConfig: CatalogRecipesListGridConfig) {
            self.params = params
            self.baseViews = baseViews
            self.myMealsViewModel = myMealsViewModel
            self.gridConfig = gridConfig
        }
        
        var body: some View {
            ScrollView {
                if myMealsViewModel.recipes.count < 1 {
                    baseViews.empty.content(params: BaseEmptyParameters(
                        onOptionalCallback: params.actions.onNoResultsRedirect))
                }
                LazyVGrid(
                    columns: Array(
                        repeating: GridItem(.flexible()),
                        count: gridConfig.numberOfColumns),
                    spacing: 0
                ) {
                    ForEach(myMealsViewModel.recipes) { recipe in
                        MyMealRecipe(
                            recipeCard: params.recipeCard,
                            recipeCardLoading: params.recipeCardLoading,
                            recipe: recipe,
                            recipeCardDimensions: gridConfig.recipeCardDimensions,
                            onShowRecipeDetails: params.actions.onShowRecipeDetails
                        )
                    }
                    .padding(.vertical, gridConfig.spacing.height)
                    .padding(.horizontal, gridConfig.spacing.width)
                }
            }
        }
    }
}
