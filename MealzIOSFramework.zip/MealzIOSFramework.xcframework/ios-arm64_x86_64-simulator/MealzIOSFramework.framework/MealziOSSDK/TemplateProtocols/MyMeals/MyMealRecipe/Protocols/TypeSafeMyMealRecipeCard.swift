//
//  TypeSafeMyMealRecipeCard.swift
//
//
//  Created by miam x didi on 04/01/2024.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafeMyMealRecipeCard: MyMealRecipeCardProtocol {
    private let _content: (MyMealRecipeCardParameters) -> AnyView

    public init<T: MyMealRecipeCardProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MyMealRecipeCardParameters) -> some View {
        _content(params)
    }
}
