//
//  MyMealRecipe.swift
//
//
//  Created by miam x didi on 04/01/2024.
//

import SwiftUI
import mealzcore

/**
 An MyMealRecipe that handles basket recipe overview, products in basket, products out of basket.
 
 Mandatory Parameters:
 - recipeCard:  An implementation of ``MyMealRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - recipe: Recipe -> The Recipe that the view will display
 - recipeCardDimensions: CGSize ->  The width & height of the recipe card
 
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 
 */
@available(iOS 14, *)
public struct MyMealRecipe<
    CardTemplate: MyMealRecipeCardProtocol,
    LoadingTemplate: RecipeCardLoadingProtocol
>: View {
    private let recipeCard: CardTemplate
    private let recipeCardLoading: LoadingTemplate
    private let recipe: Recipe
    private let recipeCardDimensions: CGSize
    private let onShowRecipeDetails: (String) -> Void
    
    @StateObject private var basketPreviewVM: BasketPreviewVM
    @SwiftUI.State var isDeleting: Bool = false
    
    init(
        recipeCard: CardTemplate,
        recipeCardLoading: LoadingTemplate,
        recipe: Recipe,
        recipeCardDimensions: CGSize,
        onShowRecipeDetails: @escaping (String) -> Void
    ) {
        self.recipeCard = recipeCard
        self.recipeCardLoading = recipeCardLoading
        self.recipe = recipe
        self.recipeCardDimensions = recipeCardDimensions
        self.onShowRecipeDetails = onShowRecipeDetails
        _basketPreviewVM = StateObject(wrappedValue: BasketPreviewVM(recipeId: recipe.id))
    }
    
    public var body: some View {
        UIStateWrapperView(uiState: basketPreviewVM.state?.recipeInfo) {
            recipeCardLoading.content(params: RecipeCardLoadingParameters(recipeCardDimensions: recipeCardDimensions))
        }
    emptyView: { /* there is no empty state */ }
    successView: { successContent() }
            .onAppear { basketPreviewVM.registerListeners() }
            .onDisappear { basketPreviewVM.dispose() }
    }
    
    func successContent() -> some View {
        return VStack {
            if let bpi = basketPreviewVM.basketPreviewInfo, let state = basketPreviewVM.state {
                recipeCard.content(
                    params: MyMealRecipeCardParameters(
                        recipeCardDimensions: recipeCardDimensions,
                        recipe: recipe,
                        numberOfGuests: Int(state.recipeGuest),
                        recipePrice: state.recipePrice,
                        numberOfProductsInRecipe: Int(bpi.foundEntriesCount),
                        isDeleting: isDeleting,
                        onDeleteRecipe: {
                            isDeleting = true
                            basketPreviewVM.setEvent(event: BasketPreviewContractEvent.RemoveRecipe(recipeId: recipe.id))
                        },
                        onShowRecipeDetails: onShowRecipeDetails
                    )
                )
            }
        }
    }
}
