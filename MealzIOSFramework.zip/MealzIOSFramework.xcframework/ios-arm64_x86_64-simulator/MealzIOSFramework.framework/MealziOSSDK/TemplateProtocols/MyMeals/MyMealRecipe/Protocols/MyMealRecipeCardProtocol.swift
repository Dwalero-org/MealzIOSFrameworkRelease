//
//  MyMealRecipeCardProtocol.swift
//
//
//  Created by miam x didi on 04/01/2024.
//

import SwiftUI
import mealzcore

/**
 An object containing all the items the MyMeal Recipe Card needs.
 
 - recipeCardDimensions: CGSize ->  The width & height of the recipe card
 - recipe: Recipe -> The Recipe object of the meal
 - numberOfGuests: Int -> The number of guests the recipe is designed for
 - totalPrice: Double -> The price of the meal
 - onDeleteRecipe: () -> Void ->  A closure to delete the recipe, & all it's ingredients, from the basket
 - onShowRecipeDetails: (String) -> Void ->  A closure that opens the RecipeDetails, passing in the recipeId
 */
@available(iOS 14, *)
public protocol MyMealRecipeCardProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MyMealRecipeCardParameters) -> Content
}

@available(iOS 13, *)
public struct MyMealRecipeCardParameters {
    public let recipeCardDimensions: CGSize
    public let recipe: Recipe
    public let numberOfGuests: Int
    public let recipePrice: Double
    public let numberOfProductsInRecipe: Int
    public let isDeleting: Bool
    public let onDeleteRecipe: () -> Void
    public let onShowRecipeDetails: (String) -> Void
    
    public init(
        recipeCardDimensions: CGSize,
        recipe: Recipe,
        numberOfGuests: Int,
        recipePrice: Double,
        numberOfProductsInRecipe: Int,
        isDeleting: Bool,
        onDeleteRecipe: @escaping () -> Void,
        onShowRecipeDetails: @escaping (String) -> Void
    ) {
        self.recipeCardDimensions = recipeCardDimensions
        self.recipe = recipe
        self.numberOfGuests = numberOfGuests
        self.recipePrice = recipePrice
        self.numberOfProductsInRecipe = numberOfProductsInRecipe
        self.isDeleting = isDeleting
        self.onDeleteRecipe = onDeleteRecipe
        self.onShowRecipeDetails = onShowRecipeDetails
    }
}
