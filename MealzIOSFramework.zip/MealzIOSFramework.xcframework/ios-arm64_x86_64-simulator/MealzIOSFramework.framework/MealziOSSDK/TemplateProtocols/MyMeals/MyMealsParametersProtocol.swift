//
//  MyMealsParametersProtocol.swift
//  
//
//  Created by didi on 11/10/2023.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the My Meals Page.
 - title:  An implementation of ``BaseTitleProtocol``
 - recipeCard:  An implementation of ``MyMealRecipeCardProtocol``
 - recipeCardLoading:  An implementation of ``RecipeCardLoadingProtocol``
 - loading:  An implementation of ``LoadingProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 - background: An implementation of ``BackgroundProtocol``
 
 - onNoResultsRedirect: () -> Void: A closure that navigates the user to a different page when the user doesn't have any recipes in their basket. This should usually navigate to the CatalogView
 - onShowRecipeDetails: (String) -> Void: A closure that opens the RecipeDetails, passing in the recipeId
 */
@available(iOS 14, *)
public protocol MyMealsParametersProtocol {
    associatedtype Title: BaseTitleProtocol
    associatedtype OpenItemSelectorCallToAction: BaseButtonProtocol
    associatedtype RecipeCard: MyMealRecipeCardProtocol
    associatedtype RecipeCardLoading: RecipeCardLoadingProtocol
    
    var title: Title { get }
    var itemSelectorCTA: OpenItemSelectorCallToAction { get }
    var recipeCard: RecipeCard { get }
    var recipeCardLoading: RecipeCardLoading { get }
    
    var actions: MyMealsActions { get set }
}

public struct MyMealsActions {
    var onNoResultsRedirect: () -> Void
    var onShowRecipeDetails: (String) -> Void
    var openItemSelector: ((String?) -> Void)?
    
    public init(
        onNoResultsRedirect: @escaping () -> Void,
        onShowRecipeDetails: @escaping (String) -> Void,
        openItemSelector: ((String?) -> Void)? = nil
    ) {
        self.onNoResultsRedirect = onNoResultsRedirect
        self.onShowRecipeDetails = onShowRecipeDetails
        self.openItemSelector = openItemSelector
    }
}
