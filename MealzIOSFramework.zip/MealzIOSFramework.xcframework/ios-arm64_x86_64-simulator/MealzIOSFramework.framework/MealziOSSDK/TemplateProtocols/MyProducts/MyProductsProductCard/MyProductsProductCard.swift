//
//  MyProductsProductCard.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 11/04/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A MyProductsProductCard that handles basket product overview.
 
 Mandatory Parameters:
 - productCard:  An implementation of ``MyProductsProductCardProtocol``
 - basketEntryVM: BasketEntryViewModel -> The VM of the BasketEntry that the view will display
 */
@available(iOS 14, *)
public struct MyProductsProductCard<
    ProductCardTemplate: MyProductsProductCardProtocol,
    LoadingProductTemplate: LoadingProtocol
>: View {
    private let productCard: ProductCardTemplate
    private let loadingProduct: LoadingProductTemplate
    @StateObject private var productVM: BasketEntryVM
    
    init(
        productCard: ProductCardTemplate,
        loadingProduct: LoadingProductTemplate,
        basketEntryVM: BasketEntryViewModel
    ) {
        self.productCard = productCard
        self.loadingProduct = loadingProduct
        _productVM = StateObject(wrappedValue: BasketEntryVM(instance: basketEntryVM))
    }
    
    public var body: some View {
        VStack {
            if productVM.instance.currentState.status == ComponentUiState.loading {
                loadingProduct.content(params: BaseLoadingParameters())
            } else { successContent() }
        }
        .onAppear { productVM.instance.registerListeners() }
        .onDisappear { productVM.instance.dispose() }
    }
    
    func successContent() -> some View {
        var isLocked: Bool {
            return productVM.state?.status == ComponentUiState.locked
                || productVM.state?.status == ComponentUiState.loading
            
        }
        return VStack {
            if let entry = productVM.entry {
                productCard.content(
                    params: MyProductsProductCardParameters(
                        entry: entry,
                        isLocked: isLocked,
                        onReplaceProduct: productVM.replaceProduct,
                        updateQuantity: { qty in
                            productVM.updateQuantity(quantity: qty)
                        }
                    )
                )
            }
        }
    }
}
