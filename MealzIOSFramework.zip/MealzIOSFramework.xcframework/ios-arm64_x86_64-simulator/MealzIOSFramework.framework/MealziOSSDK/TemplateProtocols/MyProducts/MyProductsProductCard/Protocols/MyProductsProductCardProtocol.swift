//
//  MyProductsProductCardProtocol.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 11/04/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 An object containing all the items the MyProductsProductCard needs.
 
 - entry: BasketEntry -> The BasketEntry object of the product
 - isDeleting: Bool -> A Bool to see if the product is currently being deleted
 - onDeleteProduct: () -> Void ->  A closure to delete the product, & all it's ingredients, from the basket
 */
@available(iOS 14, *)
public protocol MyProductsProductCardProtocol {
    associatedtype Content: View
    @ViewBuilder func content(params: MyProductsProductCardParameters) -> Content
}

@available(iOS 13, *)
public struct MyProductsProductCardParameters {
    public let entry: BasketEntry
    public let isLocked: Bool
    public let onReplaceProduct: () -> Void
    public let updateQuantity: (Int) -> Void
    
    public init(
        entry: BasketEntry,
        isLocked: Bool,
        onReplaceProduct: @escaping () -> Void,
        updateQuantity: @escaping (Int) -> Void
    ) {
        self.entry = entry
        self.isLocked = isLocked
        self.onReplaceProduct = onReplaceProduct
        self.updateQuantity = updateQuantity
    }
}
