//
//  TypeSafeMyProductsProductCard.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 11/04/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public struct TypeSafeMyProductsProductCard: MyProductsProductCardProtocol {
    private let _content: (MyProductsProductCardParameters) -> AnyView

    public init<T: MyProductsProductCardProtocol>(_ wrapped: T) where T.Content: View {
        self._content = { params in
            AnyView(wrapped.content(params: params))
        }
    }

    public func content(params: MyProductsProductCardParameters) -> some View {
        _content(params)
    }
}
