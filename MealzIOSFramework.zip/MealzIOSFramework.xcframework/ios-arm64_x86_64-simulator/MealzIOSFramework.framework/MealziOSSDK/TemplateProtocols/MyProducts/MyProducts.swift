//
//  Myproducts.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 11/04/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the MyProducts page where users can see the products in their basket.
 
 Mandatory Parameters:
 - params:  An implementation of ``MyProductsParametersProtocol``, usually the default ``MyProductsParameters``
 - baseViews:  An implementation of ``BaseViewsProtocol``
 - myProductsViewModel:  An implementation of ``MyProductsVM``
 
 */
@available(iOS 14, *)
public struct MyProducts<
    MyProductsParameters: MyProductsParametersProtocol,
    BaseViews: BaseViewsProtocol
>: View {
    private let params: MyProductsParameters
    private let baseViews: BaseViews
    @ObservedObject private var myProductsViewModel: MyProductsVM
    
    // when embedded in MyBasket
    public init(
        params: MyProductsParameters,
        baseViews: BaseViews,
        myProductsViewModel: MyProductsVM
    ) {
        self.params = params
        self.baseViews = baseViews
        _myProductsViewModel = ObservedObject(wrappedValue: myProductsViewModel)
    }
    
    // when standalone
    public init(
        params: MyProductsParameters,
        baseViews: BaseViews
    ) {
        self.params = params
        self.baseViews = baseViews
        self.myProductsViewModel = MyProductsVM(openItemSelector: params.actions.openItemSelector)
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: myProductsViewModel.state?.entries) {
                baseViews.loading.content(params: BaseLoadingParameters())
            } emptyView: {
                VStack {
                    params.itemSelectorCTA.content(params: BaseButtonParameters(
                        buttonText: Localization.myBasket.needSomethingElse.localised,
                        buttonPressed: false,
                        onButtonAction: { params.actions.openItemSelector(nil) })
                    )
                    baseViews.empty.content(params: BaseEmptyParameters(
                        onOptionalCallback: params.actions.onNoResultsRedirect))
                }
            } successView: {
                SuccessContent(params: params, baseViews: baseViews, myProductsViewModel: myProductsViewModel)
            }
            .onAppear { myProductsViewModel.registerListeners() }
            .onDisappear { myProductsViewModel.dispose() }
        }
    }
    
    struct SuccessContent: View {
        private let params: MyProductsParameters
        private let baseViews: BaseViews
        @ObservedObject private var myProductsViewModel: MyProductsVM
        
        init(params: MyProductsParameters, baseViews: BaseViews, myProductsViewModel: MyProductsVM) {
            self.params = params
            self.baseViews = baseViews
            self.myProductsViewModel = myProductsViewModel
        }
        
        var body: some View {
            ScrollView {
                params.itemSelectorCTA.content(params: BaseButtonParameters(
                    buttonText: Localization.myBasket.needSomethingElse.localised,
                    buttonPressed: false,
                    onButtonAction: { params.actions.openItemSelector(nil) })
                )
                if myProductsViewModel.entries.count < 1 {
                    baseViews.empty.content(params: BaseEmptyParameters(
                        onOptionalCallback: params.actions.onNoResultsRedirect))
                }
                LazyVGrid(
                    columns: Array(
                        repeating: GridItem(.flexible()),
                        count: 1),
                    spacing: 0
                ) {
                    ForEach(myProductsViewModel.entries) { basketEntryViewModel in
                        MyProductsProductCard(
                            productCard: params.productCard,
                            loadingProduct: params.loadingProduct,
                            basketEntryVM: basketEntryViewModel)
                    }
                }
            }
        }
    }
}
