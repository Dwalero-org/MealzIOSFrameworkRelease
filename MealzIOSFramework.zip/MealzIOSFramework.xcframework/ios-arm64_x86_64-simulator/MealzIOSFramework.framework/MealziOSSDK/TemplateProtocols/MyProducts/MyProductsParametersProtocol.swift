//
//  MyProductsParametersProtocol.swift
//  MealzIOSFramework
//
//  Created by Antonin Francois on 11/04/2024.
//  Copyright © 2024 Mealz. All rights reserved.
//

import SwiftUI

/**
 A protocol defining the necessary parameters for the MyProducts Page.
 - productCard:  An implementation of ``MyProductsProductCardProtocol``
 - actions: MyProductsActions
 */
@available(iOS 14, *)
public protocol MyProductsParametersProtocol {
    associatedtype ProductCard: MyProductsProductCardProtocol
    associatedtype LoadingProduct: LoadingProtocol
    associatedtype OpenItemSelectorCallToAction: BaseButtonProtocol
    
    var productCard: ProductCard { get }
    var loadingProduct: LoadingProduct { get }
    var itemSelectorCTA: OpenItemSelectorCallToAction { get }
    var actions: MyProductsActions { get set }
}

public struct MyProductsActions {
    var onNoResultsRedirect: () -> Void
    var openItemSelector: (String?) -> Void
    
    public init(
        onNoResultsRedirect: @escaping () -> Void,
        openItemSelector: @escaping (String?) -> Void
    ) {
        self.onNoResultsRedirect = onNoResultsRedirect
        self.openItemSelector = openItemSelector
    }
}
