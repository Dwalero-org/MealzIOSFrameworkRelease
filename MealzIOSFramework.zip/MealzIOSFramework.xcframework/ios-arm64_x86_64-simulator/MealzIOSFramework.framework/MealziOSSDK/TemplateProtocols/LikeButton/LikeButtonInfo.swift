//
//  LikeButtonInfo.swift
//  
//
//  Created by didi on 27/09/2023.
//

import SwiftUI

@available(iOS 14, *)
public struct LikeButtonInfo {
    /// id of the current Recipe
    public let recipeId: String
    /// Icon to pass if isLiked is true
    public let likedIcon: Image
    /// Icon to pass if isLiked is false
    public let unlikedIcon: Image
    /// size of the icons
    public let iconSize: CGSize
    /// size of the entire button
    public let backgroundSize: CGSize
    /// color of the icon
    public let iconColor: Color?
    /// color of the background
    public let backgroundColor: Color
    /// Shape that the background is
    public let backgroundShape: AnyShape
    
    public init(
        recipeId: String,
        likedIcon: Image = Image.mealzIcon(icon: .heartFilled),
        unlikedIcon: Image = Image.mealzIcon(icon: .heart),
        iconSize: CGSize = CGSize(width: 26.0, height: 26.0),
        backgroundSize: CGSize = CGSize(width: 40.0, height: 40.0),
        iconColor: Color? = nil,
        backgroundColor: Color = Color.mealzColor(.white),
        backgroundShape: AnyShape = AnyShape(Circle())
    ) {
        self.recipeId = recipeId
        self.likedIcon = likedIcon
        self.unlikedIcon = unlikedIcon
        self.iconSize = iconSize
        self.backgroundSize = backgroundSize
        self.iconColor = iconColor
        self.backgroundColor = backgroundColor
        self.backgroundShape = backgroundShape
    }
}

@available(iOS 14, *)
public struct AnyShape: Shape {
    private let _path: (CGRect) -> Path

    public init<S: Shape>(_ wrapped: S) {
        _path = wrapped.path(in:)
    }

    public func path(in rect: CGRect) -> Path {
        _path(rect)
    }
}

