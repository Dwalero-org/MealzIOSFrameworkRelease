//
//  LikeButton.swift
//  
//
//  Created by didi on 27/09/2023.
//

import SwiftUI
import mealzcore

/**
 A view showing the Like Button with functionality to add the associated recipe to the user's Favorites
 
 - likeButtonInfo: LikeButtonInfo -> an implementation of ``LikeButtonInfo`` that includes the recipeId & options to customize the likeButton
 
 */
@available(iOS 14, *)
public struct LikeButton: View {
    private let likeButtonInfo: LikeButtonInfo
    @StateObject var viewModel: LikeButtonVM
    public init(
        likeButtonInfo: LikeButtonInfo
    ) {
        self.likeButtonInfo = likeButtonInfo
        _viewModel = StateObject(wrappedValue: LikeButtonVM(recipeId: likeButtonInfo.recipeId))
    }
    public var body: some View {
        UIStateWrapperView(uiState: viewModel.state?.isLiked) {
            likeButton() // show when loading but don't have functionality
        } emptyView: { /* we never meet empty state */ }
        successView: {
            likeButton().onTapGesture {
                withAnimation { viewModel.instance.toggleLike() }
            }
        }
        .onAppear {
            viewModel.instance.registerListeners()
        }
        .onDisappear {
            viewModel.instance.dispose()
            viewModel.abolishInstance()
        }
    }
    
    func likeButton() -> some View {
        ZStack {
            likeButtonInfo.backgroundShape
                .frame(
                    width: likeButtonInfo.backgroundSize.width,
                    height: likeButtonInfo.backgroundSize.height)
                .foregroundColor(likeButtonInfo.backgroundColor)
            if viewModel.isLiked {
                StyledLikeIcon(
                    icon: likeButtonInfo.likedIcon,
                    iconColor: likeButtonInfo.iconColor,
                    iconSize: likeButtonInfo.iconSize)
            } else {
                StyledLikeIcon(
                    icon: likeButtonInfo.unlikedIcon,
                    iconColor: likeButtonInfo.iconColor,
                    iconSize: likeButtonInfo.iconSize)
            }
        }
    }
    
    struct StyledLikeIcon: View {
        let icon: Image
        let iconColor: Color?
        let iconSize: CGSize
        var body: some View {
            HStack(spacing: 0) {
                if let color = iconColor {
                    icon
                        .renderingMode(.template)
                        .resizable()
                        .foregroundColor(color)
                        .scaledToFill()
                        .frame(
                            width: iconSize.width,
                            height: iconSize.height)
                } else {
                    icon
                        .resizable()
                        .scaledToFill()
                        .frame(
                            width: iconSize.width,
                            height: iconSize.height)
                }
            }
        }
    }
}
