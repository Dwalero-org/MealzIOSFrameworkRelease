//
//  MealsInBasketButton.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Favorites page where users can see the recipes they have liked.
 
 Mandatory Parameters:
 - params:  An implementation of ``MealsInBasketButtonParametersProtocol``, usually the default ``MealsInBasketButtonParameters``
 - onNavigateToMyMeals: () -> Void: This should navigate to the Basket or MyMeals page where the user can see the recipes in their basket
 
 */
@available(iOS 14, *)
public struct MealsInBasketButton<
    MealsInBasketButtonParameters: MealsInBasketButtonParametersProtocol
>: View {
    private let params: MealsInBasketButtonParameters
    /// callback to navigate to the MyMealsPage
    var onNavigateToMyMeals: () -> Void
    @ObservedObject private var mealsInBasketButtonViewModel = MealsInBasketButtonVM()
    
    public init(
        params: MealsInBasketButtonParameters,
        onNavigateToMyMeals: @escaping () -> Void
    ) {
        self.params = params
        self.onNavigateToMyMeals = onNavigateToMyMeals
    }
    
    public var body: some View {
        UIStateWrapperView(
            uiState: mealsInBasketButtonViewModel.state?.recipeCount,
            loadingView: {},
            emptyView: { params.empty.content(params: BaseEmptyParameters())},
            successView: {
                params.success.content(
                    params: MealsInBasketButtonSuccessParameters(
                        mealsCount: mealsInBasketButtonViewModel.mealsCount,
                        onNavigateToMyMeals: onNavigateToMyMeals
                    )
                )
            }
        )
    }
}
