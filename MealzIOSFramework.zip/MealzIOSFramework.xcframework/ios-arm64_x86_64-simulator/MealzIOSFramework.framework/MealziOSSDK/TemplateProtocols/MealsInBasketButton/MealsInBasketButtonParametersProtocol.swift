//
//  MealsInBasketButtonParametersProtocol.swift
//  
//
//  Created by didi on 10/10/2023.
//

import Foundation

/**
 A protocol defining the necessary parameters for the MealsInBasket Button
 
 - success:  An implementation of ``MealsInBasketButtonSuccessProtocol``
 - empty:  An implementation of ``EmptyProtocol``
 
 */
@available(iOS 14, *)
public protocol MealsInBasketButtonParametersProtocol {
    associatedtype Success: MealsInBasketButtonSuccessProtocol
    associatedtype Empty: EmptyProtocol
    
    var success: Success { get }
    var empty: Empty { get }
}
