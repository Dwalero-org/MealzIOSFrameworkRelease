//
//  MealsInBasketButtonSuccessProtocol.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A protocol defining the Meals In Basket Button, that accepts the amount of meals in the Basket
 
 - mealsCount: Int ->  The number of recipes currently in the basket
 - onNavigateToMyMeals: () -> Void -> A closure to naviage to the basket or MyMeals page
 
 */
@available(iOS 14, *)
public protocol MealsInBasketButtonSuccessProtocol {
    associatedtype Content: View
    func content(params: MealsInBasketButtonSuccessParameters) -> Content
}


public struct MealsInBasketButtonSuccessParameters {
    public let mealsCount: Int
    public let onNavigateToMyMeals: () -> Void
    
    public init(mealsCount: Int, onNavigateToMyMeals: @escaping () -> Void) {
        self.mealsCount = mealsCount
        self.onNavigateToMyMeals = onNavigateToMyMeals
    }
}
