//
//  SponsorDetails.swift
//  MiamIOSFramework
//
//  Created by didi on 03/10/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import SwiftUI
import mealzcore

/**
 A view showing the Sponsor Details page where users can get more information on the sponsor
 
 Mandatory Parameters:
 - params:  An implementation of ``BaseProtocols``, usually the default ``SponsorDetailsParameters``
 - sponsor: Sponsor -> The current sponsor & content being shown, ex Menguy's 
 
 */
@available(iOS 14, *)
public struct SponsorDetails<
    BaseViews: BaseViewsProtocol
>: View {
    private let baseViews: BaseViews
    public let sponsor: Sponsor
    @StateObject var sponsorViewModel = SponsorDetailsVM()
    
    public init(
        baseViews: BaseViews,
        sponsor: Sponsor
    ) {
        self.baseViews = baseViews
        self.sponsor = sponsor
    }
    
    public var body: some View {
        ZStack {
            baseViews.background.content(params: BaseBackgroundParameters())
            UIStateWrapperView(uiState: sponsorViewModel.state?.sponsorBlocks) {
                baseViews.loading.content(params: BaseLoadingParameters())
            }
            emptyView: { baseViews.empty.content(params: BaseEmptyParameters()) }
            successView: { successContent() }
        }
        .onAppear {
            Task {
                sponsorViewModel.fetchSponsorBlockByIds(sponsor: sponsor)
            }
            sponsorViewModel.registerListeners()
        }
        .onDisappear(perform: { sponsorViewModel.dispose()})
    }
    
    func successContent() -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0.0) {
                ForEach(sponsorViewModel.sponsorBlocks, id: \.id) { section in
                    switch section.blockType {
                    case .title, .smallTitle:
                        if let title = section.attributes?.content {
                            SponsorTitleSection(title: title)
                        }
                    case .picture, .smallPicture:
                        if let picture = section.attributes?.pictureUrl {
                            SponsorImageSection(pictureURL: picture)
                                .frame(height: 256)
                        }
                    case .text, .smallText:
                        if let text = section.attributes?.content {
                            SponsorTextSection(text: text)
                        }
                    case .imageAndText:
                        if let pictureURL = section.attributes?.pictureUrl, let text = section.attributes?.content {
                            SponsorTextImageSection(
                                text: text,
                                pictureURL: pictureURL,
                                textImageArrangement: .textRightImageLeft
                            )
                        }
                    case .textAndImage:
                        if let pictureURL = section.attributes?.pictureUrl, let text = section.attributes?.content {
                            SponsorTextImageSection(
                                text: text,
                                pictureURL: pictureURL,
                                textImageArrangement: .textLeftImageRight
                            )
                        }
                    case .imageWithText:
                        if let pictureURL = section.attributes?.pictureUrl, let text = section.attributes?.content {
                            SponsorTextImageSection(
                                text: text,
                                pictureURL: pictureURL,
                                textImageArrangement: .textOverlappingImage
                            )
                        }
                    case .video:
                        if let videoURL = section.attributes?.videoUrl {
                            SponsorVideoSection(videoURL: videoURL)
                        }
                    default:
                        baseViews.empty.content(params: BaseEmptyParameters())
                    }
                }
            }
            .padding(Dimension.sharedInstance.mlPadding)
        }
    }
}
