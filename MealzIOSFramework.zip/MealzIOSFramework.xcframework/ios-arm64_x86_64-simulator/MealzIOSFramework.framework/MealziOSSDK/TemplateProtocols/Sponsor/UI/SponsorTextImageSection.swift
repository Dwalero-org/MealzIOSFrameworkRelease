//
//  SponsorTextImageSection.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

public enum SponsorTextImageArrangement {
    case textLeftImageRight
    case textRightImageLeft
    case textOverlappingImage
}

@available(iOS 14, *)
struct SponsorTextImageSection: View {
    let text: String
    let pictureURL: String
    let textImageArrangement: SponsorTextImageArrangement
    var body: some View {
        if textImageArrangement == .textOverlappingImage {
            ZStack {
                SponsorImageSection(pictureURL: pictureURL)
                SponsorTextSection(text: text)
            }
        } else {
            VStack {
                if textImageArrangement == .textLeftImageRight {
                    SponsorTextSection(text: text)
                    SponsorImageSection(pictureURL: pictureURL)
                } else {
                    SponsorImageSection(pictureURL: pictureURL)
                    SponsorTextSection(text: text)
                }
            }
        }
    }
}

@available(iOS 14, *)
struct SponsorTextAndImageSection_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 10) {
            Text("textLeftImageRight")
            SponsorTextImageSection(
                text: "Test",
                pictureURL: "URL",
                textImageArrangement: .textLeftImageRight
            )
            Text("textOverlappingImage")
            SponsorTextImageSection(
                text: "Test",
                pictureURL: "URL",
                textImageArrangement: .textOverlappingImage
            )
            Text("textRightImageLeft")
            SponsorTextImageSection(
                text: "Test",
                pictureURL: "URL",
                textImageArrangement: .textRightImageLeft
            )
        }
    }
}
