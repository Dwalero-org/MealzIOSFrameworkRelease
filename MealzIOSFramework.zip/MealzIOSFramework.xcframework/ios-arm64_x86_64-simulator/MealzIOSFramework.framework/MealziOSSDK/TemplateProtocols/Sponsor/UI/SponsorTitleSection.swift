//
//  SponsorTitleSection.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

@available(iOS 14, *)
struct SponsorTitleSection: View {
    let title: String
    var body: some View {
        Text(title)
            .miamFontStyle(style: MiamFontStyleProvider.sharedInstance.titleBigStyle)
            .foregroundColor(Color.mealzColor(.primary))
    }
}

@available(iOS 14, *)
struct SponsorTitleSection_Previews: PreviewProvider {
    static var previews: some View {
        SponsorTitleSection(title: "Test")
    }
}
