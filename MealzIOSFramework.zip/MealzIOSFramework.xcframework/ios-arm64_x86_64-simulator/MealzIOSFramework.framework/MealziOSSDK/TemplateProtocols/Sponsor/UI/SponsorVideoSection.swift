//
//  SponsorVideoSection.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI
import AVKit

@available(iOS 14, *)
struct SponsorVideoSection: View {
    let videoURL: String
    var body: some View {
        if let url = URL(string: videoURL) {
            VideoPlayer(
                player: AVPlayer(url: url)
            ).frame(height: 240)
        }
    }
}

@available(iOS 14, *)
struct SponsorVideoSection_Previews: PreviewProvider {
    static var previews: some View {
        SponsorVideoSection(videoURL: "")
    }
}
