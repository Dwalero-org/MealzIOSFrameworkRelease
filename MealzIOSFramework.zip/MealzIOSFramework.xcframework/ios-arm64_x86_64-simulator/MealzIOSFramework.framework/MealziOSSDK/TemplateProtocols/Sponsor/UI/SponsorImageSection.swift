//
//  SponsorImageSection.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

@available(iOS 14, *)
struct SponsorImageSection: View {
    let pictureURL: String
    var body: some View {
        if let url = URL(string: pictureURL) {
            if #available(iOS 15, *) {
                AsyncImage(url: url) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                }
                .frame(minWidth: 0, maxWidth: .infinity)
                .frame(height: 246.0)
                .clipped()
            }
        }
    }
}

@available(iOS 14, *)
struct SponsorImageSection_Previews: PreviewProvider {
    static var previews: some View {
        SponsorImageSection(pictureURL: "")
    }
}
