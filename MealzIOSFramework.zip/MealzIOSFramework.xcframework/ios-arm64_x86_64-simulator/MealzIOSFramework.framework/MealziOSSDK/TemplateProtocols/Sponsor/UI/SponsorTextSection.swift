//
//  SponsorTextSection.swift
//  
//
//  Created by didi on 13/10/2023.
//

import SwiftUI

@available(iOS 14, *)
struct SponsorTextSection: View {
    let text: String
    var body: some View {
        Text(text)
    }
}

@available(iOS 14, *)
struct SponsorTextSection_Previews: PreviewProvider {
    static var previews: some View {
        SponsorTextSection(text: "Test")
    }
}
