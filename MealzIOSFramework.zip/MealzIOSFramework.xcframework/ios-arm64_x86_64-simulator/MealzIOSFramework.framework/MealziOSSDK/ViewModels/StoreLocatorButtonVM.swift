//
//  StoreLocatorButtonVM.swift
//  MealzIOSFramework
//
//  Created by miam x didi on 29/04/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class StoreLocatorButtonVM: StoreLocatorButtonViewModel, ObservableObject {
    @Published var componentState: StoreLocatorButtonState? = nil
    @Published var currentPOSName: String?
    override public init() {
        super.init()
        self.collect(flow: self.state) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? StoreLocatorButtonState
            strongSelf.componentState = state
            strongSelf.currentPOSName = state?.posName
        }
    }
}
