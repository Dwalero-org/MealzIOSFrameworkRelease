//
//  PreferencesVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 02/11/2022.
//  Copyright © 2022 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class PreferencesVM: ObservableObject {
    static let sharedInstance = PreferencesVM()
    private let preferencesViewModelInstance = PreferencesViewModelInstance.shared.instance
    @Published public var state: PreferencesContractState?
    @Published public var guests: Int = 4
    public var diets: [CheckableTag] = []
    public var equipments: [CheckableTag] = []
    public var ingredients: [CheckableTag] = []
    public init() {
        self.preferencesViewModelInstance.collect(flow: self.preferencesViewModelInstance.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            guard let state = data as? PreferencesContractState else {
                return
            }
            strongSelf.state = state
            switch state.basicState {
            case _ as BasicUiStateSuccess<KotlinBoolean>:
                strongSelf.diets = state.diets
                strongSelf.ingredients = state.ingredients
                strongSelf.equipments = state.equipments
                strongSelf.guests = Int(state.guests ?? 4)
            default:
                break
            }
        }
    }
    
    public func addTag(_ tag: Tag) {
        preferencesViewModelInstance.addIngredientPreference(tag: tag)
    }
    
    public func updateGuestsNumber(_ numberOfGuests: Int) {
        preferencesViewModelInstance.changeGlobalGuest(numberOfGuest: Int32(numberOfGuests))
    }
    
    public func togglePreference(_ preference: CheckableTag) {
        preferencesViewModelInstance.togglePreference(tagIdToToggle: preference.tag.id)
    }
    public func togglePreferenceWithId(_ tagId: String) {
        preferencesViewModelInstance.togglePreference(tagIdToToggle: tagId)
    }
    
    public func resetPreferences() {
        preferencesViewModelInstance.resetPreferences()
    }

    public func applyPreferences() {
        preferencesViewModelInstance.applyPreferences()
    }
}
