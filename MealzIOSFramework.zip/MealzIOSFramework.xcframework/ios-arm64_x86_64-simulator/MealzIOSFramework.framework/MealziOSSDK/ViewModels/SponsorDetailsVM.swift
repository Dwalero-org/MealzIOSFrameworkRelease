//
//  SponsorDetailVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 20/02/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
class SponsorDetailsVM: SponsorDetailsViewModel, ObservableObject {
    @Published var state: SponsorDetailsContractState?
    @Published var sponsorBlocks: [SponsorBlock] = []
    override init() {
        super.init()
        collect(flow: self.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? SponsorDetailsContractState
            switch strongSelf.state?.sponsorBlocks {
            case let success as BasicUiStateSuccess<NSArray>:
                if let blocks = success.data as? [SponsorBlock] {
                    strongSelf.sponsorBlocks = blocks.sorted(by: {
                        guard let aPosition = $0.attributes?.position, let bPosition = $1.attributes?.position else {
                            return false
                        }
                        return aPosition < bPosition
                    })
                }
            default:
                ()
            }
        }
    }
}
