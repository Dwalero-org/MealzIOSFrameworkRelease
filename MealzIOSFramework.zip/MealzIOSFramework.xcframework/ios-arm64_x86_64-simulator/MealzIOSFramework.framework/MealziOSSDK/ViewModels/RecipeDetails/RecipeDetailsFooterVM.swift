//
//  RecipeDetailsFooterVM.swift
//  
//
//  Created by Diarmuid McGonagle on 10/01/2024.
//

import Foundation
import mealzcore

@available(iOS 14, *)
public class RecipeDetailsFooterVM: ObservableObject {
    let instance: DynamicRecipeDetailFooterViewModel
    
    @Published public var state: DynamicRecipeDetailFooterContractState?
    @Published public var price: Double? = nil
    @Published public var pricePerGuest: Double? = nil
    @Published public var priceForRemainingProduct: Double? = nil
    @Published public var priceStatus: ComponentUiState?
    @Published public var ingredientStatus: IngredientStatus? = nil
    @Published public var isAddingAllIngredients: Bool = false
    
    init(instance: DynamicRecipeDetailFooterViewModel) {
        self.instance = instance
        
        instance.collect(flow: instance.uiState) {[weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? DynamicRecipeDetailFooterContractState
            strongSelf.ingredientStatus = strongSelf.state?.ingredientsStatus
            strongSelf.priceStatus = strongSelf.state?.priceStatus
        }
        instance.collect(flow: instance.priceOfProductsInBasket) {[weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.price = Double(truncating: data as? KotlinDouble ?? 0)
        }
        instance.collect(flow: instance.priceProductsInBasketPerGuest) {[weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.pricePerGuest = Double(truncating: data as? KotlinDouble ?? 0)
        }
        instance.collect(flow: instance.priceOfRemainingProducts) {[weak self] data in
                   guard let strongSelf = self else { return }
                   strongSelf.priceForRemainingProduct = Double(truncating: data as? KotlinDouble ?? 0)
               }
        instance.collect(flow: instance.isAddingRemainingIngredients) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.isAddingAllIngredients = Bool(truncating: data as? KotlinBoolean ?? false)
        }
    }
    
    public func onContinueShopping() {
        instance.setEvent(event: DynamicRecipeDetailFooterContractEvent.OnTapContinueShopping())
    }
}
