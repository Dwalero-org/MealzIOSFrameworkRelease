//
//  DynamicRecipeDetailsVM.swift
//  
//
//  Created by Diarmuid McGonagle on 11/01/2024.
//

import SwiftUI
import mealzcore

@available(iOS 14, *)
public class DynamicRecipeDetailsVM: DynamicRecipeDetailViewModel, ObservableObject {
    @Published public var recipe: Recipe?
    @Published public var ingredients: [Ingredient]?
    @Published public var state: DynamicRecipeDetailContractState?
    @Published public var isInCart: Bool = false
    @Published public var guest: Int = 4
    @Published public var guestUpdating: Bool = false
    
    @Published public var canBeAddedProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var oftenDeletedProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var unavailableProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var footer : RecipeDetailsFooterVM?
    
    public override init(
        continueShopping: @escaping () -> Void,
        changeProduct: @escaping (String) -> Void
    ) {
        super.init(continueShopping: continueShopping, changeProduct: changeProduct)
        
        collect(flow: uiState, collect: { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? DynamicRecipeDetailContractState
            strongSelf.state = state
            
            switch state?.recipe {
            case let success as BasicUiStateSuccess<Recipe>:
                if let successRecipe = success.data {
                    strongSelf.recipe = successRecipe
                }
                strongSelf.ingredients = strongSelf.recipe?.relationships?.ingredients?.data
                strongSelf.footer = RecipeDetailsFooterVM(instance: strongSelf.dynamicRecipeDetailFooterViewModel)
                strongSelf.objectWillChange.send()
            default:
                break
            }
        })
        collect(flow: canBeAddedProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.canBeAddedProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        collect(flow: oftenDeletedProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.oftenDeletedProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        collect(flow: unavailableProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.unavailableProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        collect(flow: recipeGuests) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.guest = Int(truncating: data as? KotlinInt ?? 4)
        }
    }
    public var isLikeEnabled: Bool {
        true
        //return state?.likeIsEnable ?? false
    }
}
