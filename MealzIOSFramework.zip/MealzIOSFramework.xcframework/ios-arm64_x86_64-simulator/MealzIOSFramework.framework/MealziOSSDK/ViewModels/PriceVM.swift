//
//  PriceVM.swift
//  MiamIOSFramework
//
//  Created by Miam on 02/05/2022.
//

import mealzcore
import Combine

@available(iOS 14, *)
public class PriceVM: RecipePricingViewModel, ObservableObject {
    @Published var pricing: Pricing?
    @Published var price: Double = 0.0
    @Published public var state: PricingContractState?
    public override init() {
        super.init()
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? PricingContractState
            switch strongSelf.state?.price {
            case let success as BasicUiStateSuccess<Pricing>:
                strongSelf.pricing = success.data
            default:
                break
            }
        }
    }
}
