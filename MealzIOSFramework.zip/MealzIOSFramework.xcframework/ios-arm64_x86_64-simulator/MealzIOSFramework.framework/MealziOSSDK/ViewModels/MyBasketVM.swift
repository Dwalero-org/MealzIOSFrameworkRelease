//
//  MyBasketVM.swift
//
//
//  Created by Diarmuid McGonagle on 08/04/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MyBasketVM: MyBasketViewModel, ObservableObject {
    @Published public var myBasketStatus: ComponentUiState = ComponentUiState.idle
    @Published public var state: MyBasketContractState?
    @Published public var productCount: Int = 0
    @Published public var totalPrice: Double = 0.0
    @Published public var recipeCount: Int = 0

    public override init() {
        super.init()
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? MyBasketContractState 
            strongSelf.state = state
            strongSelf.recipeCount = Int(state?.recipeCount ?? 0)
            strongSelf.totalPrice = state?.totalPrice ?? 0.0
            strongSelf.productCount = Int(state?.productCount ?? 0)
            strongSelf.myBasketStatus = state?.basketStatus as? ComponentUiState ?? ComponentUiState.idle
        }
    }
}
