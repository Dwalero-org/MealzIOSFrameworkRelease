//
//  MealsInBasketButtonVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 03/11/2022.
//  Copyright © 2022 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealsInBasketButtonVM: MyMealButtonViewModel, ObservableObject {
    @Published public var state: MyMealButtonContractState?
    public var mealsCount: Int = 0
    public override init() {
        super.init()
        self.collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            guard let state = data as? MyMealButtonContractState else {
                return
            }
            strongSelf.state = state
            switch state.recipeCount {
            case let success as BasicUiStateSuccess<KotlinInt>:
                strongSelf.mealsCount = success.data?.intValue ?? 0
            default:
                break
            }
        }
    }
}
