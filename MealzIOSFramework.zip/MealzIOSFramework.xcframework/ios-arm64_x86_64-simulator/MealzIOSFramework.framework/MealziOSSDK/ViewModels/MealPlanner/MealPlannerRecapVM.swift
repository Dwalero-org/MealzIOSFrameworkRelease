//
//  File.swift
//  
//
//  Created by didi on 6/26/23.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealPlannerRecapVM: MealPlannerRecapViewModel, ObservableObject {
    @Published public var numberOfMeals: Int
    @Published public var totalPrice: Double
    @Published public var state: MealPlannerRecapContractState?
    public override init() {
        self.numberOfMeals = 4
        self.totalPrice = 12.0
        super.init()
        self.collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            guard let state = data as? MealPlannerRecapContractState else {
                return
            }
            strongSelf.state = state
            strongSelf.numberOfMeals = Int(state.numberOfMeals)
            strongSelf.totalPrice = Double(state.totalPrice)
        }
    }
}
