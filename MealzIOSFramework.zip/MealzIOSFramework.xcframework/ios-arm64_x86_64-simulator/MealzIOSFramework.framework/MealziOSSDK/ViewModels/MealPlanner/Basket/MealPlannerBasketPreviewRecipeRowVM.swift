//
//  MealPlannerBasketPreviewRecipeRowVM.swift
//
//
//  Created by Diarmuid McGonagle on 08/01/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealPlannerBasketPreviewRecipeRowVM: ObservableObject {
    let instance: MealPlannerBasketPreviewRecipeRowViewModel
    @Published public var state: DynamicRecipeDetailContractState?
    var recipe: Recipe?
    @Published public var recipeRowStateS: RecipeRowState? = nil
    @Published var guests: Int = 4
    @Published var guestCountUpdating: Bool = false
    @Published public var foundProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var deletedProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var oftenDeletedProducts: [BasketEntryInRecipeViewModel] = []
    @Published public var unavailableProducts: [BasketEntryInRecipeViewModel] = []

    public init(instance: MealPlannerBasketPreviewRecipeRowViewModel) {
        self.instance = instance
        instance.collect(flow: instance.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let recipeState = data as? DynamicRecipeDetailContractState
            strongSelf.state = recipeState
            
            switch recipeState?.recipe {
            case let success as BasicUiStateSuccess<Recipe>:
                strongSelf.recipe = success.data
            default:
                break
            }
        }
        instance.collect(flow: instance.recipeRowState) { [weak self] data in
            guard let strongSelf = self else { return }
            let recipeRowStateS = data as? RecipeRowState
            strongSelf.recipeRowStateS = recipeRowStateS
        }
        instance.collect(flow: instance.foundProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.foundProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        instance.collect(flow: instance.deletedProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.deletedProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        instance.collect(flow: instance.oftenDeletedProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.oftenDeletedProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        instance.collect(flow: instance.unavailableProduct) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.unavailableProducts = data as? [BasketEntryInRecipeViewModel] ?? []
        }
        instance.collect(flow: instance.recipeGuests) { [weak self] data in
            guard let strongSelf = self else { return }
            let guests = data as? KotlinInt
            strongSelf.guests = Int(truncating: guests ?? 4)
        }
        instance.collect(flow: instance.guestIsUpdating) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.guestCountUpdating = Bool(truncating: data as? KotlinBoolean ?? false)
        }
    }
}

extension MealPlannerBasketPreviewRecipeRowViewModel: Identifiable {}
