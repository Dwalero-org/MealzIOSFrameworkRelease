//
//  MealPlannerBasketPreviewVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 20/06/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealPlannerBasketPreviewVM: MealPlannerBasketPreviewViewModel, ObservableObject {
    @Published public var state: MealPlannerBasketPreviewContractState?
    @Published public var recipesVMs: [MealPlannerBasketPreviewRecipeRowViewModel] = []
    @Published public var totalPriceS: Double = 0.0
    @Published public var productCountS: Int = 0
    @Published public var isLoading: Bool = false

    public override init() {
        super.init()
        self.collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? MealPlannerBasketPreviewContractState
        }
        self.collect(flow: recipesDetailsVM) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.recipesVMs = data as? [MealPlannerBasketPreviewRecipeRowViewModel] ?? []
        }
        self.collect(flow: totalPrice) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.totalPriceS = Double(truncating: data as? KotlinDouble ?? 0.0)
        }
        self.collect(flow: productCount) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.productCountS = Int(truncating: data as? KotlinInt ?? 0)
        }
        self.collect(flow: isProcessing) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.isLoading = Bool(truncating: data as? KotlinBoolean ?? false)
        }
    }
}
