//
//  MealPlannerMeals.swift
//  MiamIOSFramework
//
//  Created by Miam on 17/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealPlannerMealsVM: MealPlannerMealsViewModel, ObservableObject {
    @Published public var meals: [MealPlannerRecipe?] = []
    @Published public var totalPrice: Double = 0.0
    @Published public var state: MealPlannerMealsContractState?
    override public init() {
        super.init()
        self.collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? MealPlannerMealsContractState
            strongSelf.state = state
            switch state?.meals {
            case let success as BasicUiStateSuccess<NSArray>:
                if let meals = success.data as? [MealPlannerRecipe?] {
                    strongSelf.meals = meals
                    strongSelf.totalPrice = state?.totalPrice ?? 0.0
                }
            default:
                ()
            }
        }
    }

    public func removeRecipe(_ withId: String) {
        guard let index = self.meals.firstIndex(where: { $0?.recipeId == withId }) else {
            return
        }
        removeRecipe(recipeIndex: Int32(index))
    }
}
