//
//  MealPlannerReplaceRecipeViewModel.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 13, *)
public class MealPlannerReplaceRecipeViewModel: MealPlannerReplaceRecipePageViewModel, ObservableObject {
    @Published public var state: RecipesPageContractState?
    @Published public var recipes: [Recipe] = []
    public override init() {
        super.init()
        self.collect(flow: self.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? RecipesPageContractState
            switch strongSelf.state?.recipes {
            case let success as BasicUiStateSuccess<NSArray>:
                if let recipes = success.data as? [Recipe] {
                    strongSelf.recipes = recipes
                }
            default:
                ()
            }
        }
    }
}
