//
//  MealPlannerFormViewModel.swift
//  MiamIOSFramework
//
//  Created by Miam on 17/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MealPlannerFormVM: MealPlannerFormViewModel, ObservableObject {
    @Published public var mealPlannerCriteria: MealPlannerCriteria
    @Published public var state: MealPlannerFormContractState?
    // TODO: remove this later & have this functionality in the core
    @Published public var errorAppeared: Bool
    public override init() {
        self.mealPlannerCriteria = MealPlannerCriteria(
            availableBudget: 0.0,
            numberOfGuests: 0,
            numberOfMeals: 0
        )
        self.errorAppeared = false
        super.init()
        self.collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? MealPlannerFormContractState
            strongSelf.state = state
            // Handle error
            if state?.uiState == .error {
               strongSelf.errorAppeared = true
            }
            guard let state else { return }
            strongSelf.mealPlannerCriteria = MealPlannerCriteria(
                availableBudget: Double(state.budget),
                numberOfGuests: Int(state.numberOfGuests),
                numberOfMeals: Int(state.numberOfMeals),
                maxRecipesForBudget: Int(state.recipeMaxCount)
            )
            
        }
    }
}
