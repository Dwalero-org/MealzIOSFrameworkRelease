//
//  BasketPreviewVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 06/06/2022.
//

import Foundation
import Combine
import mealzcore

@available(iOS 14, *)
public class BasketPreviewVM: BasketPreviewViewModel, ObservableObject {
    private let currencyCode = Localization.price.currency.localised
    @Published public var basketPreviewInfo: BasketPreviewInfo?
    @Published public var state: BasketPreviewContractState?
    // this is separated from state because state is optional -> can be null
    // when i declare it locally I can set the default to null, there are no
    // side effects & unexpected behavior
    @Published public var isReloading: Bool

    private lazy var numberFormatter: NumberFormatter = {
        let numberFormatter = NumberFormatter()
        numberFormatter.currencyCode = currencyCode
        numberFormatter.numberStyle = .currency
        numberFormatter.maximumFractionDigits = 2
        return numberFormatter
    }()

    public override init(recipeId: String) {
        self.isReloading = false
        super.init(recipeId: recipeId)
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? BasketPreviewContractState
            strongSelf.state = state
            strongSelf.isReloading = state?.isReloading ?? false
            switch state?.recipeInfo {
            case let success as BasicUiStateSuccess<BasketPreviewInfo>:
                strongSelf.basketPreviewInfo = success.data
            default:
                break
            }
        }
    }

    public var numberOfGuests: Int {
        return Int(state?.recipeGuest ?? 4)
    }
    
    public var deletingRecipe: Bool {
        return Bool(state?.isDeletingRecipe ?? false)
    }

    public var price: Double {
        return Double(state?.recipePrice ?? 0)
    }
}
