//
//  File.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 23/09/2022.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class FavoritesVM: FavoritePageViewModel, ObservableObject {
    var favorites: [Recipe] = []
    @Published public var state: FavoritePageContractState?
    public override init() {
        super.init()
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? FavoritePageContractState
            switch strongSelf.state?.favoritesRecipes {
            case let success as BasicUiStateSuccess<NSArray>:
                if let results = success.data as? [Recipe] {
                    strongSelf.favorites = results
                }
                break
            default:
                break
            }
        }
    }
}
