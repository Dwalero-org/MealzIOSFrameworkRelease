//
//  RecipePageVM.swift
//  MiamIOSFramework
//
//  Created by didi on 28/09/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class RecipePageVM: RecipesPageViewModel, ObservableObject {
    @Published public var state: RecipesPageContractState?
    @Published public var recipes: [Recipe] = []
    @Published public var isFetchingNewPage: Bool = false
    
    public init(
        filterInstance: FilterInstance,
        categoriesId: String? = nil
    ) {
        if let categoriesId {
            filterInstance.viewModel.setCat(catId: categoriesId)
        }
        super.init()
        self.collect(flow: self.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? RecipesPageContractState
            strongSelf.state = state
            strongSelf.isFetchingNewPage = state?.isFetchingNewPage ?? false
            switch state?.recipes {
            case let success as BasicUiStateSuccess<NSArray>:
                if let recipes = success.data as? [Recipe] {
                    strongSelf.recipes = recipes
                }
            default:
                ()
            }
        }
    }
}
