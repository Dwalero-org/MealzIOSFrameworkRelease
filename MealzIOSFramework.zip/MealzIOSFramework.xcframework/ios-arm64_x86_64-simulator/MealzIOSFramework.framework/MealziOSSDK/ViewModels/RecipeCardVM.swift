//
//  RecipeCardVM.swift
//  MiamIOSFramework
//
//  Created by miam on 17/02/2022.
//

import mealzcore
import Combine

@available(iOS 14, *)
public class RecipeCardVM: RecipeViewModel, ObservableObject {
    @Published public var recipe: Recipe?
    @Published public var ingredients: [Ingredient]?
    @Published public var state: RecipeContractState?
    @Published public var isInCart: Bool = false
    @Published public var guestUpdating: Bool = false
    @Published public var numberOfGuests: Int?
    
    public var sortedSteps: [RecipeStep] {
        guard let recipe = recipe else {
            return []
        }
        return recipe.sortedStep
    }
    
    public override init() {
            super.init()
        collect(flow: uiState, collect: { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? RecipeContractState
            strongSelf.state = state
            strongSelf.isInCart = state?.isInCart ?? false
            strongSelf.ingredients = state?.recipe?.relationships?.ingredients?.data
            switch state?.recipeState {
            case let success as BasicUiStateSuccess<Recipe>:
                if let recipe = success.data {
                    strongSelf.recipe = recipe
                }
                strongSelf.objectWillChange.send()
            default:
                break
            }
        })
        collect(flow: guestsInBasket, collect: { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.numberOfGuests = Int(data as? Int32 ?? 4)
        })
    }
    public var isLikeEnabled: Bool {
        return state?.likeIsEnable ?? false
    }
    
    func goToDetails() {
        self.setEvent(event: RecipeContractEvent.GoToDetail())
    }
}
