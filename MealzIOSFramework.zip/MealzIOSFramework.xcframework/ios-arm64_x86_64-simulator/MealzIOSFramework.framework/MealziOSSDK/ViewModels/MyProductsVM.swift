//
//  MyProductsVM.swift
//  MealzIOSFramework
//
//  Created by Diarmuid McGonagle on 12/04/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MyProductsVM: MyProductsViewModel, ObservableObject {
    @Published public var entries: [BasketEntryViewModel] = []
    @Published public var state: MyProductsContractState?
    
    public override init(openItemSelector: @escaping (String?) -> Void) {
        super.init(openItemSelector: openItemSelector)
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? MyProductsContractState
            strongSelf.state = state
            switch state?.entries {
            case let success as BasicUiStateSuccess<NSArray>: // Must use an object, thus NSArray
                if let entries = success.data as? [BasketEntryViewModel] {
                    strongSelf.entries = entries
                }
            default:
                break
            }
        }
    }
}
