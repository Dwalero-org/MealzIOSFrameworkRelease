//
//  MyMealsVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 16/06/2022.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class MyMealVM: MyMealViewModel, ObservableObject {
    @Published public var recipes: [Recipe] = []
    @Published public var state: MyMealContractState?

    public override init() {
        super.init()
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? MyMealContractState
            strongSelf.state = state
            switch state?.recipes {
            case let success as BasicUiStateSuccess<NSArray>: // Must use an object, thus NSArray
                if let recipes = success.data as? [Recipe] {
                    strongSelf.recipes = recipes
                }
            default:
                break
            }
        }
    }
}
