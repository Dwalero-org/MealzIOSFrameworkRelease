//
//  BasketEntryStandaloneVM.swift
//  
//
//  Created by Diarmuid McGonagle on 12/04/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class BasketEntryStandaloneVM: BasketEntryVM {
    
    public init(instance: BasketEntryStandaloneViewModel) {
        super.init(instance: instance)
    }
}

@available(iOS 14, *)
extension BasketEntryStandaloneVM: Identifiable {}
