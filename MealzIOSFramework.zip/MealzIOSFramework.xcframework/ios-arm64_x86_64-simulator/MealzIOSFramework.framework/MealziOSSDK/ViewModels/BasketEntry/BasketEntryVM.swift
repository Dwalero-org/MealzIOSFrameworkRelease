//
//  BasketEntryVM.swift
//
//
//  Created by Diarmuid McGonagle on 12/04/2024.
//


import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class BasketEntryVM: ObservableObject {
    let instance: BasketEntryViewModel
    @Published public var state: BasketEntryContractState?
    @Published var entry: BasketEntry?
    @Published var productQuantity: Int = 0
    
    public init(instance: BasketEntryViewModel) {
        self.instance = instance
        instance.collect(flow: instance.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let localState = data as? BasketEntryContractState
            strongSelf.state = data as? BasketEntryContractState
            strongSelf.entry = localState?.basketEntry
        }
        instance.collect(flow: instance.productQtySubject) { [weak self] data in
            guard let strongSelf = self else { return }
            let productQtySubjectS = data as? KotlinInt
            strongSelf.productQuantity = Int(truncating: productQtySubjectS ?? 1)
        }
    }

    public func addProduct() {
        instance.setEvent(event: BasketEntryContractEvent.AddBasketEntry())
    }
    
    public func updateQuantity(quantity: Int) {
        instance.setEvent(event: BasketEntryContractEvent.UpdateBasketEntryQty(quantity: Int32(quantity)))
    }
    public func replaceProduct() {
        instance.setEvent(event: BasketEntryContractEvent.ReplaceBasketEntry())
    }
}

extension BasketEntryViewModel: Identifiable {}
