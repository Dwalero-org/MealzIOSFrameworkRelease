//
//  BasketEntryInRecipeVM.swift
//
//
//  Created by Diarmuid McGonagle on 12/04/2024.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class BasketEntryInRecipeVM: BasketEntryVM {
    @Published var ingredient: Ingredient
    private let inRecipeInstance: BasketEntryInRecipeViewModel
    
    public init(instance: BasketEntryInRecipeViewModel) {
        self.inRecipeInstance = instance
        self.ingredient = instance.ingredient
        super.init(instance: instance)
    }
    
    public func ignoreProduct() {
        inRecipeInstance.ignoreBasketEntryInRecipe()
    }
}

extension BasketEntryInRecipeViewModel: Identifiable {}
