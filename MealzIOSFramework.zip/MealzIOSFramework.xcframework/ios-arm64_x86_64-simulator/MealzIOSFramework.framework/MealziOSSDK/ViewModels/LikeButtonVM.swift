//
//  LikeButtonVM.swift
//  MiamIOSFramework
//
//  Created by Miam on 17/11/2022.
//  Copyright © 2022 Miam. All rights reserved.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class LikeButtonVM: ObservableObject {
    public let instance: LikeButtonViewModel
    @Published public var isLiked: Bool = false
    @Published public var state: RecipeLikeContractState?
    private let recipeId: String
    public init(recipeId: String) {
        self.recipeId = recipeId
        self.instance = LikeButtonViewModelFactory().instantiate(key: recipeId)
        instance.collect(flow: instance.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? RecipeLikeContractState
            switch strongSelf.state?.isLiked {
            case let success as BasicUiStateSuccess<KotlinBoolean>:
                if let liked = success.data {
                    strongSelf.isLiked = liked.boolValue
                }
            default:
                break
            }
        }
    }
    
    public func abolishInstance() {
        LikeButtonViewModelFactory().abolishInstance(key: recipeId)
    }
}
