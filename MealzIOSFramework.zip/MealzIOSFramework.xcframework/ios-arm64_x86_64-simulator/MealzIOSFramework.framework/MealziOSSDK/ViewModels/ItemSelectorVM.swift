//
//  ItemSelectorVM.swift
//  MiamIOSFramework
//
//  Created by Miam on 08/06/2022.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class ItemSelectorVM: ItemSelectorViewModel, ObservableObject{
    var localState: ItemSelectorContractState?
    @Published var items: [Item] = []
    @Published var searchString: String?
    var selectedItem: Item? = nil
    var ingredientId: String = ""
    var ingredientName: String = ""
    var ingredientQuantity: Int = 0
    var ingredientUnit: String = ""
    var guestCount: Int = 4
    var defaultRecipeGuest: Int = 4
    //
    public override init() {
        super.init()
        collect(flow: uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.localState = data as? ItemSelectorContractState
            strongSelf.selectedItem = strongSelf.currentState.selectedItem
            strongSelf.ingredientId = strongSelf.currentState.ingredientId
            strongSelf.ingredientName = strongSelf.currentState.ingredientName
            strongSelf.ingredientQuantity = Int(strongSelf.currentState.ingredientQuantity)
            strongSelf.ingredientUnit = strongSelf.currentState.ingredientUnit
            strongSelf.guestCount = Int(strongSelf.currentState.guestCount)
            strongSelf.defaultRecipeGuest = Int(strongSelf.currentState.defaultRecipeGuest)
            switch strongSelf.localState?.items {
            case let success as BasicUiStateSuccess<NSArray>:
                if let items = success.data as? [Item] {
                    strongSelf.items = items
                }
                break;
            default:
                break;
            }
            strongSelf.objectWillChange.send()
        }
    }
    
    func searchFromText(text: String) {
        self.setEvent(event: ItemSelectorContractEvent.Search(searchString: text))
    }
    
    func setIngredientId(id: String) {
        self.setEvent(event: ItemSelectorContractEvent.InitWithIngredientId(ingredientId:id))
    }
    
    func setStandalone() {
        self.setEvent(event: ItemSelectorContractEvent.InitStandalone())
    }
    
    func setBasketEntryId(basketEntryId: String) {
        self.setEvent(event: ItemSelectorContractEvent.InitWithBasketEntry(basketEntryId: basketEntryId))
    }
    
    func setItem(item: Item) {
        self.setEvent(event: ItemSelectorContractEvent.SelectItem(item: item))
    }
}
