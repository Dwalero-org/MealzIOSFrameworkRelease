//
//  FiltersVM.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 01/07/2022.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class FiltersVM: ObservableObject {
    private var filterInstance: FilterInstance
    @Published public var state: FilterContractState?
    public var numberOfRecipes: Int = 0
    public var difficulty: [CatalogFilterOptions] = []
    public var cost: [CatalogFilterOptions] = []
    public var time: [CatalogFilterOptions] = []

    // we need a FilterInstance to decide how we want filters (traditional Catalog vs Meal Planner, etc)
    public init(filterInstance: FilterInstance) {
        self.filterInstance = filterInstance
        filterInstance.viewModel.collect(flow: filterInstance.viewModel.uiState) { [weak self] data in
            guard let strongSelf = self else { return }
            let state = data as? FilterContractState
            strongSelf.state = state
            strongSelf.numberOfRecipes = Int(state?.numberOfResult ?? 0)
            strongSelf.difficulty = state?.difficulty ?? []
            strongSelf.cost = state?.cost ?? []
            strongSelf.time = state?.time ?? []
        }
    }

    public func applyFilter() {
        filterInstance.viewModel.applyFilter()
    }

    public func setEvent(event: FilterContractEvent) {
        filterInstance.viewModel.setEvent(event: event)
    }
    public func search(searchString: String) {
        filterInstance.viewModel.setSearchString(searchString: searchString)
    }

    public func clear() {
        filterInstance.viewModel.clear()
    }
}
