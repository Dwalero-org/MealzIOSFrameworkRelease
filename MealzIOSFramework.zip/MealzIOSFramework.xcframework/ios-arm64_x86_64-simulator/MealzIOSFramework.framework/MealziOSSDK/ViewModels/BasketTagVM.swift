//
//  BasketTagVM.swift
//  MiamIOSFramework
//
//  Created by Miam on 07/07/2022.
//

import Foundation
import mealzcore
import Combine

@available(iOS 14, *)
public class BasketTagVM: BasketTagViewModel, ObservableObject {
    @Published public var recipes: [Recipe] = []
    @Published public var state: BasketTagContractState?
    
    public init(retailerProductId: String) {
        super.init(vmRouter: RouterOutletViewModel())
        collect(flow: uiState, collect: { [weak self] data in
            guard let strongSelf = self else { return }
            strongSelf.state = data as? BasketTagContractState
            switch strongSelf.state?.recipeList {
            case let success as BasicUiStateSuccess<NSArray>:
                if let recipes = success.data as? [Recipe] {
                    strongSelf.recipes = recipes
                }
            default:
                break
            }
        })
        setEvent(event: BasketTagContractEvent.SetRetailerProductId(productId: retailerProductId))
    }
}
