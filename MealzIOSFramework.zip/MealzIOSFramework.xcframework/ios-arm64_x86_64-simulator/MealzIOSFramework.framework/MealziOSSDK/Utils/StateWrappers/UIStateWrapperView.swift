//
//  UIStateWrapperView.swift
//
//
//  Created by didi on 13/10/2023.
//

import SwiftUI
import mealzcore
import Combine

@available(iOS 14, *)
struct UIStateWrapperView<State: AnyObject, Success: View, Loading: View, Empty: View>: View {
  let uiState: BasicUiState<State>?
  @ViewBuilder let loadingView: Loading
  @ViewBuilder let emptyView: Empty
  @ViewBuilder let successView: Success
  var idle: (any View)? = nil
  @SwiftUI.State private var showErrorView = false
  @SwiftUI.State private var timerCancellable: AnyCancellable?
   
  var body: some View {
    switch self.uiState {
    case is BasicUiStateIdle:
      if let idle = idle {
        AnyView(idle)
      }else{
        EmptyView()
      }
    case is BasicUiStateEmpty:
      emptyView
    case is BasicUiStateError:
      HStack { } // TODO handle error state
    case is BasicUiStateSuccess<State>:
      successView
    case is BasicUiStateLoading:
      loadingView
    default:
      if showErrorView {
        emptyView
      } else {
        loadingView
          .onAppear {
            // Start the timer when the loading view appears
            timerCancellable = Timer.publish(every: 5, on: .main, in: .common)
              .autoconnect()
              .sink { _ in
                // Timer's action: Show the error view after 5 seconds
                self.showErrorView = true
              }
          }
          .onDisappear {
            // Cancel the timer when the loading view disappears
            timerCancellable?.cancel()
          }
      }
    }
  }
}
