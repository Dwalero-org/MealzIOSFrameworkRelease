//
//  ComponentUIStateWrapperView.swift
//  
//
//  Created by Diarmuid McGonagle on 11/01/2024.
//

import Combine
import SwiftUI
import mealzcore

@available(iOS 14, *)
struct ComponentUIStateWrapperView<Success: View, Loading: View, Empty: View>: View {
    let uiState: ComponentUiState?
    @ViewBuilder let loadingView: Loading
    @ViewBuilder let emptyView: Empty
    @ViewBuilder let successView: Success
    @SwiftUI.State private var showErrorView = false
    @SwiftUI.State private var timerCancellable: AnyCancellable?
    
    var body: some View {
        switch self.uiState {
        case _ where self.uiState === ComponentUiState.empty:
            emptyView
        case _ where self.uiState === ComponentUiState.error:
            HStack { } // TODO handle error state
        case _ where self.uiState === ComponentUiState.success:
            successView
        case _ where self.uiState === ComponentUiState.loading:
            loadingView
        case _ where self.uiState === ComponentUiState.locked:
            successView
        default:
            if showErrorView {
                emptyView
            } else {
                loadingView
                    .onAppear {
                        // Start the timer when the loading view appears
                        timerCancellable = Timer.publish(every: 5, on: .main, in: .common)
                            .autoconnect()
                            .sink { _ in
                                // Timer's action: Show the error view after 5 seconds
                                self.showErrorView = true
                            }
                    }
                    .onDisappear {
                        // Cancel the timer when the loading view disappears
                        timerCancellable?.cancel()
                    }
            }
        }
    }
}
