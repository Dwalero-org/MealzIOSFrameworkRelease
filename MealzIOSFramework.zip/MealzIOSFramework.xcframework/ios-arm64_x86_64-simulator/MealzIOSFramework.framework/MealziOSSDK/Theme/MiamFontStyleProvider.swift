//
//  MiamFontStyleProvider.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 25/11/2022.
//  Copyright © 2022 Miam. All rights reserved.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public struct TitleBigFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 24, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct TitleFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 20, weight: .semibold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct TitleMediumFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 16, weight: .semibold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct TitleSmallFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 14, weight: .semibold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct TitleExtraSmallFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 13, weight: .semibold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct TitleExtraSmallMediumFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 13, weight: .medium, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct SubtitleFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 15, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyBigFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 16, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyBigBoldFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 16, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyBigLightFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 16, weight: .light, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 15, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyBoldFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 15, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyMediumFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 14, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyMediumBoldFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 14, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodySmallFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 12, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodySmallBoldFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 12, weight: .bold, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public struct BodyExtraSmallFontStyle: MiamFontStyle {
    public var font: Font = Font.system(size: 11, design: .default)
    public var color: Color?
}

@available(iOS 14, *)
public class MiamFontStyleProvider {
    static public let sharedInstance = MiamFontStyleProvider()

    public var titleStyle: MiamFontStyle = TitleFontStyle()
    public var titleBigStyle: MiamFontStyle = TitleBigFontStyle()
    public var titleMediumStyle: MiamFontStyle = TitleMediumFontStyle()
    public var titleSmallStyle: MiamFontStyle = TitleSmallFontStyle()
    public var titleExtraSmallStyle: MiamFontStyle = TitleExtraSmallFontStyle()
    public var titleExtraSmallMediumStyle: MiamFontStyle = TitleExtraSmallMediumFontStyle()
    public var subtitleStyle: MiamFontStyle = SubtitleFontStyle()
    public var bodyStyle: MiamFontStyle = BodyFontStyle()
    public var bodyBigStyle: MiamFontStyle = BodyBigFontStyle()
    public var bodyBigLightStyle: MiamFontStyle = BodyBigLightFontStyle()
    public var bodyBigBoldStyle: MiamFontStyle = BodyBigBoldFontStyle()
    public var bodyBoldStyle: MiamFontStyle = BodyBoldFontStyle()
    public var bodyMediumStyle: MiamFontStyle = BodyMediumFontStyle()
    public var bodyMediumBoldStyle: MiamFontStyle = BodyMediumBoldFontStyle()
    public var bodySmallStyle: MiamFontStyle = BodySmallFontStyle()
    public var bodySmallBoldStyle: MiamFontStyle = BodySmallBoldFontStyle()
    public var bodyExtraSmallStyle: MiamFontStyle = BodyExtraSmallFontStyle()
}
