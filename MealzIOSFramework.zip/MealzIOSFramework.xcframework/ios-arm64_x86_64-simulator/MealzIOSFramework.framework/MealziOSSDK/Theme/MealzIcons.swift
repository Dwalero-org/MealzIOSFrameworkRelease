//
//  MealzIcons.swift
//
//
//  Created by miam x didi on 30/11/2023.
//

import Foundation

// We need to do our best to keep this in alphabetical order
public enum MealzIcons: String {
    case alert = "mealzAlert"
    case arrow = "mealzArrow"
    case basket = "mealzBasket"
    case basketCheck = "mealzBasketCheck"
    case caret = "mealzCaret"
    case check = "mealzCheck"
    case chefHat = "mealzChefHat"
    case cutlery = "mealzCutlery"
    case edit = "mealzEdit"
    case eye = "mealzEye"
    case feelingBlue = "mealzFeelingBlue"
    case filters = "mealzFilters"
    case guests = "mealzGuests"
    case heart = "mealzHeart"
    case heartFilled = "mealzHeartFilled"
    case home = "mealzHome"
    case knife = "mealzKnife"
    case mealPlannerCTA = "mealzMealPlannerCTA"
    case menu = "mealzMenu"
    case minus = "mealzMinus"
    case pan = "mealzPan"
    case plus = "mealzPlus"
    case reset = "mealzReset"
    case search = "mealzSearch"
    case shop = "mealzShop"
    case swap = "mealzSwap"
    case time = "mealzTime"
    case trash = "mealzTrash"
    case user = "mealzUser"
    case userAdd = "mealzUserAdd"
}
