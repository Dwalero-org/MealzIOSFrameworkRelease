//
//  MealzColor.swift
//
//
//  Created by miam x didi on 07/12/2023.
//

import Foundation

@available(iOS 14, *)
public enum MealzColor: String {
    case darkBlue = "mealzDarkBlue"
    case darkerBlue = "mealzDarkerBlue"
    case darkestBlue = "mealzDarkestBlue"
    
    case lightBlue = "mealzLightBlue"
    case lighterBlue = "mealzLighterBlue"
    case lightestBlue = "mealzLightestBlue"
    
    case darkGray = "mealzDarkGray"
    case darkerGray = "mealzDarkerGray"
    case darkestGray = "mealzDarkestGray"
    
    case lightGray = "mealzLightGray"
    case lighterGray = "mealzLighterGray"
    case lightestGray = "mealzLightestGray"
    
    case white = "mealzWhite"
    case unpureWhite = "mealzUnpureWhite"
    case itemSelectedBackground = "mealzItemSelectedBackground"
    
    case red = "mealzRed"
    case burgundy = "mealzBurgundy"
    case pinkishRed = "mealzPinkishRed"
    case salmon = "mealzSalmon"
    case mustard = "mealzMustard"
    case brownishYellow = "mealzBrownishYellow"
    case green = "mealzGreen"
    
    case danger = "mealzDanger"
    case success = "mealzSuccess"
    case warning = "mealzWarning"
    
    case primaryText = "mealzPrimaryText"
    case standardLightText = "mealzStandardLightText"
    case standardDarkText = "mealzStandardDarkText"
    case grayText = "mealzGrayText"
    
    case primary = "mealzPrimary"
    case primaryBackground = "mealzPrimaryBackground"
    case border = "mealzBorder"
    case auxiliary = "mealzAuxiliary"
    case lightBackground = "mealzLightBackground"
    case errorBackground = "mealzErrorBackground"
    
    case backButton = "mealzBackButton"
}
