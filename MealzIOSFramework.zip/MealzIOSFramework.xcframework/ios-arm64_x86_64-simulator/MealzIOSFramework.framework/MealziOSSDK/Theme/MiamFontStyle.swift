//
//  MiamFontStyle.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 25/11/2022.
//  Copyright © 2022 Miam. All rights reserved.
//

import Foundation
import SwiftUI

@available(iOS 14, *)

public protocol MiamFontStyle {
    var font: Font { get }
    var color: Color? { get }
}

@available(iOS 14, *)
public struct MiamFontStyleModifier: ViewModifier {
    let fontStyle: MiamFontStyle

   public func body(content: Content) -> some View {
        content.font(fontStyle.font)// .fontWeight(weight)
        if let color = fontStyle.color {
            content.foregroundColor(color)
        }
    }
}

@available(iOS 14, *)
extension View {
    public func miamFontStyle(style: any MiamFontStyle) -> some View {
        modifier(MiamFontStyleModifier(fontStyle: style))
    }
}
