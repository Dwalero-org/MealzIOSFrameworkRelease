//
//  View.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 11/03/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
extension View {
    func prefersScrollIndicatorsHidden() -> some View {
        if #available(iOS 16, *) {
            return self.scrollIndicators(.hidden)
        } else {
            return self
        }
    }
}
