//
//  FirstLetterCapitalizer.swift
//  MiamIOSFramework
//
//  Created by Miam on 02/06/2022.
//

import Foundation

extension String {
    public func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }

    public mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
    
    public func spellOutTimeUnit() -> String {
        if self.contains("m") && !self.contains("min") {
            return self.replacingOccurrences(of: "m", with: " min")
        } else if self.contains("s") && !self.contains("sec") {
            return self.replacingOccurrences(of: "s", with: " sec")
        } else if self.contains("h") && !self.contains("hour") {
            return self.replacingOccurrences(of: "h", with: " hour")
        } else { return self }
    }
}
