//
//  FakeRecipe.swift
//  MiamIOSFramework
//
//  Created by didi on 6/13/23.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore

public struct FakeRecipe {
        /// Public init of FakeRecipe
        public init() {}
        let fake = RecipeFakeFactory()
        public func createRandomFakeRecipe() -> Recipe {
            let newAttributes = fake.createAdvancedAttributes()
            return fake.create(id: fake.FAKE_ID, attributes: newAttributes, relationships: nil)
        }
}
