//
//  BasketEntry.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 21/06/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore

public extension BasketEntry {
    var pictureURL: URL {
        guard let pictureUrlString = selectedItem?.attributes?.image else {
            return URL(string: "https://via.placeholder.com/150")!
        }
        return URL(string: pictureUrlString)!
    }
    var detailedDescription: String {
        let name = selectedItem?.attributes?.name.capitalizingFirstLetter() ?? ""
        let capacityUnit = selectedItem?.attributes?.capacityUnit ?? ""
        let capacityVolume = selectedItem?.attributes?.capacityVolume ?? ""
        return "\(name)\n\(capacityVolume) \(capacityUnit)"
    }

}

extension BasketEntry: Identifiable {
}
