//
//  Recipe.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 04/05/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import mealzcore

public extension Recipe {

    var title: String {
        return attributes?.title ?? ""
    }

    var difficulty: Int {
        return attributes?.difficulty?.intValue ?? 1
    }

    var pictureURL: URL {
        guard let pictureUrlString = attributes?.mediaUrl else {
            return URL(string: "")! // Should be a nice placeholder
        }
        return URL(string: pictureUrlString)!
    }
}

extension Recipe: Identifiable {
}
