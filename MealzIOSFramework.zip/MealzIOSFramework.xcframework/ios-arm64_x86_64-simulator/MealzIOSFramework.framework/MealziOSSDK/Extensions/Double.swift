//
//  Double.swift
//  MiamIOSFramework
//
//  Created by didi on 14/09/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation

extension Double {
    public var currencyFormatted: String {
        let price = self
        let numberFormatter = NumberFormatter()
        numberFormatter.maximumFractionDigits = 2
        numberFormatter.numberStyle = .currency
        numberFormatter.currencyCode = Localization.price.currency.localised
        if numberFormatter.currencyCode.contains("EUR") {
            // Set the positive format with the currency code on the trailing side
            numberFormatter.positiveFormat = "#,##0.00 ¤"
        }
        guard let formattedPrice = numberFormatter.string(from: NSNumber(floatLiteral: price)) else {
            return ""
        }
        return formattedPrice
    }
    
    public var currencyFormattedWholeNumber: String {
        let price = self
        let numberFormatter = NumberFormatter()
        numberFormatter.maximumFractionDigits = 0
        numberFormatter.numberStyle = .currency
        numberFormatter.currencyCode = Localization.price.currency.localised
        if numberFormatter.currencyCode.contains("EUR") {
            numberFormatter.positiveFormat = "#0 ¤"
        }
        guard let formattedPrice = numberFormatter.string(from: NSNumber(floatLiteral: price)) else {
            return ""
        }
        return formattedPrice
    }
    
    public func pricePerPerson(numberOfGuests: Int) -> String {
        let pricePerPerson = self / Double(numberOfGuests)
        return pricePerPerson.currencyFormatted
    }
    
    public func pricePerPersonWithText(numberOfGuests: Int) -> String {
        let pricePerPerson = self / Double(numberOfGuests)
        return "\(pricePerPerson.currencyFormatted) \(Localization.price.perGuest.localised)"
    }
}
