//
//  Image.swift
//  MiamIOSFramework
//
//  Created by Vincent Kergonna on 26/07/2022.
//

import Foundation
import SwiftUI
import mealzcore

@available(iOS 14, *)
extension Image {
    @available(*, deprecated, message: "Use .mealzIcon instead")
    public static func miamImage(icon: MiamIcon) -> Image {
        guard let image = UIImage(named: icon.rawValue) else {
            return Image(icon.rawValue, bundle: Bundle.miamBundle)
        }

        return Image(uiImage: image)
    }

    public static func mealzIcon(icon: MealzIcons) -> Image {
        guard let image = UIImage(named: icon.rawValue) else {
            return Image(miamCoreResourceName: icon.rawValue)
        }
        return Image(uiImage: image)
    }
    
    init(miamCoreResourceName: String) {
        let defaultImage = UIImage(systemName: "questionmark") ?? UIImage()
        let image = MealzImages.shared.getImageWithFileName(fileName: miamCoreResourceName).toUIImage() ?? defaultImage
        self.init(uiImage: image)
    }

}

// TODO: delete this
@available(iOS 14, *)
extension Image {
    @available(*, deprecated, message: "Use .mealzIcon instead")
    public static func miamNeutralImage(icon: MiamNeutralIcons) -> Image {
        guard let image = UIImage(named: icon.rawValue) else {
            return Image(icon.rawValue, bundle: Bundle.miamBundle)
        }

        return Image(uiImage: image)
    }
}
