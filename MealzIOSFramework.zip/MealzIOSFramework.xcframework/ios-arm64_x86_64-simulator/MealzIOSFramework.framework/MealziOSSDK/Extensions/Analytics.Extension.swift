//
//  Analytics.Extension.swift
//  MiamIOSFramework
//
//  Created by miam x didi on 05/01/2024.
//  Copyright © 2024 Miam. All rights reserved.
//

import Foundation
import mealzcore

extension Analytics {
    public static func setProps(
        recipeId: String? = nil,
        categoryId: String? = nil,
        entryName: String? = nil,
        basketId: String? = nil,
        miamAmount: KotlinFloat? = nil,
        totalAmount: String? = nil,
        posId: String? = nil,
        posTotalAmount: String? = nil,
        posName: String? = nil,
        searchTerm: String? = nil,
        usesCount: String? = nil,
        timePassed: String? = nil,
        budgetUser: String? = nil,
        budgetPlanner: String? = nil,
        recipeCount: String? = nil,
        query: String? = nil,
        guests: String? = nil,
        userPreference: String? = nil,
        itemId:  String? = nil,
        itemEan:  String? = nil,
        oldItemId:  String? = nil,
        oldItemEan: String? = nil,
        newItemId: String? = nil,
        newItemEan: String? = nil,
        recipeItemId: String? = nil,
        diff: String? = nil,
        fromMiam: Bool? = nil
    ) -> Analytics.PlausibleProps {
       return Analytics.PlausibleProps(
            recipe_id: recipeId,
            category_id: categoryId,
            entry_name: entryName,
            basket_id: basketId,
            miam_amount: miamAmount,
            total_amount: totalAmount,
            pos_id: posId,
            pos_total_amount: posTotalAmount,
            pos_name: posName,
            search_term: searchTerm,
            uses_count: usesCount,
            time_passed: timePassed,
            budget_user: budgetUser,
            budget_planner: budgetPlanner,
            recipe_count: recipeCount,
            query: query,
            guests: guests,
            item_id: userPreference,
            item_ean: itemId,
            user_preference: itemEan,
            old_item_id: oldItemId,
            old_item_ean: oldItemEan,
            new_item_id: newItemId,
            new_item_ean: newItemEan,
            recipe_item_id: recipeItemId,
            diff: diff,
            from_miam: KotlinBoolean(nonretainedObject: fromMiam)
        )
    }
}
