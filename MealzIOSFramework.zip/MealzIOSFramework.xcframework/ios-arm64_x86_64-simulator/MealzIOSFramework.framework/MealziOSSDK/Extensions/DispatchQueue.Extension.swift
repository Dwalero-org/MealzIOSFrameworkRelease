//
//  DispatchQueue.Extension.swift
//  MiamIOSFramework
//
//  Created by miam x didi on 12/12/2023.
//  Copyright © 2023 Miam. All rights reserved.
//

import Foundation
import Combine

@available(iOS 14, *)
extension DispatchQueue {
    // Helper function to create a cancellable timer
    static func schedule(after delay: TimeInterval, action: @escaping () -> Void) -> Cancellable {
        let workItem = DispatchWorkItem(block: action)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: workItem)
        return CancellableWrapper(workItem: workItem)
    }
}

class CancellableWrapper: Cancellable {
    private var workItem: DispatchWorkItem?

    init(workItem: DispatchWorkItem) {
        self.workItem = workItem
    }

    func cancel() {
        workItem?.cancel()
        workItem = nil
    }
}
